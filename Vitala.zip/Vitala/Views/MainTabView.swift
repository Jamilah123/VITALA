//
//  MainTabView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI

struct MainTabView: View {

    let repository: ProfileRepository

    let onLogout: () -> Void

    @State private var selectedTab = 0

    init(
        repository: ProfileRepository,
        onLogout: @escaping () -> Void = {}
    ) {
        self.repository = repository
        self.onLogout = onLogout
    }

    var body: some View {

        VStack(spacing: 0) {

            Group {

                switch selectedTab {

                case 0:

                    HomeView(
                        repository: repository,
                        openTab: { tab in
                            selectedTab = tab
                        }
                    )

                case 1:

                    CheckupsView()

                case 2:

                    PatientFollowUpView()

                case 3:

                    PatientHealthRecordView(repository: repository)

                default:

                    PatientAccountView(onLogout: onLogout)

                }

            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            Divider()

            HStack(spacing: 0) {

                tabButton(title: "الرئيسية", icon: "house.fill", tag: 0)

                tabButton(title: "فحوصاتي", icon: "heart.text.clipboard", tag: 1)

                tabButton(title: "المتابعة", icon: "chart.bar", tag: 2)

                tabButton(title: "السجل", icon: "list.bullet.rectangle", tag: 3)

                tabButton(title: "حسابي", icon: "person.crop.circle", tag: 4)

            }
            .padding(.top, 10)
            .padding(.bottom, 8)
            .background(Color.white)

        }
        .background(Color.white)
        .environment(\.layoutDirection, .rightToLeft)
        .toolbar(.hidden, for: .navigationBar)

    }

    private func tabButton(
        title: String,
        icon: String,
        tag: Int
    ) -> some View {

        Button {
            selectedTab = tag
        } label: {

            VStack(spacing: 5) {

                Image(systemName: icon)
                    .font(.system(size: 21, weight: .semibold))

                Text(title)
                    .font(
                        .system(
                            size: 11,
                            weight: selectedTab == tag ? .bold : .regular
                        )
                    )

            }
            .frame(maxWidth: .infinity)
            .foregroundStyle(
                selectedTab == tag
                    ? VitalaTheme.Colors.navy
                    : VitalaTheme.Colors.muted
            )
            .contentShape(Rectangle())

        }
        .buttonStyle(.plain)

    }

}

// MARK: - Preview

#Preview {

    MainTabView(repository: InMemoryProfileRepository())
        .environment(\.layoutDirection, .rightToLeft)

}
