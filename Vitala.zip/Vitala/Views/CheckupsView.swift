//
//  CheckupsView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI

struct CheckupsView: View {

    @StateObject private var viewModel = CheckupsViewModel()
    @State private var selectedCheckup: Checkup?

    var body: some View {

        VStack(spacing: 0) {

            VitalaHeader(title: "فحوصاتي", showsBack: false)

            ScrollView {

                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("خريطتك الوقائية")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(VitalaTheme.Colors.navy)

                        Text("تابع فحوصاتك الصحية واحتفظ بسجلك")
                            .font(.system(size: 15))
                            .foregroundStyle(VitalaTheme.Colors.muted)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    HStack(spacing: 10) {

                        summaryCard(
                            title: "قادمة",
                            count: viewModel.checkups.filter { $0.status == .upcoming }.count,
                            color: .blue
                        )

                        summaryCard(
                            title: "متأخرة",
                            count: viewModel.checkups.filter { $0.status == .overdue }.count,
                            color: .orange
                        )

                        summaryCard(
                            title: "مكتملة",
                            count: viewModel.checkups.filter { $0.status == .completed }.count,
                            color: .green
                        )
                    }

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 8) {

                            ForEach(viewModel.filters, id: \.self) { filter in

                                Button {
                                    viewModel.selectedFilter = filter
                                } label: {

                                    Text(filter)
                                        .font(.system(size: 14, weight: .semibold))
                                        .padding(.horizontal, 18)
                                        .padding(.vertical, 11)
                                        .foregroundStyle(
                                            viewModel.selectedFilter == filter
                                            ? .white
                                            : VitalaTheme.Colors.navy
                                        )
                                        .background(
                                            viewModel.selectedFilter == filter
                                            ? VitalaTheme.Colors.navy
                                            : .white
                                        )
                                        .clipShape(Capsule())
                                        .overlay {
                                            Capsule()
                                                .stroke(
                                                    VitalaTheme.Colors.border,
                                                    lineWidth: 1
                                                )
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    VStack(spacing: 12) {

                        ForEach(viewModel.filteredCheckups) { checkup in

                            Button {
                                selectedCheckup = checkup
                            } label: {

                                checkupRow(checkup)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(20)
            }
        }
        .background(VitalaTheme.Colors.background)
        .environment(\.layoutDirection, .rightToLeft)
        .sheet(item: $selectedCheckup) { checkup in
            CheckupDetailsView(checkup: checkup)
        }
    }

    private func summaryCard(
        title: String,
        count: Int,
        color: Color
    ) -> some View {

        VStack(spacing: 8) {

            Text("\(count)")
                .font(.system(size: 23, weight: .bold))
                .foregroundStyle(color)

            Text(title)
                .font(.system(size: 13))
                .foregroundStyle(VitalaTheme.Colors.muted)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 17))
    }


        private func checkupRow(_ checkup: Checkup) -> some View {

            VStack(alignment: .leading, spacing: 12) {

                HStack {

                    Text(checkup.status.rawValue)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(statusColor(checkup.status))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(
                            statusColor(checkup.status).opacity(0.1)
                        )
                        .clipShape(Capsule())

                    Spacer()

                    Image(systemName: "chevron.left")
                        .foregroundStyle(VitalaTheme.Colors.muted)
                }

                Text(checkup.name)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .multilineTextAlignment(.leading)

                HStack {

                    Text(checkup.category)
                        .font(.system(size: 13))
                        .foregroundStyle(VitalaTheme.Colors.muted)

                    Spacer()

                    Text(checkup.date)
                        .font(.system(size: 13))
                        .foregroundStyle(VitalaTheme.Colors.muted)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(17)
            .background(.white)
            .clipShape(
                RoundedRectangle(cornerRadius: 20)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 20)
                    .stroke(
                        VitalaTheme.Colors.border,
                        lineWidth: 1
                    )
            }
        }


    private func statusColor(_ status: CheckupStatus) -> Color {
        switch status {
        case .overdue: return .orange
        case .upcoming: return .blue
        case .completed: return .green
        }
    }
}


#Preview("فحوصاتي") {
    CheckupsView()
        .environment(\.layoutDirection, .rightToLeft)
}
