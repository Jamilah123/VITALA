//
//  PatientAccountView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI

struct PatientAccountView: View {

    @StateObject private var viewModel = PatientAccountViewModel()

    @State private var isEditing = false
    @State private var showLogoutConfirmation = false

    var onLogout: () -> Void = {}

    var body: some View {

        ScrollView(showsIndicators: false) {

            VStack(alignment: .leading, spacing: 20) {

                PatientTabHeading(
                    title: "الحساب",
                    subtitle: "بيانات حسابك وتفضيلاتك",
                    symbol: "person.crop.circle"
                )

                PatientTabCard {

                    HStack(spacing: 14) {

                        Image(systemName: "person.crop.circle.fill")
                            .font(.system(size: 52))
                            .foregroundStyle(PatientTabPalette.green)

                        VStack(alignment: .leading, spacing: 6) {

                            Text(viewModel.fullName.isEmpty ? "ملفي الشخصي" : viewModel.fullName)
                                .font(.headline)
                                .foregroundStyle(PatientTabPalette.navy)

                            Text(viewModel.email.isEmpty ? "أضيفي بيانات التواصل" : viewModel.email)
                                .font(.caption)
                                .foregroundStyle(.secondary)

                        }

                        Spacer()

                    }

                }

                Text("المعلومات الشخصية")
                    .font(.headline)
                    .foregroundStyle(PatientTabPalette.navy)

                PatientTabCard {

                    VStack(alignment: .leading, spacing: 14) {

                        accountRow("الاسم الكامل", value: viewModel.fullName)

                        Divider()

                        accountRow("رقم الجوال", value: viewModel.phone)

                        Divider()

                        accountRow("البريد الإلكتروني", value: viewModel.email)

                        Button {

                            isEditing = true

                        } label: {

                            Label(
                                "تعديل بيانات الحساب",
                                systemImage: "square.and.pencil"
                            )
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity)
                            .padding(14)
                            .foregroundStyle(.white)
                            .background(
                                PatientTabPalette.navy,
                                in: RoundedRectangle(cornerRadius: 13)
                            )

                        }
                        .buttonStyle(.plain)

                    }

                }

                Text("التفضيلات")
                    .font(.headline)
                    .foregroundStyle(PatientTabPalette.navy)

                PatientTabCard {

                    Toggle(
                        "تفضيل تلقي الإشعارات",
                        isOn: $viewModel.notificationsEnabled
                    )
                    .tint(PatientTabPalette.green)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                }
                .font(.caption)
                .foregroundStyle(.secondary)

                // MARK: - Logout

                Button {

                    showLogoutConfirmation = true

                } label: {

                    Label(
                        "تسجيل الخروج",
                        systemImage: "rectangle.portrait.and.arrow.right"
                    )
                    .font(.subheadline.bold())
                    .frame(maxWidth: .infinity)
                    .padding(14)
                    .foregroundStyle(.red)
                    .background(
                        Color.red.opacity(0.06),
                        in: RoundedRectangle(cornerRadius: 13)
                    )

                }
                .buttonStyle(.plain)

            }
            .padding(20)

        }
        .background(Color.white.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $isEditing) {

            NavigationStack {

                Form {

                    TextField("الاسم الكامل", text: $viewModel.fullName)

                    TextField("رقم الجوال", text: $viewModel.phone)
                        .keyboardType(.phonePad)

                    TextField("البريد الإلكتروني", text: $viewModel.email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)

                }
                .navigationTitle("تعديل الحساب")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {

                    ToolbarItem(placement: .confirmationAction) {

                        Button("تم") {
                            isEditing = false
                        }

                    }

                }

            }
            .environment(\.layoutDirection, .rightToLeft)

        }
        .confirmationDialog(
            "هل تريدين تسجيل الخروج؟",
            isPresented: $showLogoutConfirmation,
            titleVisibility: .visible
        ) {

            Button("تسجيل الخروج", role: .destructive) {
                onLogout()
            }

            Button("إلغاء", role: .cancel) {}

        }
        .environment(\.layoutDirection, .rightToLeft)

    }

    private func accountRow(
        _ title: String,
        value: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 5) {

            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            Text(value.isEmpty ? "غير مضاف" : value)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(PatientTabPalette.navy)

        }

    }

}

#Preview("الحساب") {

    PatientAccountView()
        .environment(\.locale, Locale(identifier: "ar"))

}

