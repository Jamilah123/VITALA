//
//  SetupCompleteView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI

struct SetupCompleteView: View {

    let onShowMap: () -> Void

    var body: some View {

        VStack(spacing: 0) {

            VitalaHeader(
                title: "اكتمل",
                showsBack: false,
                showsLogo: false
            )

            Spacer()

            Image("SetupComplete")
                .resizable()
                .scaledToFit()
                .frame(width: 220, height: 220)
                .padding(.bottom, 35)

            Text("جهزنا خريطتك الوقائية")
                .font(.system(size: 27, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            Text("بناءً على عمرك وتاريخك الصحي، وجدنا 5 فحوصات ومتابعة للسكري والضغط")
                .font(.system(size: 17))
                .foregroundStyle(VitalaTheme.Colors.muted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 12)
                .padding(.top, 8)

            PrimaryButton(title: "عرض خريطتي") {
                onShowMap()
            }
            .padding(.top, 18)

            Spacer()
            Spacer()
        }
        .padding(.horizontal, 20)
        .background(VitalaTheme.Colors.background)
        .environment(\.layoutDirection, .rightToLeft)
        .toolbar(.hidden, for: .navigationBar)
    }
}

#Preview("اكتمل الإعداد") {
    SetupCompleteView {
        print("عرض الخريطة")
    }
    .environment(\.layoutDirection, .rightToLeft)
}
