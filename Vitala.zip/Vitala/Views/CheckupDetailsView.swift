//
//  Untitled.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import SwiftUI

struct CheckupDetailsView: View {

    let checkup: Checkup

    @State private var showingAddResult = false
    @State private var results: [CheckupResult] = []

    private var latestResult: CheckupResult? {
        results.first
    }

    var body: some View {

        ScrollView {

            VStack(alignment: .leading, spacing: 20) {

                // MARK: - Checkup Information

                VStack(alignment: .leading, spacing: 8) {

                    Text(checkup.name)
                        .font(.title2.bold())

                    Text(checkup.category)
                        .foregroundStyle(.secondary)

                    Text(checkup.description)
                        .font(.body)
                }

                Divider()

                // MARK: - Checkup Importance

                VStack(alignment: .leading, spacing: 8) {

                    Text("أهمية الفحص")
                        .font(.headline)

                    Text(checkup.importance)
                        .foregroundStyle(.secondary)
                }

                Divider()

                // MARK: - Previous Results

                VStack(alignment: .leading, spacing: 12) {

                    HStack {

                        Text("النتائج السابقة")
                            .font(.headline)

                        Spacer()

                        Text("\(results.count) نتائج")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    if results.isEmpty {

                        ContentUnavailableView(
                            "لا توجد نتائج",
                            systemImage: "doc.text.magnifyingglass",
                            description: Text(
                                "يمكنك إضافة نتيجة لهذا الفحص"
                            )
                        )

                    } else {

                        ForEach(results) { result in

                            VStack(alignment: .leading, spacing: 8) {

                                HStack(alignment: .firstTextBaseline) {

                                    Text(result.value)
                                        .font(.title3.bold())

                                    Text(result.unit)
                                        .foregroundStyle(.secondary)

                                    Spacer()

                                    Text(
                                        result.date.formatted(
                                            date: .abbreviated,
                                            time: .omitted
                                        )
                                    )
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                }

                                if !result.notes.isEmpty {

                                    Text(result.notes)
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .padding()
                            .frame(
                                maxWidth: .infinity,
                                alignment: .leading
                            )
                            .background(
                                Color(.secondarySystemBackground)
                            )
                            .clipShape(
                                RoundedRectangle(cornerRadius: 12)
                            )
                        }
                    }
                }

                // MARK: - Add Result Button

                Button {
                    showingAddResult = true
                } label: {

                    Label(
                        "إضافة نتيجة",
                        systemImage: "plus"
                    )
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        VitalaTheme.Colors.navy,
                        in: RoundedRectangle(cornerRadius: 14)
                    )
                }
                .buttonStyle(.plain)
            }
            .padding()
        }
        .navigationTitle("تفاصيل الفحص")
        .navigationBarTitleDisplayMode(.inline)

        // MARK: - Add Result Sheet

        .sheet(isPresented: $showingAddResult) {

            AddCheckupResultView(
                checkupID: checkup.id
            ) {
                loadResults()
            }
        }

        // MARK: - Load Results

        .onAppear {
            loadResults()
        }
    }

    // MARK: - Fetch Results

    private func loadResults() {

        results = CheckupResultsStore.shared.results(
            for: checkup.id
        )
    }
}

// MARK: - Preview

#Preview("تفاصيل الفحص") {

    NavigationStack {

        CheckupDetailsView(
            checkup: CheckupsViewModel().checkups[0]
        )
        .environment(
            \.layoutDirection,
            .rightToLeft
        )
    }
}
