//
//  WelcomeView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import SwiftUI

struct WelcomeView: View {

    @StateObject private var viewModel: WelcomeViewModel
    @State private var selectedAction: String? = nil
    @State private var showClinicLogin = false

    init(viewModel: WelcomeViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {
        VStack(spacing: 0) {

            Spacer()

            VitalaLogo(size: 130)

            Text("Vitala")
                .font(.system(size: 52, weight: .bold, design: .serif))
                .foregroundStyle(VitalaTheme.Colors.navy)
                .padding(.top, 8)

            Rectangle()
                .fill(VitalaTheme.Colors.border)
                .frame(width: 140, height: 1)
                .padding(.vertical, 28)

            Text("ابدأ رحلتك\nالصحية الوقائية")
                .font(.system(size: 28, weight: .bold))
                .multilineTextAlignment(.center)
                .foregroundStyle(VitalaTheme.Colors.navy)

            Spacer()

            VStack(spacing: 8) {

                if selectedAction == "start" {
                    PrimaryButton(title: "ابدأ الآن") {
                        viewModel.startTapped()
                    }
                } else {
                    SecondaryButton(title: "ابدأ الآن") {
                        selectedAction = "start"
                        viewModel.startTapped()
                    }
                }

                if selectedAction == "login" {
                    PrimaryButton(title: "تسجيل الدخول") {
                        viewModel.loginTapped()
                    }
                } else {
                    SecondaryButton(title: "تسجيل الدخول") {
                        selectedAction = "login"
                        viewModel.loginTapped()
                    }
                }

                Button {
                    showClinicLogin = true
                } label: {
                    Text("تسجيل العيادة")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(VitalaTheme.Colors.navy)
                        .padding(.top, 14)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 130)
            .animation(
                .easeInOut(duration: 0.15),
                value: selectedAction
            )
        }
        .background(VitalaTheme.Colors.background)
        .toolbar(.hidden, for: .navigationBar)
        .fullScreenCover(isPresented: $showClinicLogin) {
            ClinicEntryView()
                .environment(\.layoutDirection, .rightToLeft)
        }
        .onAppear {
            selectedAction = nil
        }
    }
}

#Preview("البداية") {
    WelcomeView(
        viewModel: AppContainer().makeWelcomeViewModel()
    )
    .environment(\.layoutDirection, .rightToLeft)
    .environment(\.locale, Locale(identifier: "ar"))
}

