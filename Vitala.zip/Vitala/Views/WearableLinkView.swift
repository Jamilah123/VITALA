//
//  WearableLinkView..swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI

struct WearableLinkView: View {

    @StateObject private var viewModel: WearableLinkViewModel

    init(viewModel: WearableLinkViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {

        VStack(spacing: 0) {

            VitalaHeader(
                title: "ربط الساعة",
                showsBack: true
            ) {
                viewModel.backTapped()
            }

            ScrollView {
                VStack(alignment: .trailing, spacing: 18) {

                    StepProgressBar(currentStep: 3)
                        .padding(.horizontal, 20)
                    VStack(alignment: .trailing, spacing: 18) {

                        Text("ربط الساعة الذكية")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundStyle(VitalaTheme.Colors.navy)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .multilineTextAlignment(.trailing)
                            .environment(\.layoutDirection, .leftToRight)

                        VStack(spacing: 18) {

                            activityRow(
                                icon: "figure.run",
                                title: "الخطوات والدقائق النشطة",
                                subtitle: viewModel.stepsText,
                                color: Color(red: 0.91, green: 0.93, blue: 0.97),
                                connected: viewModel.activityData.steps != nil
                            )

                            activityRow(
                                icon: "heart",
                                title: "معدل النبض",
                                subtitle: viewModel.heartRateText,
                                color: Color(red: 0.97, green: 0.89, blue: 0.90),
                                connected: viewModel.activityData.heartRate != nil
                            )

                            activityRow(
                                icon: "moon",
                                title: "النوم",
                                subtitle: viewModel.sleepText,
                                color: Color(red: 0.89, green: 0.92, blue: 0.86),
                                connected: viewModel.activityData.sleepHours != nil
                            )
                        }
                        .padding(14)
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        .overlay {
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(
                                    VitalaTheme.Colors.border,
                                    lineWidth: 1
                                )
                        }

                        if let error = viewModel.errorMessage {
                            Text(error)
                                .font(.system(size: 14))
                                .foregroundStyle(.red)
                                .frame(
                                    maxWidth: .infinity,
                                    alignment: .trailing
                                )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    .padding(.bottom, 20)
                }
            }

            VStack(spacing: 16) {

                PrimaryButton(
                    title: viewModel.isConnecting
                    ? "جارٍ ربط الساعة..."
                    : "السماح وربط الساعة",
                    isEnabled: !viewModel.isConnecting
                ) {
                    viewModel.connectHealth()
                }

                Button {
                    viewModel.skipTapped()
                } label: {
                    Text("تخطي الآن")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(VitalaTheme.Colors.navy)
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 16)
        }
        .background(VitalaTheme.Colors.background)
        .environment(\.layoutDirection, .rightToLeft)
        .toolbar(.hidden, for: .navigationBar)
    }

    
    
    private func activityRow(
        icon: String,
        title: String,
        subtitle: String,
        color: Color,
        connected: Bool
    ) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .trailing, spacing: 6) {
                Text(title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)
                    .fixedSize(horizontal: false, vertical: true)

                Text(subtitle)
                    .font(.system(size: 13))
                    .foregroundStyle(VitalaTheme.Colors.muted)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)

            Image(systemName: icon)
                .font(.system(size: 21))
                .foregroundStyle(VitalaTheme.Colors.navy)
                .frame(width: 52, height: 52)
                .background(color)
                .clipShape(RoundedRectangle(cornerRadius: 15))

            Image(systemName: connected ? "checkmark" : "minus")
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 32, height: 28)
                .background(
                    connected
                    ? Color(red: 0.43, green: 0.51, blue: 0.34)
                    : VitalaTheme.Colors.border
                )
                .clipShape(RoundedRectangle(cornerRadius: 8))
        }
        .frame(maxWidth: .infinity)
    }
}


#Preview("ربط الساعة") {
    let container = AppContainer()

    WearableLinkView(
        viewModel: container.makeWearableLinkViewModel()
    )
    .environment(\.layoutDirection, .rightToLeft)
}
