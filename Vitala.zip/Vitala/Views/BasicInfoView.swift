//
//  BasicInfoView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//




import SwiftUI
import Foundation

struct BasicInfoView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: BasicInfoViewModel
    private let openedFromHealthRecord: Bool
    private let healthHistoryViewModel: HealthHistoryViewModel?
    @State private var showHealthHistory = false

    init(
        viewModel: BasicInfoViewModel,
        openedFromHealthRecord: Bool = false,
        healthHistoryViewModel: HealthHistoryViewModel? = nil
    ) {
        _viewModel = StateObject(wrappedValue: viewModel)
        self.openedFromHealthRecord = openedFromHealthRecord
        self.healthHistoryViewModel = healthHistoryViewModel
    }

    private func handleBack() {
        if openedFromHealthRecord { dismiss() }
        else { viewModel.backTapped() }
    }

    private func handleNext() {
        if openedFromHealthRecord { showHealthHistory = true }
        else { viewModel.nextTapped() }
    }

    var body: some View {
        VStack(spacing: 0) {
            VitalaHeader(title: "المعلومات الأساسية", showsBack: true) {
                handleBack()
            }
            ScrollView {
                VStack(spacing: 14) {
                    StepProgressBar(currentStep: 1)
                    ScreenTitle(
                        title: "المعلومات الأساسية",
                        subtitle: "نستخدمها لتحديد الفحوصات المناسبة لعمرك وجنسك"
                    )
                    birthDateRow
                    genderRow
                    measurementRow(
                        title: "الطول", unit: "سم",
                        text: $viewModel.heightText,
                        isValid: viewModel.isHeightValid
                    )
                    measurementRow(
                        title: "الوزن", unit: "كجم",
                        text: $viewModel.weightText,
                        isValid: viewModel.isWeightValid
                    )
                    BMICard(viewModel: viewModel)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 16)
            }
            .scrollDismissesKeyboard(.interactively)
            HStack(spacing: 12) {
                SecondaryButton(title: "رجوع") { handleBack() }
                PrimaryButton(title: "التالي", isEnabled: viewModel.canProceed) {
                    handleNext()
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 16)
        }
        .background(VitalaTheme.Colors.background)
        #if os(iOS) || os(visionOS)
        .toolbar(.hidden, for: .navigationBar)
        #endif
        .navigationDestination(isPresented: $showHealthHistory) {
            if let healthHistoryViewModel {
                HealthHistoryView(
                    viewModel: healthHistoryViewModel,
                    openedFromHealthRecord: true,
                    onFinishEditing: {
                        showHealthHistory = false
                        DispatchQueue.main.async { dismiss() }
                    }
                )
            }
        }
    }

    // MARK: - Rows
    private var birthDateRow: some View {
        FieldRow(title: "تاريخ الميلاد") {
            DatePicker("", selection: $viewModel.birthDate, in: ...Date(), displayedComponents: .date)
                .labelsHidden()
                .environment(\.calendar, Calendar(identifier: .gregorian))
        }
    }

    private var genderRow: some View {
        HStack(spacing: 10) {
            ForEach(Gender.allCases) { gender in
                ChipView(title: gender.title, isSelected: viewModel.gender == gender) {
                    viewModel.gender = gender
                }
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func measurementRow(
        title: String,
        unit: String,
        text: Binding<String>,
        isValid: Bool
    ) -> some View {
        FieldRow(title: title) {
            HStack(spacing: 6) {
                TextField("0", text: text)
                #if os(iOS) || os(visionOS)
                    .keyboardType(UIKeyboardType.decimalPad)
                #endif
                    .multilineTextAlignment(.leading)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)
                    .frame(maxWidth: 80)
                Text(unit)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)
            }
        }
    }
}

// MARK: - BMI Card
private struct BMICard: View {
    @ObservedObject var viewModel: BasicInfoViewModel
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("مؤشر كتلة الجسم")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)
                Spacer()
                Text(viewModel.bmiDisplay)
                    .font(.system(size: 34, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.green)
            }
            // الشريط دائماً يسار إلى يمين (أزرق إلى أحمر)
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [
                                    Color(hex: 0x7D93C0),
                                    Color(hex: 0x8BB06A),
                                    Color(hex: 0xE8B84A),
                                    Color(hex: 0xD9706F)
                                ],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(height: 10)
                    if viewModel.bmi != nil {
                        Circle()
                            .fill(.white)
                            .overlay(
                                Circle().stroke(VitalaTheme.Colors.navy, lineWidth: 2)
                            )
                            .frame(width: 18, height: 18)
                            .offset(x: (geo.size.width - 18) * viewModel.bmiMarkerPosition)
                    }
                }
                .frame(maxHeight: .infinity)
            }
            .frame(height: 18)
            .environment(\.layoutDirection, .leftToRight)
            Text(viewModel.bmiCategory?.title ?? "أدخل الطول والوزن")
                .font(.system(size: 14))
                .foregroundStyle(VitalaTheme.Colors.muted)
        }
        .padding(18)
        .background(
            VitalaTheme.Colors.surface,
            in: RoundedRectangle(cornerRadius: VitalaTheme.Radius.card)
        )
        .overlay(
            RoundedRectangle(cornerRadius: VitalaTheme.Radius.card)
                .stroke(VitalaTheme.Colors.border, lineWidth: 1)
        )
        .animation(.easeInOut(duration: 0.2), value: viewModel.bmi)
    }
}

// MARK: - Preview
#Preview("فارغ") {
    BasicInfoView(viewModel: AppContainer().makeBasicInfoViewModel())
        .environment(\.layoutDirection, .rightToLeft)
        .environment(\.locale, Locale(identifier: "ar"))
}

#Preview("ببيانات وهمية") {
    let container = AppContainer(
        repository: InMemoryProfileRepository(draft: MockData.patientDraft)
    )
    BasicInfoView(viewModel: container.makeBasicInfoViewModel())
        .environment(\.layoutDirection, .rightToLeft)
        .environment(\.locale, Locale(identifier: "ar"))
}
