//
//  MyAppointmentsView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI

struct MyAppointmentsView: View {

    @ObservedObject private var repository =
        AppointmentRepository.shared

    @Environment(\.dismiss) private var dismiss

    @State private var selectedFilter = "القادمة"
    @State private var appointmentToCancel: Appointment?
    @State private var appointmentToEdit: Appointment?
    @State private var errorMessage: String?

    private let filters = ["القادمة", "السابقة"]

    private var filteredAppointments: [Appointment] {

        repository.appointments
            .filter { appointment in

                switch selectedFilter {
                case "القادمة":
                    return appointment.displayStatus == .upcoming
                case "السابقة":
                    return appointment.displayStatus == .completed
                default:
                    return appointment.displayStatus == .cancelled
                }
            }
            .sorted { $0.date < $1.date }
    }

    var body: some View {

        NavigationStack {

            ScrollView {

                VStack(alignment: .leading, spacing: 20) {

                    Text("مواعيدي")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(VitalaTheme.Colors.navy)

                    filterSelector

                    if filteredAppointments.isEmpty {

                        ContentUnavailableView(
                            "لا توجد مواعيد",
                            systemImage: "calendar",
                            description: Text(
                                "لا توجد مواعيد في هذا القسم حاليًا."
                            )
                        )

                    } else {

                        ForEach(filteredAppointments) { appointment in

                            appointmentCard(appointment)
                        }
                    }
                }
                .padding(20)
            }
            .background(VitalaTheme.Colors.background)
            .navigationTitle("مواعيدي")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                ToolbarItem(placement: .topBarLeading) {

                    Button("إغلاق") {
                        dismiss()
                    }
                }
            }
            .confirmationDialog(
                "هل تريدين إلغاء هذا الموعد؟",
                isPresented: Binding(
                    get: { appointmentToCancel != nil },
                    set: {
                        if !$0 {
                            appointmentToCancel = nil
                        }
                    }
                ),
                titleVisibility: .visible
            ) {

                Button("إلغاء الموعد", role: .destructive) {

                    if let appointment = appointmentToCancel {

                        do {
                            try repository.cancel(appointment)
                        } catch {
                            errorMessage = error.localizedDescription
                        }
                    }

                    appointmentToCancel = nil
                }

                Button("تراجع", role: .cancel) {
                    appointmentToCancel = nil
                }
            }
            .sheet(item: $appointmentToEdit) { appointment in

                RescheduleAppointmentView(
                    appointment: appointment
                )
            }
            .alert(
                "تنبيه",
                isPresented: Binding(
                    get: { errorMessage != nil },
                    set: {
                        if !$0 {
                            errorMessage = nil
                        }
                    }
                )
            ) {

                Button("حسنًا", role: .cancel) {}

            } message: {

                Text(errorMessage ?? "")
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    private var filterSelector: some View {

        HStack(spacing: 8) {

            ForEach(filters, id: \.self) { filter in

                Button {
                    selectedFilter = filter
                } label: {

                    Text(filter)
                        .font(.system(size: 13, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .foregroundStyle(
                            selectedFilter == filter
                            ? .white
                            : VitalaTheme.Colors.navy
                        )
                        .background(
                            selectedFilter == filter
                            ? VitalaTheme.Colors.navy
                            : .white
                        )
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func appointmentCard(
        _ appointment: Appointment
    ) -> some View {

        VStack(alignment: .leading, spacing: 12) {

            Text(appointment.clinicName)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            Label(
                appointment.service,
                systemImage: "heart.text.square"
            )

            Label(
                appointment.formattedDate,
                systemImage: "calendar"
            )

            Label(
                appointment.formattedTime,
                systemImage: "clock"
            )

            Label(
                appointment.clinicAddress,
                systemImage: "mappin"
            )

            if appointment.displayStatus == .upcoming {

                Divider()

                HStack(spacing: 12) {

                    Button("تعديل الموعد") {
                        appointmentToEdit = appointment
                    }
                    .foregroundStyle(VitalaTheme.Colors.navy)

                    Spacer()

                    Button("إلغاء الموعد", role: .destructive) {
                        appointmentToCancel = appointment
                    }
                }
                .font(.system(size: 13, weight: .semibold))
            }
        }
        .font(.system(size: 13))
        .foregroundStyle(VitalaTheme.Colors.muted)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

// MARK: - Reschedule

struct RescheduleAppointmentView: View {

    let appointment: Appointment

    @ObservedObject private var repository =
        AppointmentRepository.shared

    @Environment(\.dismiss) private var dismiss

    @State private var selectedDate = Date()
    @State private var selectedTime = "09:00"
    @State private var errorMessage: String?

    private let times = [
        "09:00", "10:30", "12:00",
        "14:00", "15:30", "17:00"
    ]

    private var selectedDateTime: Date? {

        let parts = selectedTime.split(separator: ":")

        guard parts.count == 2,
              let hour = Int(parts[0]),
              let minute = Int(parts[1]) else {
            return nil
        }

        return Calendar.current.date(
            bySettingHour: hour,
            minute: minute,
            second: 0,
            of: selectedDate
        )
    }

    private var availableTimes: [String] {

        times.filter { time in

            let parts = time.split(separator: ":")

            guard parts.count == 2,
                  let hour = Int(parts[0]),
                  let minute = Int(parts[1]),
                  let date = Calendar.current.date(
                    bySettingHour: hour,
                    minute: minute,
                    second: 0,
                    of: selectedDate
                  ) else {
                return false
            }

            return date > Date() &&
                repository.isAvailable(
                    clinicID: appointment.clinicID,
                    date: date,
                    durationMinutes: appointment.durationMinutes,
                    excluding: appointment.id
                )
        }
    }

    var body: some View {

        NavigationStack {

            VStack(alignment: .leading, spacing: 20) {

                Text("اختاري موعدًا جديدًا")
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)

                DatePicker(
                    "التاريخ",
                    selection: $selectedDate,
                    in: Date()...,
                    displayedComponents: .date
                )
                .datePickerStyle(.graphical)

                Text("الأوقات المتاحة")
                    .font(.system(size: 17, weight: .bold))

                if availableTimes.isEmpty {

                    Text("لا توجد أوقات متاحة لهذا اليوم.")
                        .foregroundStyle(VitalaTheme.Colors.muted)

                } else {

                    Picker("الوقت", selection: $selectedTime) {

                        ForEach(availableTimes, id: \.self) { time in

                            Text(time).tag(time)
                        }
                    }
                    .pickerStyle(.wheel)
                    .onChange(of: selectedDate) { _, _ in
                        selectedTime = availableTimes.first ?? ""
                    }
                }

                Spacer()

                Button {

                    guard let newDate = selectedDateTime else {
                        return
                    }

                    do {
                        try repository.reschedule(
                            appointment,
                            to: newDate
                        )
                        dismiss()
                    } catch {
                        errorMessage = error.localizedDescription
                    }

                } label: {

                    Text("حفظ التعديل")
                        .font(.system(size: 16, weight: .bold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 17)
                        .foregroundStyle(.white)
                        .background(VitalaTheme.Colors.navy)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .disabled(
                    selectedDateTime == nil ||
                    !availableTimes.contains(selectedTime)
                )
            }
            .padding(20)
            .navigationTitle("تعديل الموعد")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                ToolbarItem(placement: .topBarLeading) {

                    Button("إغلاق") {
                        dismiss()
                    }
                }
            }
            .alert(
                "تعذر تعديل الموعد",
                isPresented: Binding(
                    get: { errorMessage != nil },
                    set: {
                        if !$0 {
                            errorMessage = nil
                        }
                    }
                )
            ) {

                Button("حسنًا", role: .cancel) {}

            } message: {

                Text(errorMessage ?? "")
            }
            .onAppear {
                selectedTime = availableTimes.first ?? ""
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}
