//
//  ClinicDetailsView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//



import SwiftUI
import MapKit

struct ClinicDetailsView: View {

    @StateObject private var viewModel: ClinicDetailsViewModel

    @Environment(\.dismiss) private var dismiss

    @State private var cameraPosition: MapCameraPosition

    @State private var showBooking = false

    init(clinic: NearbyClinic) {

        _viewModel = StateObject(
            wrappedValue: ClinicDetailsViewModel(
                clinic: clinic
            )
        )

        _cameraPosition = State(
            initialValue: .region(
                MKCoordinateRegion(
                    center: clinic.coordinate,
                    span: MKCoordinateSpan(
                        latitudeDelta: 0.012,
                        longitudeDelta: 0.012
                    )
                )
            )
        )
    }

    // MARK: - Body

    var body: some View {

        NavigationStack {

            ScrollView {

                VStack(alignment: .leading, spacing: 20) {

                    clinicHeader

                    locationSection

                    informationSection

                    servicesSection

                    bookingButton
                }
                .padding(20)
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
            }
            .background(VitalaTheme.Colors.background)
            .navigationTitle("تفاصيل العيادة")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                ToolbarItem(placement: .topBarLeading) {

                    Button("إغلاق") {
                        dismiss()
                    }
                    .foregroundStyle(
                        VitalaTheme.Colors.navy
                    )
                }
            }
            .sheet(isPresented: $showBooking) {

                BookingView(clinic: viewModel.clinic)
                    .presentationDragIndicator(.visible)
            }
        }
        .environment(
            \.layoutDirection,
            .rightToLeft
        )
    }

    // MARK: - Clinic Header

    private var clinicHeader: some View {

        VStack(alignment: .leading, spacing: 12) {

            Text(viewModel.clinic.name)
                .font(.system(size: 23, weight: .bold))
                .foregroundStyle(
                    VitalaTheme.Colors.navy
                )
                .multilineTextAlignment(.leading)

            Text(viewModel.clinic.description)
                .font(.system(size: 14))
                .foregroundStyle(
                    VitalaTheme.Colors.muted
                )
                .multilineTextAlignment(.leading)

            HStack(spacing: 14) {

                if let rating = viewModel.clinic.rating {

                    Label(
                        String(
                            format: "%.1f",
                            rating
                        ),
                        systemImage: "star.fill"
                    )
                    .foregroundStyle(
                        VitalaTheme.Colors.green
                    )
                }

                Label(
                    "\(viewModel.clinic.district)، \(viewModel.clinic.city)",
                    systemImage: "mappin"
                )
                .foregroundStyle(
                    VitalaTheme.Colors.muted
                )
            }
            .font(.system(size: 13))
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .padding(18)
        .background(.white)
        .clipShape(
            RoundedRectangle(cornerRadius: 20)
        )
    }

    // MARK: - Location Section

    private var locationSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("الموقع")

            Map(position: $cameraPosition) {

                Annotation(
                    viewModel.clinic.name,
                    coordinate: viewModel.clinic.coordinate
                ) {

                    Image(
                        systemName: "cross.case.fill"
                    )
                    .font(.system(size: 20))
                    .foregroundStyle(.white)
                    .padding(12)
                    .background(
                        VitalaTheme.Colors.navy
                    )
                    .clipShape(Circle())
                }
            }
            .frame(height: 210)
            .clipShape(
                RoundedRectangle(cornerRadius: 18)
            )

            Label(
                viewModel.clinic.address,
                systemImage: "mappin.and.ellipse"
            )
            .font(.system(size: 14))
            .foregroundStyle(
                VitalaTheme.Colors.muted
            )

            if let mapsURL = viewModel.mapsURL {

                Link(destination: mapsURL) {

                    Label(
                        "فتح الموقع في الخرائط",
                        systemImage: "arrow.up.right.square"
                    )
                    .font(
                        .system(
                            size: 14,
                            weight: .semibold
                        )
                    )
                    .foregroundStyle(
                        VitalaTheme.Colors.green
                    )
                }
            }
        }
    }

    // MARK: - Information Section

    private var informationSection: some View {

        VStack(alignment: .leading, spacing: 14) {

            sectionTitle("معلومات العيادة")

            infoRow(
                icon: "clock",
                title: "ساعات العمل",
                value: viewModel.clinic.workingHours
            )

            if viewModel.hasPhoneNumber {

                infoRow(
                    icon: "phone",
                    title: "رقم التواصل",
                    value: viewModel.clinic.phone
                )

                if let phoneURL = viewModel.phoneURL {

                    Link(
                        "الاتصال بالعيادة",
                        destination: phoneURL
                    )
                    .font(.system(size: 14))
                    .foregroundStyle(
                        VitalaTheme.Colors.green
                    )
                }

            } else {

                infoRow(
                    icon: "phone",
                    title: "رقم التواصل",
                    value: "غير متوفر حاليًا"
                )
            }
        }
        .padding(17)
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .background(.white)
        .clipShape(
            RoundedRectangle(cornerRadius: 20)
        )
    }

    // MARK: - Services Section

    private var servicesSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("الفحوصات والخدمات المتاحة")

            VStack(spacing: 0) {

                ForEach(
                    viewModel.clinic.services,
                    id: \.self
                ) { service in

                    HStack(spacing: 10) {

                        Image(
                            systemName: "checkmark.circle.fill"
                        )
                        .foregroundStyle(
                            VitalaTheme.Colors.green
                        )

                        Text(service)
                            .font(.system(size: 15))
                            .foregroundStyle(
                                VitalaTheme.Colors.navy
                            )

                        Spacer()
                    }
                    .padding(.vertical, 15)

                    if service != viewModel.clinic.services.last {
                        Divider()
                    }
                }
            }
            .padding(.horizontal, 16)
            .background(.white)
            .clipShape(
                RoundedRectangle(cornerRadius: 20)
            )
        }
    }

    // MARK: - Booking Button

    private var bookingButton: some View {

        Button {

            showBooking = true

        } label: {

            HStack(spacing: 10) {

                Image(
                    systemName: "calendar.badge.plus"
                )

                Text("اختيار خدمة الفحص")
            }
            .font(
                .system(
                    size: 16,
                    weight: .bold
                )
            )
            .frame(maxWidth: .infinity)
            .padding(.vertical, 17)
            .foregroundStyle(.white)
            .background(
                VitalaTheme.Colors.navy
            )
            .clipShape(
                RoundedRectangle(cornerRadius: 16)
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - Section Title

    private func sectionTitle(
        _ title: String
    ) -> some View {

        Text(title)
            .font(
                .system(
                    size: 18,
                    weight: .bold
                )
            )
            .foregroundStyle(
                VitalaTheme.Colors.navy
            )
    }

    // MARK: - Information Row

    private func infoRow(
        icon: String,
        title: String,
        value: String
    ) -> some View {

        HStack(alignment: .top, spacing: 12) {

            Image(systemName: icon)
                .foregroundStyle(
                    VitalaTheme.Colors.green
                )
                .frame(width: 22)

            VStack(
                alignment: .leading,
                spacing: 5
            ) {

                Text(title)
                    .font(.system(size: 12))
                    .foregroundStyle(
                        VitalaTheme.Colors.muted
                    )

                Text(value)
                    .font(.system(size: 14))
                    .foregroundStyle(
                        VitalaTheme.Colors.navy
                    )
                    .multilineTextAlignment(.leading)
            }

            Spacer()
        }
    }
}

// MARK: - Preview

#Preview {

    ClinicDetailsView(
        clinic: MockNearbyClinicsRepository()
            .fetchClinics()[0]
    )
}
