//
//  BookingConfirmationView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI

struct BookingConfirmationView: View {

    let appointment: Appointment
    let onDone: () -> Void

    var body: some View {

        VStack(spacing: 24) {

            Spacer()

            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 72))
                .foregroundStyle(VitalaTheme.Colors.green)

            Text("تم تأكيد حجزك بنجاح!")
                .font(.system(size: 23, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            Text("موعدك مسجل في قسم مواعيدي.")
                .font(.system(size: 14))
                .foregroundStyle(VitalaTheme.Colors.muted)

            VStack(alignment: .leading, spacing: 18) {

                detailRow(
                    "العيادة",
                    appointment.clinicName,
                    icon: "cross.case"
                )

                detailRow(
                    "الخدمة",
                    appointment.service,
                    icon: "heart.text.square"
                )

                detailRow(
                    "التاريخ",
                    appointment.formattedDate,
                    icon: "calendar"
                )

                detailRow(
                    "الوقت",
                    appointment.formattedTime,
                    icon: "clock"
                )

                detailRow(
                    "الموقع",
                    appointment.clinicAddress,
                    icon: "mappin.and.ellipse"
                )
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white)
            .clipShape(RoundedRectangle(cornerRadius: 20))

            Spacer()

            Button(action: onDone) {

                Text("العودة إلى الصفحة الرئيسية")
                    .font(.system(size: 16, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 17)
                    .foregroundStyle(.white)
                    .background(VitalaTheme.Colors.navy)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            }
            .buttonStyle(.plain)
        }
        .padding(20)
        .background(VitalaTheme.Colors.background)
        .environment(\.layoutDirection, .rightToLeft)
    }

    private func detailRow(
        _ title: String,
        _ value: String,
        icon: String
    ) -> some View {

        HStack(alignment: .top, spacing: 12) {

            Image(systemName: icon)
                .foregroundStyle(VitalaTheme.Colors.green)
                .frame(width: 22)

            VStack(alignment: .leading, spacing: 5) {

                Text(title)
                    .font(.system(size: 12))
                    .foregroundStyle(VitalaTheme.Colors.muted)

                Text(value)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(VitalaTheme.Colors.navy)
            }

            Spacer()
        }
    }
}
