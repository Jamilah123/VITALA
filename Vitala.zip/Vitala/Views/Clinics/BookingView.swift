//
//  BookingView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI

struct BookingView: View {

    @StateObject private var viewModel: BookingViewModel
    @ObservedObject private var repository = AppointmentRepository.shared

    @Environment(\.dismiss) private var dismiss

    @State private var showBookingSummary = false

    init(clinic: NearbyClinic) {
        _viewModel = StateObject(
            wrappedValue: BookingViewModel(clinic: clinic)
        )
    }

    var body: some View {

        NavigationStack {

            ScrollView {

                VStack(alignment: .leading, spacing: 22) {

                    clinicCard

                    serviceSection

                    dateSection

                    timeSection

                    continueButton
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(VitalaTheme.Colors.background)
            .navigationTitle("حجز موعد")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                ToolbarItem(placement: .topBarLeading) {

                    Button("إغلاق") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showBookingSummary) {

                bookingSummary
                    .presentationDragIndicator(.visible)
            }
            .fullScreenCover(
                item: $viewModel.bookedAppointment
            ) { appointment in

                BookingConfirmationView(
                    appointment: appointment
                ) {
                    viewModel.bookedAppointment = nil
                    dismiss()

                    NotificationCenter.default.post(
                        name: Notification.Name("VitalaReturnHome"),
                        object: nil
                    )
                }
            }
            .alert(
                "تعذر إتمام الحجز",
                isPresented: Binding(
                    get: { viewModel.errorMessage != nil },
                    set: {
                        if !$0 {
                            viewModel.errorMessage = nil
                        }
                    }
                )
            ) {

                Button("حسنًا", role: .cancel) {}

            } message: {

                Text(viewModel.errorMessage ?? "")
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    // MARK: - Clinic

    private var clinicCard: some View {

        VStack(alignment: .leading, spacing: 7) {

            Text(viewModel.clinic.name)
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            Text(viewModel.clinic.address)
                .font(.system(size: 13))
                .foregroundStyle(VitalaTheme.Colors.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(17)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    // MARK: - Services

    private var serviceSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("اختاري خدمة الفحص")

            ForEach(viewModel.clinic.services, id: \.self) { service in

                Button {
                    viewModel.selectService(service)
                } label: {

                    HStack(spacing: 12) {

                        Text(service)
                            .font(.system(size: 15, weight: .medium))

                        Spacer()

                        Image(
                            systemName:
                                viewModel.selectedService == service
                                ? "checkmark.circle.fill"
                                : "circle"
                        )
                        .foregroundStyle(
                            viewModel.selectedService == service
                            ? VitalaTheme.Colors.green
                            : VitalaTheme.Colors.muted
                        )
                    }
                    .foregroundStyle(VitalaTheme.Colors.navy)
                    .padding(16)
                    .background(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                    .overlay {

                        RoundedRectangle(cornerRadius: 15)
                            .stroke(
                                viewModel.selectedService == service
                                ? VitalaTheme.Colors.navy
                                : VitalaTheme.Colors.border,
                                lineWidth: 1
                            )
                    }
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: - Dates

    private var dateSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("اختاري التاريخ")

            ScrollView(.horizontal, showsIndicators: false) {

                HStack(spacing: 10) {

                    ForEach(
                        viewModel.availableDates,
                        id: \.self
                    ) { date in

                        Button {
                            viewModel.selectDate(date)
                        } label: {

                            Text(viewModel.formattedDate(date))
                                .font(.system(size: 13, weight: .semibold))
                                .padding(.horizontal, 14)
                                .padding(.vertical, 14)
                                .foregroundStyle(
                                    Calendar.current.isDate(
                                        date,
                                        inSameDayAs: viewModel.selectedDate
                                    )
                                    ? .white
                                    : VitalaTheme.Colors.navy
                                )
                                .background(
                                    Calendar.current.isDate(
                                        date,
                                        inSameDayAs: viewModel.selectedDate
                                    )
                                    ? VitalaTheme.Colors.navy
                                    : .white
                                )
                                .clipShape(
                                    RoundedRectangle(cornerRadius: 14)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: - Times

    private var timeSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("الأوقات المتاحة")

            if viewModel.availableTimes.isEmpty {

                Text("لا توجد مواعيد متاحة لهذا اليوم.")
                    .font(.system(size: 14))
                    .foregroundStyle(VitalaTheme.Colors.muted)
                    .padding(15)

            } else {

                LazyVGrid(
                    columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ],
                    spacing: 10
                ) {

                    ForEach(viewModel.availableTimes) { slot in

                        Button {
                            viewModel.selectTime(slot)
                        } label: {

                            Text(slot.time)
                                .font(.system(size: 14, weight: .semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 15)
                                .foregroundStyle(
                                    viewModel.selectedTime == slot
                                    ? .white
                                    : VitalaTheme.Colors.navy
                                )
                                .background(
                                    viewModel.selectedTime == slot
                                    ? VitalaTheme.Colors.navy
                                    : .white
                                )
                                .clipShape(
                                    RoundedRectangle(cornerRadius: 14)
                                )
                                .overlay {

                                    RoundedRectangle(cornerRadius: 14)
                                        .stroke(
                                            VitalaTheme.Colors.border,
                                            lineWidth: 1
                                        )
                                }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: - Continue

    private var continueButton: some View {

        Button {
            showBookingSummary = true
        } label: {

            Label(
                "متابعة إلى تأكيد الحجز",
                systemImage: "calendar.badge.checkmark"
            )
            .font(.system(size: 16, weight: .bold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 17)
            .foregroundStyle(.white)
            .background(
                viewModel.canContinue
                ? VitalaTheme.Colors.navy
                : VitalaTheme.Colors.muted
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .disabled(!viewModel.canContinue)
        .buttonStyle(.plain)
    }

    // MARK: - Booking Summary

    private var bookingSummary: some View {

        NavigationStack {

            VStack(alignment: .leading, spacing: 18) {

                Text("راجعي تفاصيل موعدك قبل التأكيد")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(VitalaTheme.Colors.navy)

                summaryRow(
                    "العيادة",
                    viewModel.clinic.name
                )

                summaryRow(
                    "الخدمة",
                    viewModel.selectedService ?? ""
                )

                summaryRow(
                    "التاريخ",
                    viewModel.formattedDate(viewModel.selectedDate)
                )

                summaryRow(
                    "الوقت",
                    viewModel.selectedTime?.time ?? ""
                )

                summaryRow(
                    "الموقع",
                    viewModel.clinic.address
                )

                Spacer()

                Button {

                    showBookingSummary = false
                    viewModel.confirmBooking()

                } label: {

                    Text("تأكيد الحجز")
                        .font(.system(size: 16, weight: .bold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 17)
                        .foregroundStyle(.white)
                        .background(VitalaTheme.Colors.navy)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .buttonStyle(.plain)
            }
            .padding(20)
            .navigationTitle("تأكيد الحجز")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                ToolbarItem(placement: .topBarLeading) {

                    Button("رجوع") {
                        showBookingSummary = false
                    }
                }
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    // MARK: - Helpers

    private func sectionTitle(_ title: String) -> some View {

        Text(title)
            .font(.system(size: 18, weight: .bold))
            .foregroundStyle(VitalaTheme.Colors.navy)
    }

    private func summaryRow(
        _ title: String,
        _ value: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 6) {

            Text(title)
                .font(.system(size: 12))
                .foregroundStyle(VitalaTheme.Colors.muted)

            Text(value)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(VitalaTheme.Colors.navy)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    BookingView(
        clinic: MockNearbyClinicsRepository()
            .fetchClinics()[0]
    )
}

