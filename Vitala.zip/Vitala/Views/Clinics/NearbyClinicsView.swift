//
//  NearbyClinicsView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI
import MapKit

struct NearbyClinicsView: View {

    @StateObject private var viewModel =
        NearbyClinicsViewModel()
    @State private var showMyAppointments = false

    @Environment(\.dismiss) private var dismiss

    @State private var cameraPosition: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(
                latitude: 21.5433,
                longitude: 39.1728
            ),
            span: MKCoordinateSpan(
                latitudeDelta: 0.20,
                longitudeDelta: 0.20
            )
        )
    )

    @State private var selectedClinic: NearbyClinic?

    var body: some View {

        NavigationStack {

            VStack(spacing: 0) {

                ScrollView {

                    VStack(alignment: .leading, spacing: 18) {

                        heading

                        searchField

                        locationButton

                        modeSelector

                        if viewModel.filteredClinics.isEmpty {

                            ContentUnavailableView.search(
                                text: viewModel.searchText
                            )

                        } else if viewModel.selectedMode == .list {

                            VStack(spacing: 12) {

                                ForEach(viewModel.filteredClinics) { clinic in

                                    Button {
                                        selectedClinic = clinic
                                    } label: {
                                        clinicCard(clinic)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }

                        } else {

                            clinicMap
                        }
                    }
                    .frame(
                        maxWidth: .infinity,
                        alignment: .leading
                    )
                    .padding(20)
                }
            }
            .background(VitalaTheme.Colors.background)
            .navigationTitle("العيادات")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showMyAppointments = true
                    } label: {
                        Label("مواعيدي", systemImage: "calendar")
                    }
                    .foregroundStyle(VitalaTheme.Colors.navy)
                }
                
                ToolbarItem(placement: .topBarLeading) {

                    Button("إغلاق") {
                        dismiss()
                    }
                    .foregroundStyle(VitalaTheme.Colors.navy)
                }
            }
            
            .sheet(item: $selectedClinic) { clinic in
                ClinicDetailsView(clinic: clinic)
                    .presentationDragIndicator(.visible)
            }
            
            .sheet(isPresented: $showMyAppointments) {
                MyAppointmentsView()
            }

            .alert(
                "الموقع",
                isPresented: Binding(
                    get: {
                        viewModel.locationMessage != nil
                    },
                    set: {
                        if !$0 {
                            viewModel.locationMessage = nil
                        }
                    }
                )
            ) {

                Button("حسنًا", role: .cancel) {
                    viewModel.locationMessage = nil
                }

            } message: {

                Text(viewModel.locationMessage ?? "")
            }
            .onChange(of: viewModel.userLocation?.latitude) { _, _ in
                centerOnUser()
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    // MARK: - Heading

    private var heading: some View {

        VStack(alignment: .leading, spacing: 6) {

            Text("ابحث عن عيادتك")
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            Text("استكشف العيادات التي توفر الفحوصات المناسبة لك.")
                .font(.system(size: 14))
                .foregroundStyle(VitalaTheme.Colors.muted)
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
    }

    // MARK: - Search

    private var searchField: some View {

        HStack(spacing: 10) {

            Image(systemName: "magnifyingglass")
                .foregroundStyle(VitalaTheme.Colors.muted)

            TextField(
                "اسم العيادة أو المدينة أو الحي",
                text: $viewModel.searchText
            )
            .font(.system(size: 15))
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()

            if !viewModel.searchText.isEmpty {

                Button {
                    viewModel.searchText = ""
                } label: {

                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(VitalaTheme.Colors.muted)
                }
            }
        }
        .padding(15)
        .background(.white)
        .clipShape(
            RoundedRectangle(cornerRadius: 17)
        )
        .overlay {

            RoundedRectangle(cornerRadius: 17)
                .stroke(
                    VitalaTheme.Colors.border,
                    lineWidth: 1
                )
        }
    }

    // MARK: - Location

    private var locationButton: some View {

        Button {
            viewModel.requestLocation()
        } label: {

            HStack(spacing: 9) {

                Image(systemName: "location.circle.fill")
                    .font(.system(size: 19))

                Text(
                    viewModel.userLocation == nil
                    ? "استخدام موقعي الحالي"
                    : "تم تحديد موقعك — تحديث الموقع"
                )
                .font(.system(size: 14, weight: .medium))

                Spacer()

                Image(systemName: "chevron.left")
            }
            .foregroundStyle(VitalaTheme.Colors.green)
        }
        .buttonStyle(.plain)
    }

    // MARK: - List / Map Selector

    private var modeSelector: some View {

        HStack(spacing: 10) {

            modeButton(.list, icon: "list.bullet")

            modeButton(.map, icon: "map")
        }
    }

    private func modeButton(
        _ mode: NearbyClinicsViewModel.DisplayMode,
        icon: String
    ) -> some View {

        Button {

            viewModel.selectedMode = mode

            if mode == .map {
                centerMapOnResults()
            }

        } label: {

            HStack(spacing: 7) {

                Image(systemName: icon)

                Text(mode.rawValue)
            }
            .font(.system(size: 14, weight: .semibold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .foregroundStyle(
                viewModel.selectedMode == mode
                ? .white
                : VitalaTheme.Colors.navy
            )
            .background(
                viewModel.selectedMode == mode
                ? VitalaTheme.Colors.navy
                : .white
            )
            .clipShape(
                RoundedRectangle(cornerRadius: 14)
            )
            .overlay {

                RoundedRectangle(cornerRadius: 14)
                    .stroke(
                        VitalaTheme.Colors.border,
                        lineWidth: 1
                    )
            }
        }
        .buttonStyle(.plain)
    }

    // MARK: - Clinic Card

    private func clinicCard(
        _ clinic: NearbyClinic
    ) -> some View {

        VStack(alignment: .leading, spacing: 12) {

            HStack(alignment: .top) {

                VStack(alignment: .leading, spacing: 5) {

                    Text(clinic.name)
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(VitalaTheme.Colors.navy)

                    Text("\(clinic.district)، \(clinic.city)")
                        .font(.system(size: 13))
                        .foregroundStyle(VitalaTheme.Colors.muted)
                }

                Spacer(minLength: 8)

                if let rating = clinic.rating {

                    Label(
                        String(format: "%.1f", rating),
                        systemImage: "star.fill"
                    )
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(VitalaTheme.Colors.green)
                }
            }

            if let distance = viewModel.distanceText(for: clinic) {

                Label(
                    distance,
                    systemImage: "location"
                )
                .font(.system(size: 12))
                .foregroundStyle(VitalaTheme.Colors.muted)
            }

            Label(
                clinic.workingHours,
                systemImage: "clock"
            )
            .font(.system(size: 12))
            .foregroundStyle(VitalaTheme.Colors.muted)

            Text(clinic.services.joined(separator: "  •  "))
                .font(.system(size: 12))
                .foregroundStyle(VitalaTheme.Colors.green)
                .fixedSize(
                    horizontal: false,
                    vertical: true
                )

            Divider()

            HStack {

                Text("عرض التفاصيل")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(VitalaTheme.Colors.navy)

                Spacer()

                Image(systemName: "chevron.left")
                    .foregroundStyle(VitalaTheme.Colors.muted)
            }
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )
        .padding(17)
        .background(.white)
        .clipShape(
            RoundedRectangle(cornerRadius: 20)
        )
        .overlay {

            RoundedRectangle(cornerRadius: 20)
                .stroke(
                    VitalaTheme.Colors.border,
                    lineWidth: 1
                )
        }
    }

    // MARK: - Map

    private var clinicMap: some View {

        Map(position: $cameraPosition) {

            ForEach(viewModel.filteredClinics) { clinic in

                Annotation(
                    clinic.name,
                    coordinate: clinic.coordinate
                ) {

                    Button {
                        selectedClinic = clinic
                    } label: {

                        Image(systemName: "cross.case.fill")
                            .font(.system(size: 18))
                            .foregroundStyle(.white)
                            .padding(11)
                            .background(VitalaTheme.Colors.navy)
                            .clipShape(Circle())
                    }
                    .buttonStyle(.plain)
                }
            }

            if let location = viewModel.userLocation {

                Annotation(
                    "موقعي",
                    coordinate: location
                ) {

                    Image(systemName: "location.circle.fill")
                        .font(.system(size: 27))
                        .foregroundStyle(.blue)
                }
            }
        }
        .mapControls {

            MapCompass()

            MapScaleView()
        }
        .frame(height: 420)
        .clipShape(
            RoundedRectangle(cornerRadius: 20)
        )
        .overlay {

            RoundedRectangle(cornerRadius: 20)
                .stroke(
                    VitalaTheme.Colors.border,
                    lineWidth: 1
                )
        }
        .onChange(of: viewModel.searchText) { _, _ in
            centerMapOnResults()
        }
    }

    // MARK: - Map Camera

    private func centerOnUser() {

        guard let location = viewModel.userLocation else {
            return
        }

        cameraPosition = .region(
            MKCoordinateRegion(
                center: location,
                span: MKCoordinateSpan(
                    latitudeDelta: 0.15,
                    longitudeDelta: 0.15
                )
            )
        )
    }

    private func centerMapOnResults() {

        guard !viewModel.filteredClinics.isEmpty else {
            return
        }

        let clinics = viewModel.filteredClinics

        let latitudes = clinics.map(\.latitude)
        let longitudes = clinics.map(\.longitude)

        guard
            let minLat = latitudes.min(),
            let maxLat = latitudes.max(),
            let minLon = longitudes.min(),
            let maxLon = longitudes.max()
        else {
            return
        }

        cameraPosition = .region(
            MKCoordinateRegion(
                center: CLLocationCoordinate2D(
                    latitude: (minLat + maxLat) / 2,
                    longitude: (minLon + maxLon) / 2
                ),
                span: MKCoordinateSpan(
                    latitudeDelta: max(
                        0.03,
                        (maxLat - minLat) * 1.5
                    ),
                    longitudeDelta: max(
                        0.03,
                        (maxLon - minLon) * 1.5
                    )
                )
            )
        )
    }

    
}

#Preview {
    NearbyClinicsView()
}
