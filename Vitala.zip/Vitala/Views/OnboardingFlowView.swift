//
//  OnboardingFlowView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import SwiftUI

struct OnboardingFlowView: View {

    let container: AppContainer

    @ObservedObject private var router: OnboardingRouter

    init(container: AppContainer) {

        self.container = container
        self.router = container.router

    }

    var body: some View {

        NavigationStack(path: $router.path) {

            WelcomeView(
                viewModel: container.makeWelcomeViewModel()
            )
            .navigationDestination(
                for: OnboardingRoute.self
            ) { route in

                switch route {

                case .auth(let mode):

                    AuthView(
                        viewModel: container.makeAuthViewModel(
                            mode: mode
                        )
                    )

                case .basicInfo:

                    BasicInfoView(
                        viewModel: container.makeBasicInfoViewModel()
                    )

                case .healthHistory:

                    HealthHistoryView(
                        viewModel: container.makeHealthHistoryViewModel()
                    )

                case .wearableLink:

                    WearableLinkView(
                        viewModel: container.makeWearableLinkViewModel()
                    )

                case .setupComplete:

                    SetupCompleteView {
                        container.router.push(.patientApp)
                    }

                case .patientApp:

                    MainTabView(
                        repository: container.repository,
                        onLogout: {
                            container.router.popToRoot()
                        }
                    )

                }

            }

        }
        .tint(VitalaTheme.Colors.navy)

    }

}

// MARK: - Preview

#Preview("التدفق كامل") {

    OnboardingFlowView(
        container: AppContainer()
    )
    .environment(
        \.layoutDirection,
        .rightToLeft
    )
    .environment(
        \.locale,
        Locale(identifier: "ar")
    )

}
