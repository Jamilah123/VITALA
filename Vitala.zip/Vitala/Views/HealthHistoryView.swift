//
//  HealthHistoryView..swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//




import SwiftUI

struct HealthHistoryView: View {

    @StateObject private var viewModel: HealthHistoryViewModel

    // MARK: - Custom Conditions

    @State private var customConditions: [String] = []
    @State private var customFamilyHistory: [String] = []

    @State private var newCondition = ""
    @State private var newFamilyCondition = ""

    @State private var showConditionInput = false
    @State private var showFamilyInput = false

    @Environment(\.dismiss) private var dismiss

    private let openedFromHealthRecord: Bool
    private let onFinishEditing: (() -> Void)?

    init(
        viewModel: HealthHistoryViewModel,
        openedFromHealthRecord: Bool = false,
        onFinishEditing: (() -> Void)? = nil
    ) {
        self.openedFromHealthRecord = openedFromHealthRecord
        self.onFinishEditing = onFinishEditing
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {

        VStack(spacing: 0) {

            VitalaHeader(
                title: "التاريخ الصحي",
                showsBack: true
            ) {
                handleBack()
            }

            ScrollView {

                VStack(spacing: 20) {

                    StepProgressBar(currentStep: 2)

                    ScreenTitle(
                        title: "التاريخ الصحي",
                        subtitle: "اختار ما ينطبق عليك يمكنك التعديل لاحقاً"
                    )

                    // MARK: - Diagnosed Conditions

                    section("حالات مشخصة") {

                        VStack(alignment: .leading, spacing: 12) {

                            ChipsFlow(
                                items: DiagnosedCondition.allCases,
                                title: \.title,
                                isSelected: {
                                    viewModel.conditions.contains($0)
                                },
                                onTap: {
                                    viewModel.toggle($0)
                                }
                            )

                            if viewModel.conditions.contains(.diabetes) {

                                diabetesTypePicker(
                                    title: "ما نوع السكري لديك؟",
                                    selection: $viewModel.diabetesType
                                )

                            }

                            customItems(
                                customConditions,
                                onDelete: { item in
                                    customConditions.removeAll {
                                        $0 == item
                                    }
                                }
                            )

                            addCustomField(
                                title: "إضافة حالة أخرى",
                                placeholder: "اكتبي اسم الحالة المرضية",
                                isExpanded: $showConditionInput,
                                text: $newCondition
                            ) {
                                addCondition()
                            }

                        }

                    }

                    // MARK: - Family History

                    section("تاريخ العائلة") {

                        VStack(alignment: .leading, spacing: 12) {

                            ChipsFlow(
                                items: FamilyHistoryItem.allCases,
                                title: \.title,
                                isSelected: {
                                    viewModel.familyHistory.contains($0)
                                },
                                onTap: {
                                    viewModel.toggle($0)
                                }
                            )

                            if viewModel.familyHistory.contains(.diabetes) {

                                diabetesTypePicker(
                                    title: "ما نوع السكري الموجود في العائلة؟",
                                    selection: $viewModel.familyDiabetesType
                                )

                            }

                            customItems(
                                customFamilyHistory,
                                onDelete: { item in
                                    customFamilyHistory.removeAll {
                                        $0 == item
                                    }
                                }
                            )

                            addCustomField(
                                title: "إضافة مرض عائلي",
                                placeholder: "اكتبي اسم المرض في العائلة",
                                isExpanded: $showFamilyInput,
                                text: $newFamilyCondition
                            ) {
                                addFamilyCondition()
                            }

                        }

                    }

                    // MARK: - Smoking Status

                    section("حالة التدخين") {

                        VStack(alignment: .leading, spacing: 12) {

                            Text("هل تدخن حاليًا أو سبق لك التدخين؟")
                                .font(.system(size: 14))
                                .foregroundStyle(
                                    VitalaTheme.Colors.muted
                                )

                            VStack(spacing: 10) {

                                ForEach(SmokingStatus.allCases) { status in

                                    Button {

                                        viewModel.smokingStatus = status

                                    } label: {

                                        HStack(spacing: 12) {

                                            Image(
                                                systemName:
                                                    viewModel.smokingStatus == status
                                                    ? "largecircle.fill.circle"
                                                    : "circle"
                                            )
                                            .font(.system(size: 20))
                                            .foregroundStyle(
                                                VitalaTheme.Colors.navy
                                            )

                                            Text(status.title)
                                                .font(.system(size: 15))
                                                .foregroundStyle(
                                                    VitalaTheme.Colors.navy
                                                )

                                            Spacer()

                                        }
                                        .padding(.horizontal, 16)
                                        .frame(minHeight: 52)
                                        .background(
                                            viewModel.smokingStatus == status
                                            ? VitalaTheme.Colors.navy.opacity(0.05)
                                            : Color.clear,
                                            in: RoundedRectangle(
                                                cornerRadius: 12
                                            )
                                        )
                                        .overlay {

                                            RoundedRectangle(
                                                cornerRadius: 12
                                            )
                                            .stroke(
                                                VitalaTheme.Colors.border,
                                                lineWidth: 1
                                            )

                                        }

                                    }
                                    .buttonStyle(.plain)

                                }

                            }

                        }

                    }

                    // MARK: - Current Medications

                    section("الأدوية الحالية") {

                        VStack(spacing: 10) {

                            ForEach(viewModel.medications) { medication in

                                MedicationRow(medication: medication) {
                                    viewModel.removeMedication(medication)
                                }

                            }

                            addMedicationButton

                        }

                    }

                }
                .padding(.horizontal, 20)
                .padding(.bottom, 16)

            }
            .scrollDismissesKeyboard(.interactively)

            // MARK: - Navigation Buttons

            HStack(spacing: 12) {

                SecondaryButton(title: "رجوع") {
                    handleBack()
                }

                PrimaryButton(
                    title: openedFromHealthRecord ? "حفظ" : "التالي"
                ) {
                    handleNext()
                }

            }
            .padding(.horizontal, 20)
            .padding(.bottom, 16)

        }
        .background(VitalaTheme.Colors.background)

        #if os(iOS)
        .toolbar(.hidden, for: .navigationBar)
        #endif

        .sheet(isPresented: $viewModel.isAddingMedication) {

            AddMedicationSheet { name, frequency in

                viewModel.addMedication(
                    name: name,
                    frequency: frequency
                )

            }
            .presentationDetents([.medium])

        }
        .environment(\.layoutDirection, .rightToLeft)

    }

    // MARK: - Diabetes Type

    private func diabetesTypePicker(
        title: String,
        selection: Binding<DiabetesType?>
    ) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            Text(title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            Menu {

                ForEach(DiabetesType.allCases) { type in

                    Button {

                        selection.wrappedValue = type

                    } label: {

                        if selection.wrappedValue == type {
                            Label(type.title, systemImage: "checkmark")
                        } else {
                            Text(type.title)
                        }

                    }

                }

            } label: {

                HStack(spacing: 10) {

                    Text(
                        selection.wrappedValue?.title
                        ?? "حددي نوع السكري"
                    )
                    .font(.system(size: 15))
                    .foregroundStyle(
                        selection.wrappedValue == nil
                        ? VitalaTheme.Colors.muted
                        : VitalaTheme.Colors.navy
                    )

                    Spacer()

                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(
                            VitalaTheme.Colors.muted
                        )

                }
                .padding(.horizontal, 16)
                .frame(height: 52)
                .overlay {

                    RoundedRectangle(
                        cornerRadius: VitalaTheme.Radius.card
                    )
                    .stroke(
                        VitalaTheme.Colors.border,
                        lineWidth: 1
                    )

                }

            }

        }

    }

    // MARK: - Navigation

    private func handleBack() {

        if openedFromHealthRecord {
            dismiss()
        } else {
            viewModel.backTapped()
        }

    }

    private func handleNext() {

        if openedFromHealthRecord {

            viewModel.saveHistory()

            if let onFinishEditing {
                onFinishEditing()
            } else {
                dismiss()
            }

        } else {

            viewModel.nextTapped()

        }

    }

    // MARK: - Sections

    private func section<Content: View>(
        _ title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            Text(title)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            content()

        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading
        )

    }

    // MARK: - Custom Input Field

    private func addCustomField(
        title: String,
        placeholder: String,
        isExpanded: Binding<Bool>,
        text: Binding<String>,
        onAdd: @escaping () -> Void
    ) -> some View {

        VStack(spacing: 10) {

            if isExpanded.wrappedValue {

                HStack(spacing: 10) {

                    TextField(
                        placeholder,
                        text: text
                    )
                    .font(.system(size: 15))
                    .foregroundStyle(VitalaTheme.Colors.navy)
                    .submitLabel(.done)
                    .onSubmit {
                        onAdd()
                    }

                    Button(action: onAdd) {

                        Image(systemName: "checkmark")
                            .font(.system(
                                size: 15,
                                weight: .bold
                            ))
                            .foregroundStyle(.white)
                            .frame(width: 36, height: 36)
                            .background(
                                VitalaTheme.Colors.navy,
                                in: RoundedRectangle(cornerRadius: 10)
                            )

                    }
                    .buttonStyle(.plain)

                    Button {

                        text.wrappedValue = ""
                        isExpanded.wrappedValue = false

                    } label: {

                        Image(systemName: "xmark")
                            .font(.system(size: 14))
                            .foregroundStyle(
                                VitalaTheme.Colors.muted
                            )

                    }
                    .buttonStyle(.plain)

                }
                .padding(.horizontal, 14)
                .frame(height: 56)
                .overlay {

                    RoundedRectangle(
                        cornerRadius: VitalaTheme.Radius.card
                    )
                    .stroke(
                        VitalaTheme.Colors.border,
                        lineWidth: 1
                    )

                }

            } else {

                Button {

                    isExpanded.wrappedValue = true

                } label: {

                    HStack(spacing: 8) {

                        Image(systemName: "plus")
                            .font(.system(
                                size: 14,
                                weight: .semibold
                            ))

                        Text(title)
                            .font(.system(
                                size: 15,
                                weight: .semibold
                            ))

                        Spacer()

                    }
                    .foregroundStyle(VitalaTheme.Colors.muted)
                    .padding(.horizontal, 18)
                    .frame(height: 56)
                    .overlay {

                        RoundedRectangle(
                            cornerRadius: VitalaTheme.Radius.card
                        )
                        .stroke(
                            VitalaTheme.Colors.border,
                            lineWidth: 1
                        )

                    }

                }
                .buttonStyle(.plain)

            }

        }

    }

    // MARK: - Custom Added Items

    private func customItems(
        _ items: [String],
        onDelete: @escaping (String) -> Void
    ) -> some View {

        VStack(spacing: 8) {

            ForEach(items, id: \.self) { item in

                HStack(spacing: 10) {

                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(
                            VitalaTheme.Colors.navy
                        )

                    Text(item)
                        .font(.system(size: 15))
                        .foregroundStyle(
                            VitalaTheme.Colors.navy
                        )

                    Spacer()

                    Button {
                        onDelete(item)
                    } label: {

                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(
                                VitalaTheme.Colors.muted
                            )

                    }
                    .buttonStyle(.plain)

                }
                .padding(.horizontal, 16)
                .frame(minHeight: 46)
                .background(
                    VitalaTheme.Colors.navy.opacity(0.05),
                    in: RoundedRectangle(cornerRadius: 12)
                )

            }

        }

    }

    // MARK: - Add Custom Condition

    private func addCondition() {

        let value = newCondition.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !value.isEmpty else {
            return
        }

        guard !customConditions.contains(value) else {
            newCondition = ""
            showConditionInput = false
            return
        }

        customConditions.append(value)

        newCondition = ""
        showConditionInput = false

    }

    // MARK: - Add Family Condition

    private func addFamilyCondition() {

        let value = newFamilyCondition.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !value.isEmpty else {
            return
        }

        guard !customFamilyHistory.contains(value) else {
            newFamilyCondition = ""
            showFamilyInput = false
            return
        }

        customFamilyHistory.append(value)

        newFamilyCondition = ""
        showFamilyInput = false

    }

    // MARK: - Add Medication Button

    private var addMedicationButton: some View {

        Button {

            viewModel.isAddingMedication = true

        } label: {

            HStack {

                Text("+ إضافة دواء")
                    .font(.system(
                        size: 15,
                        weight: .semibold
                    ))
                    .foregroundStyle(
                        VitalaTheme.Colors.muted
                    )

                Spacer()

            }
            .padding(.horizontal, 18)
            .frame(height: 56)
            .overlay {

                RoundedRectangle(
                    cornerRadius: VitalaTheme.Radius.card
                )
                .stroke(
                    VitalaTheme.Colors.border,
                    lineWidth: 1
                )

            }

        }
        .buttonStyle(.plain)

    }

}

// MARK: - Medication Row

private struct MedicationRow: View {

    let medication: Medication
    let onDelete: () -> Void

    var body: some View {

        HStack(spacing: 10) {

            Text(medication.name)
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(
                    VitalaTheme.Colors.navy
                )

            Spacer()

            if !medication.frequency.isEmpty {

                Text(medication.frequency)
                    .font(.system(size: 14))
                    .foregroundStyle(
                        VitalaTheme.Colors.muted
                    )

            }

            Button(action: onDelete) {

                Image(systemName: "xmark.circle.fill")
                    .foregroundStyle(
                        VitalaTheme.Colors.border
                    )

            }
            .accessibilityLabel("حذف الدواء")

        }
        .padding(.horizontal, 18)
        .frame(minHeight: 56)
        .overlay {

            RoundedRectangle(
                cornerRadius: VitalaTheme.Radius.card
            )
            .stroke(
                VitalaTheme.Colors.border,
                lineWidth: 1
            )

        }

    }

}

// MARK: - Add Medication Sheet

private struct AddMedicationSheet: View {

    let onAdd: (String, String) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var frequency = ""

    var body: some View {

        VStack(spacing: 14) {

            Text("إضافة دواء")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(
                    VitalaTheme.Colors.navy
                )
                .padding(.top, 20)

            FieldRow(title: "اسم الدواء") {

                TextField(
                    "ميتفورمين 500 ملغ",
                    text: $name
                )
                .multilineTextAlignment(.leading)

            }

            FieldRow(title: "عدد المرات") {

                TextField(
                    "مرتين يومياً",
                    text: $frequency
                )
                .multilineTextAlignment(.leading)

            }

            Spacer()

            PrimaryButton(
                title: "إضافة",
                isEnabled: !name.trimmingCharacters(
                    in: .whitespaces
                ).isEmpty
            ) {

                onAdd(name, frequency)
                dismiss()

            }

        }
        .padding(.horizontal, 20)
        .padding(.bottom, 20)
        .environment(\.layoutDirection, .rightToLeft)

    }

}

// MARK: - Previews

#Preview("فارغ") {

    HealthHistoryView(
        viewModel: AppContainer()
            .makeHealthHistoryViewModel()
    )
    .environment(
        \.layoutDirection,
        LayoutDirection.rightToLeft
    )
    .environment(
        \.locale,
        Foundation.Locale(identifier: "ar")
    )

}

#Preview("ببيانات وهمية") {

    let container = AppContainer(
        repository: InMemoryProfileRepository(
            draft: MockData.patientDraft
        )
    )

    HealthHistoryView(
        viewModel: container.makeHealthHistoryViewModel()
    )
    .environment(
        \.layoutDirection,
        LayoutDirection.rightToLeft
    )
    .environment(
        \.locale,
        Foundation.Locale(identifier: "ar")
    )

}
