//
//  AddCheckupResultView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI

struct AddCheckupResultView: View {
    @Environment(\.dismiss) private var dismiss

    @StateObject private var viewModel: AddCheckupResultViewModel

    init(checkupID: UUID, onSave: @escaping () -> Void) {
        _viewModel = StateObject(
            wrappedValue: AddCheckupResultViewModel(
                checkupID: checkupID
            )
        )
        self.onSave = onSave
    }

    private let onSave: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("بيانات النتيجة") {
                    TextField("النتيجة", text: $viewModel.value)
                        .keyboardType(.decimalPad)

                    TextField("الوحدة (مثال: % أو mg/dL)", text: $viewModel.unit)

                    DatePicker(
                        "تاريخ الفحص",
                        selection: $viewModel.date,
                        displayedComponents: .date
                    )
                }

                Section("ملاحظات") {
                    TextField(
                        "أضيفي ملاحظات إن وجدت",
                        text: $viewModel.notes,
                        axis: .vertical
                    )
                    .lineLimit(3...5)
                }

                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundStyle(.red)
                }

                Section {
                    Button {
                        if viewModel.save() {
                            onSave()
                            dismiss()
                        }
                    } label: {
                        Text("حفظ النتيجة")
                            .frame(maxWidth: .infinity)
                    }
                }
            }
            .navigationTitle("إضافة نتيجة")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("إلغاء") {
                        dismiss()
                    }
                }
            }
        }
    }
}



#Preview("إضافة نتيجة") {
    AddCheckupResultView(
        checkupID: UUID(),
        onSave: {
            print("تم حفظ النتيجة")
        }
    )
}
