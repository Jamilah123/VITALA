//
//  ClinicDashboardView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//



import SwiftUI

// MARK: - Clinic Destinations

enum ClinicDestination: String, Hashable {
    case patients
    case doctors
    case services
    case appointments
    case results
    case reports
    case profile
    case subscription
}

// MARK: - Clinic Dashboard

struct ClinicDashboardView: View {

    @ObservedObject private var store = ClinicStore.shared

    private let navy = VitalaTheme.Colors.navy
    private let green = VitalaTheme.Colors.green

    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {

        NavigationStack {

            ScrollView(showsIndicators: false) {

                VStack(alignment: .leading, spacing: 24) {

                    // MARK: Header

                    VStack(alignment: .leading, spacing: 8) {

                        HStack {

                            Text("لوحة التحكم")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundStyle(navy)

                            Spacer()

                            Image(systemName: "cross.case.fill")
                                .font(.system(size: 24))
                                .foregroundStyle(green)
                                .frame(width: 48, height: 48)
                                .background(
                                    Color.green.opacity(0.10),
                                    in: RoundedRectangle(
                                        cornerRadius: 15
                                    )
                                )
                        }

                        Text("مرحباً، \(store.state.profile.name)")
                            .font(
                                .system(
                                    size: 17,
                                    weight: .medium
                                )
                            )
                            .foregroundStyle(navy)

                        Text("إليك ملخص نشاط عيادتك")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    // MARK: Statistics

                    LazyVGrid(
                        columns: columns,
                        spacing: 12
                    ) {

                        metricCard(
                            title: "إجمالي المرضى",
                            value: store.state.patients.count,
                            symbol: "person.2.fill",
                            color: Color(
                                red: 0.86,
                                green: 0.93,
                                blue: 0.86
                            )
                        )

                        metricCard(
                            title: "مواعيد اليوم",
                            value: todayAppointments,
                            symbol: "calendar",
                            color: Color(
                                red: 0.87,
                                green: 0.92,
                                blue: 0.98
                            )
                        )

                        metricCard(
                            title: "الخدمات المتاحة",
                            value: activeServices,
                            symbol: "cross.vial.fill",
                            color: Color(
                                red: 0.98,
                                green: 0.92,
                                blue: 0.82
                            )
                        )

                        metricCard(
                            title: "نتائج بانتظار الرفع",
                            value: pendingResults,
                            symbol: "doc.text.fill",
                            color: Color(
                                red: 0.97,
                                green: 0.88,
                                blue: 0.91
                            )
                        )
                    }

                    // MARK: Clinic Management

                    VStack(
                        alignment: .leading,
                        spacing: 14
                    ) {

                        Text("إدارة العيادة")
                            .font(.title3.bold())
                            .foregroundStyle(navy)

                        dashboardMenu(
                            title: "قائمة المرضى",
                            subtitle: "عرض الملفات والبيانات الصحية",
                            symbol: "person.2.fill",
                            color: Color(
                                red: 0.86,
                                green: 0.93,
                                blue: 0.86
                            ),
                            destination: .patients
                        )

                        dashboardMenu(
                            title: "قائمة الأطباء",
                            subtitle: "عرض أطباء العيادة وتخصصاتهم",
                            symbol: "stethoscope",
                            color: Color(
                                red: 0.87,
                                green: 0.92,
                                blue: 0.98
                            ),
                            destination: .doctors
                        )

                        dashboardMenu(
                            title: "إدارة الخدمات",
                            subtitle: "إضافة الخدمات وتعديلها",
                            symbol: "cross.case.fill",
                            color: Color(
                                red: 0.98,
                                green: 0.92,
                                blue: 0.82
                            ),
                            destination: .services
                        )

                        dashboardMenu(
                            title: "المواعيد والتوفر",
                            subtitle: "إدارة المواعيد والأوقات المتاحة",
                            symbol: "calendar.badge.clock",
                            color: Color(
                                red: 0.92,
                                green: 0.88,
                                blue: 0.98
                            ),
                            destination: .appointments
                        )

                        dashboardMenu(
                            title: "رفع النتائج",
                            subtitle: "إضافة تقارير ونتائج المرضى",
                            symbol: "square.and.arrow.up.on.square",
                            color: Color(
                                red: 0.97,
                                green: 0.88,
                                blue: 0.91
                            ),
                            destination: .results
                        )

                        dashboardMenu(
                            title: "التقارير والإحصائيات",
                            subtitle: "متابعة أداء العيادة",
                            symbol: "chart.bar.fill",
                            color: Color(
                                red: 0.86,
                                green: 0.93,
                                blue: 0.86
                            ),
                            destination: .reports
                        )

                        dashboardMenu(
                            title: "الملف التعريفي للعيادة",
                            subtitle: "تعديل معلومات العيادة",
                            symbol: "building.2.fill",
                            color: Color(
                                red: 0.87,
                                green: 0.92,
                                blue: 0.98
                            ),
                            destination: .profile
                        )

                        dashboardMenu(
                            title: "الفوترة والاشتراك",
                            subtitle: "إدارة خطة الاشتراك والفواتير",
                            symbol: "creditcard.fill",
                            color: Color(
                                red: 0.98,
                                green: 0.92,
                                blue: 0.82
                            ),
                            destination: .subscription
                        )
                    }

                    // MARK: Logout

                    Button {
                        store.logout()
                    } label: {

                        HStack(spacing: 10) {

                            Image(
                                systemName:
                                    "rectangle.portrait.and.arrow.right"
                            )

                            Text("تسجيل الخروج")
                                .fontWeight(.semibold)
                        }
                        .font(.system(size: 16))
                        .foregroundStyle(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 17)
                        .background(
                            Color.red.opacity(0.06),
                            in: RoundedRectangle(
                                cornerRadius: 18
                            )
                        )
                        .overlay {
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(
                                    Color.red.opacity(0.15),
                                    lineWidth: 1
                                )
                        }
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 20)
                .padding(.top, 24)
                .padding(.bottom, 35)
            }
            .background(VitalaTheme.Colors.background)
            .toolbar(.hidden, for: .navigationBar)

            // MARK: Navigation

            .navigationDestination(
                for: ClinicDestination.self
            ) { destination in

                switch destination {

                case .patients:
                    ClinicPatientsView()

                case .doctors:
                    ClinicDoctorsView()

                case .services:
                    ClinicServicesView()

                case .appointments:
                    ClinicAppointmentsView()

                case .results:
                    ClinicResultsView()

                case .reports:
                    ClinicReportsView()

                case .profile:
                    ClinicProfileView()

                case .subscription:
                    ClinicSubscriptionView()
                }
            }
        }
        .environment(
            \.layoutDirection,
            .rightToLeft
        )
    }

    // MARK: - Statistics Calculations

    private var todayAppointments: Int {
        store.state.bookings.filter {
            Calendar.current.isDateInToday($0.date)
        }.count
    }

    private var activeServices: Int {
        store.state.services.filter {
            $0.isActive
        }.count
    }

    private var pendingResults: Int {

        store.state.bookings.filter { booking in

            booking.status == .completed &&

            !store.state.results.contains { result in

                result.patientID == booking.patientID &&

                result.serviceID == booking.serviceID &&

                Calendar.current.isDate(
                    result.date,
                    inSameDayAs: booking.date
                )
            }
        }.count
    }

    // MARK: - Metric Card

    private func metricCard(
        title: String,
        value: Int,
        symbol: String,
        color: Color
    ) -> some View {

        VStack(
            alignment: .leading,
            spacing: 10
        ) {

            HStack(alignment: .top, spacing: 8) {

                // Number - Right side in RTL
                
                
                Text("\(value)")
                    .font(
                        .system(
                            size: 32,
                            weight: .bold
                        )
                    )
                    .foregroundStyle(green)
                    .padding(.top, 6)

                Spacer(minLength: 4)

                // Icon - Left side in RTL

                Image(systemName: symbol)
                    .font(
                        .system(
                            size: 19,
                            weight: .medium
                        )
                    )
                    .foregroundStyle(navy)
                    .frame(
                        width: 43,
                        height: 43
                    )
                    .background(
                        color,
                        in: RoundedRectangle(
                            cornerRadius: 13
                        )
                    )
            }

            // Title closer to the top

            Text(title)
                .font(
                    .system(
                        size: 13,
                        weight: .medium
                    )
                )
                .padding(.top, 55)
                .foregroundStyle(navy)
                .lineLimit(2)
                .multilineTextAlignment(.leading)

            Spacer(minLength: 0)
        }
        .frame(
            maxWidth: .infinity,
            minHeight: 150,
            alignment: .topLeading
        )
        .padding(10)
        .background(
            Color.white,
            in: RoundedRectangle(
                cornerRadius: 20
            )
        )
        .overlay {

            RoundedRectangle(
                cornerRadius: 20
            )
            .stroke(
                VitalaTheme.Colors.border,
                lineWidth: 1
            )
        }
    }

    // MARK: - Dashboard Menu

    private func dashboardMenu(
        title: String,
        subtitle: String,
        symbol: String,
        color: Color,
        destination: ClinicDestination
    ) -> some View {

        NavigationLink(
            value: destination
        ) {

            HStack(spacing: 14) {

                Image(systemName: symbol)
                    .font(
                        .system(size: 21)
                    )
                    .foregroundStyle(navy)
                    .frame(
                        width: 50,
                        height: 50
                    )
                    .background(
                        color,
                        in: RoundedRectangle(
                            cornerRadius: 15
                        )
                    )

                VStack(
                    alignment: .leading,
                    spacing: 5
                ) {

                    Text(title)
                        .font(
                            .system(
                                size: 16,
                                weight: .semibold
                            )
                        )
                        .foregroundStyle(navy)

                    Text(subtitle)
                        .font(
                            .system(size: 12)
                        )
                        .foregroundStyle(.secondary)
                }

                Spacer(minLength: 5)

                Image(
                    systemName: "chevron.left"
                )
                .font(
                    .system(
                        size: 13,
                        weight: .semibold
                    )
                )
                .foregroundStyle(.gray)
            }
            .padding(15)
            .background(
                Color.white,
                in: RoundedRectangle(
                    cornerRadius: 20
                )
            )
            .overlay {

                RoundedRectangle(
                    cornerRadius: 20
                )
                .stroke(
                    VitalaTheme.Colors.border,
                    lineWidth: 1
                )
            }
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Preview

#Preview("لوحة تحكم العيادة") {

    ClinicDashboardView()
        .environment(
            \.layoutDirection,
            .rightToLeft
        )
}
