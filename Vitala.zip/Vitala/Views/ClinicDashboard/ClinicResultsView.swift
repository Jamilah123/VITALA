//
//  ClinicResultsView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI
import UniformTypeIdentifiers

struct ClinicResultsView: View {

    @ObservedObject private var store = ClinicStore.shared

    @State private var selectedPatientID: UUID?
    @State private var selectedServiceID: UUID?
    @State private var notes = ""

    @State private var selectedFileName: String?
    @State private var selectedFileData: Data?

    @State private var showFileImporter = false
    @State private var showSuccess = false
    @State private var showError = false

    private let navy = VitalaTheme.Colors.navy
    private let green = VitalaTheme.Colors.green

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 22) {

                header

                ClinicCard {
                    VStack(alignment: .leading, spacing: 18) {

                        sectionTitle(
                            "بيانات المريض",
                            icon: "person.crop.circle"
                        )

                        VStack(alignment: .leading, spacing: 8) {
                            Text("اختيار المريض")
                                .font(.subheadline.bold())
                                .foregroundStyle(navy)

                            Picker(
                                "اختيار المريض",
                                selection: $selectedPatientID
                            ) {
                                Text("اختاري المريض")
                                    .tag(nil as UUID?)

                                ForEach(store.state.patients) { patient in
                                    Text(patient.name)
                                        .tag(Optional(patient.id))
                                }
                            }
                            .tint(navy)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }

                        Divider()

                        VStack(alignment: .leading, spacing: 8) {
                            Text("الخدمة الطبية")
                                .font(.subheadline.bold())
                                .foregroundStyle(navy)

                            Picker(
                                "اختيار الخدمة",
                                selection: $selectedServiceID
                            ) {
                                Text("اختاري الخدمة")
                                    .tag(nil as UUID?)

                                ForEach(store.state.services) { service in
                                    Text(service.name)
                                        .tag(Optional(service.id))
                                }
                            }
                            .tint(navy)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }

                ClinicCard {
                    VStack(alignment: .leading, spacing: 16) {

                        sectionTitle(
                            "التقرير الطبي",
                            icon: "doc.text"
                        )

                        Text("ارفعي نتيجة الفحص أو التقرير الطبي للمريض")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)

                        Button {
                            showFileImporter = true
                        } label: {
                            VStack(spacing: 12) {
                                Image(
                                    systemName: selectedFileName == nil
                                        ? "square.and.arrow.up"
                                        : "doc.badge.checkmark"
                                )
                                .font(.system(size: 30))
                                .foregroundStyle(green)

                                Text(
                                    selectedFileName
                                    ?? "اضغطي لاختيار ملف"
                                )
                                .font(.subheadline.bold())
                                .foregroundStyle(navy)
                                .multilineTextAlignment(.center)

                                Text("PDF أو صورة")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 26)
                            .padding(.horizontal, 12)
                            .background(
                                Color.green.opacity(0.05),
                                in: RoundedRectangle(cornerRadius: 16)
                            )
                            .overlay {
                                RoundedRectangle(cornerRadius: 16)
                                    .strokeBorder(
                                        green.opacity(0.35),
                                        style: StrokeStyle(
                                            lineWidth: 1.5,
                                            dash: [6, 5]
                                        )
                                    )
                            }
                        }
                        .buttonStyle(.plain)

                        if selectedFileName != nil {
                            Button(role: .destructive) {
                                selectedFileName = nil
                                selectedFileData = nil
                            } label: {
                                Label(
                                    "إزالة الملف",
                                    systemImage: "trash"
                                )
                                .font(.subheadline)
                            }
                        }
                    }
                }

                ClinicCard {
                    VStack(alignment: .leading, spacing: 12) {

                        sectionTitle(
                            "ملاحظات إضافية",
                            icon: "square.and.pencil"
                        )

                        TextEditor(text: $notes)
                            .frame(minHeight: 115)
                            .padding(8)
                            .scrollContentBackground(.hidden)
                            .background(
                                VitalaTheme.Colors.background,
                                in: RoundedRectangle(cornerRadius: 12)
                            )
                            .overlay {
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(
                                        VitalaTheme.Colors.border,
                                        lineWidth: 1
                                    )
                            }
                    }
                }

                Button {
                    saveResult()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "checkmark.circle.fill")
                        Text("حفظ ورفع النتيجة")
                    }
                }
                .buttonStyle(ClinicPrimaryButton())

                Text("سيتم حفظ النتيجة ضمن بيانات العيادة التجريبية.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)

            }
            .padding(20)
        }
        .background(VitalaTheme.Colors.background)
        .navigationTitle("رفع النتائج")
        .navigationBarTitleDisplayMode(.inline)
        .fileImporter(
            isPresented: $showFileImporter,
            allowedContentTypes: [
                .pdf,
                .jpeg,
                .png,
                .heic
            ],
            allowsMultipleSelection: false
        ) { result in
            handleFileSelection(result)
        }
        .alert("تم حفظ النتيجة", isPresented: $showSuccess) {
            Button("حسنًا", role: .cancel) {}
        } message: {
            Text("تمت إضافة النتيجة إلى سجلات العيادة بنجاح.")
        }
        .alert("تعذر إكمال العملية", isPresented: $showError) {
            Button("حسنًا", role: .cancel) {}
        } message: {
            Text("تأكدي من اختيار المريض والخدمة والملف، وأن الملف قابل للقراءة.")
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {

            Text("رفع نتائج المرضى")
                .font(.system(size: 25, weight: .bold))
                .foregroundStyle(navy)

            Text("إضافة نتائج الفحوصات والتقارير الطبية")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    // MARK: - Section Title

    private func sectionTitle(
        _ title: String,
        icon: String
    ) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .foregroundStyle(green)

            Text(title)
                .font(.headline)
                .foregroundStyle(navy)
        }
    }

    // MARK: - File Selection

    private func handleFileSelection(
        _ result: Result<[URL], Error>
    ) {
        switch result {

        case .success(let urls):
            guard let url = urls.first else {
                showError = true
                return
            }

            let hasAccess = url.startAccessingSecurityScopedResource()

            defer {
                if hasAccess {
                    url.stopAccessingSecurityScopedResource()
                }
            }

            do {
                let data = try Data(contentsOf: url)

                selectedFileData = data
                selectedFileName = url.lastPathComponent
            } catch {
                showError = true
            }

        case .failure:
            showError = true
        }
    }

    // MARK: - Save Result

    private func saveResult() {

        guard let patientID = selectedPatientID,
              let serviceID = selectedServiceID,
              let fileData = selectedFileData,
              let fileName = selectedFileName else {
            showError = true
            return
        }

        let newResult = ClinicResult(
            patientID: patientID,
            serviceID: serviceID,
            notes: notes,
            fileName: fileName,
            fileData: fileData
        )

        store.addResult(newResult)

        notes = ""
        selectedPatientID = nil
        selectedServiceID = nil
        selectedFileName = nil
        selectedFileData = nil

        showSuccess = true
    }
}

#Preview("رفع نتائج المرضى") {
    NavigationStack {
        ClinicResultsView()
    }
    .environment(\.layoutDirection, .rightToLeft)
}
