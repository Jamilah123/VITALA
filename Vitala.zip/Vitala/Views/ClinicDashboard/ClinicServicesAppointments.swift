//
//  ClinicServicesAppointments.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import SwiftUI

// MARK: - Clinic Services

struct ClinicServicesView: View {

    @ObservedObject private var store = ClinicStore.shared

    @State private var newName = ""
    @State private var duration = 30

    // MARK: - Size Settings
    // قللي الرقم لتوسيع مربع الخدمات
    // 0 = أوسع، 8 = أضيق

    private let servicesSideInset: CGFloat = 4

    var body: some View {

        List {

            Section("الخدمات") {

                ForEach($store.state.services) { $service in

                    VStack(alignment: .leading, spacing: 20) {

                        TextField(
                            "اسم الخدمة",
                            text: $service.name
                        )

                        Stepper(
                            "مدة الموعد: \(service.duration) دقيقة",
                            value: $service.duration,
                            in: 10...180,
                            step: 5
                        )

                        Toggle(
                            "متاحة للحجز",
                            isOn: $service.isActive
                        )

                    }
                    .padding(.vertical, 4)
                    .listRowInsets(
                        EdgeInsets(
                            top: 8,
                            leading: 20,
                            bottom: 8,
                            trailing: 20
                        )
                    )
                }
                .onDelete {
                    store.state.services.remove(atOffsets: $0)
                }
            }

            Section("إضافة خدمة") {

                TextField(
                    "اسم الخدمة الجديدة",
                    text: $newName
                )

                Stepper(
                    "المدة: \(duration) دقيقة",
                    value: $duration,
                    in: 10...180,
                    step: 5
                )

                Button("إضافة خدمة") {

                    let trimmedName = newName.trimmingCharacters(
                        in: .whitespacesAndNewlines
                    )

                    guard !trimmedName.isEmpty else {
                        return
                    }

                    store.addService(
                        ClinicManagedService(
                            name: trimmedName,
                            duration: duration
                        )
                    )

                    newName = ""
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("إدارة الخدمات")
    }
}

// MARK: - Clinic Appointments

struct ClinicAppointmentsView: View {

    @ObservedObject private var store = ClinicStore.shared

    @State private var selected = 0
    @State private var day = Date()
    @State private var time = Date()
    @State private var duration = 30

    var body: some View {

        VStack {

            Picker("القسم", selection: $selected) {
                Text("الحجوزات").tag(0)
                Text("التوفر").tag(1)
            }
            .pickerStyle(.segmented)
            .padding()

            List {

                if selected == 0 {

                    ForEach(
                        store.state.bookings.sorted {
                            $0.date < $1.date
                        }
                    ) { booking in

                        VStack(
                            alignment: .leading,
                            spacing: 8
                        ) {

                            Text(
                                store.patient(
                                    booking.patientID
                                )?.name ?? "مريض"
                            )
                            .font(.headline)

                            Text(
                                store.service(
                                    booking.serviceID
                                )?.name ?? "خدمة"
                            )

                            Text(
                                booking.date.formatted(
                                    date: .abbreviated,
                                    time: .shortened
                                )
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)

                            Picker(
                                "حالة الحجز",
                                selection: Binding(
                                    get: {
                                        store.state.bookings.first {
                                            $0.id == booking.id
                                        }?.status ?? booking.status
                                    },
                                    set: { newStatus in
                                        store.updateBooking(
                                            booking,
                                            status: newStatus
                                        )
                                    }
                                )
                            ) {
                                ForEach(
                                    ClinicBookingStatus.allCases
                                ) { status in

                                    Text(status.rawValue)
                                        .tag(status)
                                }
                            }
                        }
                        .padding(.vertical, 5)
                    }

                } else {

                    Section("إضافة وقت متاح") {

                        DatePicker(
                            "اليوم",
                            selection: $day,
                            in: Date()...,
                            displayedComponents: .date
                        )

                        DatePicker(
                            "الوقت",
                            selection: $time,
                            displayedComponents: .hourAndMinute
                        )

                        Stepper(
                            "مدة الموعد: \(duration) دقيقة",
                            value: $duration,
                            in: 10...180,
                            step: 5
                        )

                        Button("إضافة وقت") {

                            let cal = Calendar.current

                            let date = cal.date(
                                bySettingHour: cal.component(
                                    .hour,
                                    from: time
                                ),
                                minute: cal.component(
                                    .minute,
                                    from: time
                                ),
                                second: 0,
                                of: day
                            ) ?? day

                            store.addSlot(
                                ClinicAvailability(
                                    date: day,
                                    time: date,
                                    duration: duration
                                )
                            )
                        }
                    }

                    Section("الأوقات المحددة") {

                        ForEach(
                            $store.state.availability
                        ) { $slot in

                            VStack(alignment: .leading) {

                                Text(
                                    slot.time.formatted(
                                        date: .abbreviated,
                                        time: .shortened
                                    )
                                )

                                Toggle(
                                    "مغلق / غير متاح",
                                    isOn: $slot.isClosed
                                )
                            }
                        }
                        .onDelete {
                            store.state.availability.remove(
                                atOffsets: $0
                            )
                        }
                    }
                }
            }
        }
        .navigationTitle("إدارة المواعيد")
    }
}

// MARK: - Previews

#if DEBUG

#Preview("إدارة خدمات العيادة") {
    NavigationStack {
        ClinicServicesView()
    }
    .environment(
        \.layoutDirection,
        .rightToLeft
    )
}

#Preview("المواعيد والتوفر") {
    NavigationStack {
        ClinicAppointmentsView()
    }
    .environment(
        \.layoutDirection,
        .rightToLeft
    )
}

#endif
