//
//  ClinicPeopleViews.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import SwiftUI

struct ClinicPatientsView: View {
    @ObservedObject private var store = ClinicStore.shared
    @State private var search = ""
    var body: some View {
        List {
            ForEach(store.state.patients.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) }) { patient in
                NavigationLink { ClinicPatientDetailView(patientID: patient.id) } label: {
                    VStack(alignment: .leading, spacing: 5) { Text(patient.name).font(.headline); Text("\(patient.age) سنة • \(patient.gender)").font(.caption).foregroundStyle(.secondary) }
                }
            }
        }.searchable(text: $search, prompt: "ابحث عن مريض").navigationTitle("قائمة المرضى")
    }
}
struct ClinicPatientDetailView: View {
    @ObservedObject private var store = ClinicStore.shared
    let patientID: UUID
    var body: some View {
        Group {
            if let patient = store.patient(patientID) {
                List {
                    Section("المعلومات الشخصية") {
                        line("الاسم", patient.name); line("العمر", "\(patient.age)"); line("الجنس", patient.gender)
                        line("الطول", "\(patient.height.formatted()) سم"); line("الوزن", "\(patient.weight.formatted()) كجم"); line("BMI", String(format: "%.1f", patient.bmi))
                    }
                    Section("ملخص قبل الزيارة") {
                        line("التاريخ المرضي", patient.medicalHistory); line("التاريخ العائلي", patient.familyHistory)
                        line("الأدوية الحالية", patient.medications); line("عوامل الخطورة", patient.riskFactors)
                        line("النتائج السابقة", patient.previousResults); line("الفحوصات الموصى بها", patient.recommendedScreenings)
                    }
                    Section("النتائج المرفوعة") {
                        ForEach(store.state.results.filter { $0.patientID == patientID }) { result in
                            VStack(alignment: .leading) {
                                Text(store.service(result.serviceID)?.name ?? "فحص")
                                Text(result.notes).font(.caption).foregroundStyle(.secondary)
                                if let file = result.fileName { Text(file).font(.caption2) }
                            }
                        }
                    }
                }.navigationTitle("ملف المريض")
            } else { ContentUnavailableView("المريض غير موجود", systemImage: "person.crop.circle.badge.xmark") }
        }
    }
    private func line(_ title: String, _ value: String) -> some View { HStack { Text(title).foregroundStyle(.secondary); Spacer(); Text(value).multilineTextAlignment(.trailing) } }
}
struct ClinicDoctorsView: View {
    @ObservedObject private var store = ClinicStore.shared
    @State private var name = ""
    @State private var specialty = ""
    var body: some View {
        List {
            Section("الأطباء") {
                ForEach(store.state.doctors) { doctor in
                    VStack(alignment: .leading) { Text(doctor.name); Text(doctor.specialty).font(.caption).foregroundStyle(.secondary) }
                }.onDelete { store.state.doctors.remove(atOffsets: $0) }
            }
            Section("إضافة طبيب") {
                TextField("اسم الطبيب", text: $name)
                TextField("التخصص", text: $specialty)
                Button("إضافة") { guard !name.isEmpty else { return }; store.state.doctors.append(ClinicDoctor(name: name, specialty: specialty)); name = ""; specialty = "" }
            }
        }.navigationTitle("قائمة الأطباء")
    }
}


// MARK: - Doctors List Preview

#Preview("قائمة الأطباء") {
    NavigationStack {
        ClinicDoctorsView()
    }
    .environment(\.layoutDirection, .rightToLeft)
}
