//
//  ClinicProfileSubscription.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import SwiftUI
import PhotosUI

struct ClinicProfileView: View {
    @ObservedObject private var store = ClinicStore.shared
    @State private var selectedPhoto: PhotosPickerItem?
    var body: some View {
        Form {
            Section("شعار العيادة") {
                if let data = store.state.profile.logoData, let image = UIImage(data: data) {
                    Image(uiImage: image).resizable().scaledToFit().frame(height: 90)
                }
                PhotosPicker("اختيار الشعار", selection: $selectedPhoto, matching: .images)
            }
            Section("معلومات العيادة") {
                TextField("اسم العيادة", text: $store.state.profile.name)
                TextField("الوصف", text: $store.state.profile.description)
                TextField("الموقع", text: $store.state.profile.address)
                TextField("رقم التواصل", text: $store.state.profile.phone)
                TextField("البريد الإلكتروني", text: $store.state.profile.email)
                TextField("ساعات العمل", text: $store.state.profile.workingHours)
            }
            Section { Text("تُحفظ التغييرات تلقائيًا في النسخة التجريبية.").font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle("الملف التعريفي")
        .onChange(of: selectedPhoto) { _, newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self), data.count <= 2_000_000 { store.state.profile.logoData = data }
            }
        }
    }
}
struct ClinicSubscriptionView: View {
    @ObservedObject private var store = ClinicStore.shared
    var body: some View {
        Form {
            Section("الاشتراك") {
                LabeledContent("الباقة", value: store.state.subscription.planName)
                LabeledContent("الحالة", value: store.state.subscription.isActive ? "نشط" : "غير نشط")
                LabeledContent("التجديد", value: store.state.subscription.renewalDate.formatted(date: .abbreviated, time: .omitted))
            }
            Section("الفوترة") {
                Text("إدارة المدفوعات والفواتير ستُربط بمزود دفع لاحقًا. لا توجد عمليات مالية حقيقية في هذه النسخة.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
        }.navigationTitle("Billing & Subscription")
    }
}


#if DEBUG

// MARK: - Clinic Profile Preview

#Preview("الملف التعريفي للعيادة") {
    NavigationStack {
        ClinicProfileView()
    }
    .environment(\.layoutDirection, .rightToLeft)
}

// MARK: - Billing & Subscription Preview

#Preview("الفوترة والاشتراك") {
    NavigationStack {
        ClinicSubscriptionView()
    }
    .environment(\.layoutDirection, .rightToLeft)
}

#endif
