//
//  ClinicEntryView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//



import SwiftUI

struct ClinicEntryView: View {

    @Environment(\.dismiss) private var dismiss

    @ObservedObject private var store = ClinicStore.shared

    @State private var hasLoggedIn = false

    var body: some View {

        Group {

            if store.isLoggedIn {

                ClinicDashboardView()
                    .onAppear {
                        hasLoggedIn = true
                    }

            } else {

                ClinicLoginView {
                    dismiss()
                }
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onChange(of: store.isLoggedIn) { oldValue, newValue in

            if hasLoggedIn && oldValue && !newValue {
                dismiss()
            }
        }
    }
}

// MARK: - Clinic Login

struct ClinicLoginView: View {

    @Environment(\.dismiss) private var dismiss

    @ObservedObject private var store = ClinicStore.shared

    var onBack: (() -> Void)? = nil

    @State private var name = "عيادة الأمل"
    @State private var contact = "clinic@example.com"
    @State private var password = "123456"
    @State private var error = false

    var body: some View {

        NavigationStack {

            ScrollView {

                VStack(spacing: 22) {

                    Image("SetupComplete")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)

                    Text("تسجيل دخول العيادة")
                        .foregroundStyle(.secondary)

                    VStack(alignment: .leading, spacing: 14) {

                        TextField("اسم العيادة", text: $name)
                            .textInputAutocapitalization(.never)

                        TextField(
                            "البريد الإلكتروني أو رقم الجوال",
                            text: $contact
                        )
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)

                        SecureField(
                            "كلمة المرور",
                            text: $password
                        )
                    }
                    .textFieldStyle(.roundedBorder)

                    Button("تسجيل الدخول") {

                        error = !store.login(
                            name: name,
                            contact: contact,
                            password: password
                        )
                    }
                    .buttonStyle(ClinicPrimaryButton())
                }
                .padding(24)
            }
            .background(Color.white.ignoresSafeArea())
            .navigationTitle("دخول العيادة")
            .navigationBarTitleDisplayMode(.inline)

            // MARK: - Back Button
            .toolbar {

                ToolbarItem(placement: .topBarLeading) {

                    Button {

                        if let onBack {
                            onBack()
                        } else {
                            dismiss()
                        }

                    } label: {

                        Image(systemName: "chevron.right")
                            .font(
                                .system(
                                    size: 18,
                                    weight: .semibold
                                )
                            )
                            .foregroundStyle(
                                VitalaTheme.Colors.navy
                            )
                    }
                    .accessibilityLabel("رجوع")
                }
            }
            .alert(
                "بيانات الدخول غير صحيحة",
                isPresented: $error
            ) {

                Button("حسنًا", role: .cancel) {}
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}

// MARK: - Primary Button

struct ClinicPrimaryButton: ButtonStyle {

    func makeBody(configuration: Configuration) -> some View {

        configuration.label
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(15)
            .foregroundStyle(.white)
            .background(VitalaTheme.Colors.navy)
            .clipShape(
                RoundedRectangle(cornerRadius: 14)
            )
            .opacity(configuration.isPressed ? 0.75 : 1)
    }
}

// MARK: - Clinic Card

struct ClinicCard<Content: View>: View {

    @ViewBuilder let content: Content

    var body: some View {

        content
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .padding(16)
            .background(.white)
            .clipShape(
                RoundedRectangle(cornerRadius: 18)
            )
            .overlay {

                RoundedRectangle(cornerRadius: 18)
                    .stroke(
                        VitalaTheme.Colors.border,
                        lineWidth: 1
                    )
            }
    }
}

// MARK: - Preview

#Preview("تسجيل دخول العيادة") {

    ClinicEntryView()
        .environment(
            \.layoutDirection,
            .rightToLeft
        )
}
