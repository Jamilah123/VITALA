//
//  ClinicResultsReports.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI

// MARK: - Reports Period

private enum ClinicReportPeriod: String, CaseIterable, Identifiable {
    case week = "الأسبوع"
    case month = "الشهر"
    case year = "السنة"

    var id: String { rawValue }

    var calendarComponent: Calendar.Component {
        switch self {
        case .week: return .weekOfYear
        case .month: return .month
        case .year: return .year
        }
    }
}

// MARK: - Clinic Reports View

struct ClinicReportsView: View {

    @ObservedObject private var store = ClinicStore.shared

    @State private var selectedPeriod: ClinicReportPeriod = .month

    private let navy = VitalaTheme.Colors.navy
    private let green = VitalaTheme.Colors.green

    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 22) {

                // MARK: Header

                VStack(alignment: .leading, spacing: 7) {
                    Text("التقارير والإحصائيات")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundStyle(navy)

                    Text("متابعة أداء العيادة وتحليل نشاطها")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                // MARK: Period Selector

                HStack(spacing: 8) {
                    ForEach(ClinicReportPeriod.allCases) { period in
                        Button {
                            selectedPeriod = period
                        } label: {
                            Text(period.rawValue)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(
                                    selectedPeriod == period ? .white : navy
                                )
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(
                                    selectedPeriod == period
                                        ? navy
                                        : Color.white,
                                    in: RoundedRectangle(cornerRadius: 13)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(5)
                .background(
                    Color.gray.opacity(0.08),
                    in: RoundedRectangle(cornerRadius: 18)
                )

                // MARK: Statistics

                Text("نظرة عامة")
                    .font(.title3.bold())
                    .foregroundStyle(navy)

                LazyVGrid(columns: columns, spacing: 12) {

                    reportMetric(
                        title: "إجمالي المرضى",
                        value: patientCount,
                        icon: "person.2.fill",
                        tint: Color(red: 0.86, green: 0.93, blue: 0.86)
                    )

                    reportMetric(
                        title: "المواعيد",
                        value: filteredBookings.count,
                        icon: "calendar",
                        tint: Color(red: 0.87, green: 0.92, blue: 0.98)
                    )

                    reportMetric(
                        title: "المكتملة",
                        value: completedCount,
                        icon: "checkmark.circle.fill",
                        tint: Color(red: 0.98, green: 0.92, blue: 0.82)
                    )

                    reportMetric(
                        title: "الملغاة",
                        value: cancelledCount,
                        icon: "xmark.circle.fill",
                        tint: Color(red: 0.97, green: 0.88, blue: 0.91)
                    )
                }

                // MARK: Booking Summary

                VStack(alignment: .leading, spacing: 16) {
                    sectionHeading(
                        "حالة المواعيد",
                        icon: "calendar.badge.clock"
                    )

                    statusRow(
                        title: "مواعيد مكتملة",
                        count: completedCount,
                        color: green
                    )

                    statusRow(
                        title: "مواعيد مجدولة",
                        count: scheduledCount,
                        color: .blue
                    )

                    statusRow(
                        title: "مواعيد ملغاة",
                        count: cancelledCount,
                        color: .orange
                    )

                    statusRow(
                        title: "لم يحضر",
                        count: noShowCount,
                        color: .red
                    )
                }
                .reportCard()

                // MARK: Most Requested Services

                VStack(alignment: .leading, spacing: 16) {
                    sectionHeading(
                        "الخدمات الأكثر طلبًا",
                        icon: "chart.bar.fill"
                    )

                    if mostRequestedServices.isEmpty {
                        emptyMessage("لا توجد حجوزات خلال الفترة المحددة")
                    } else {
                        ForEach(mostRequestedServices, id: \.id) { service in

                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text(service.name)
                                        .font(.subheadline.weight(.medium))
                                        .foregroundStyle(navy)

                                    Spacer()

                                    Text("\(service.count)")
                                        .font(.subheadline.bold())
                                        .foregroundStyle(green)
                                }

                                GeometryReader { geometry in
                                    ZStack(alignment: .leading) {
                                        Capsule()
                                            .fill(Color.gray.opacity(0.12))

                                        Capsule()
                                            .fill(green)
                                            .frame(
                                                width: geometry.size.width
                                                    * CGFloat(service.count)
                                                    / CGFloat(maxServiceCount)
                                            )
                                    }
                                }
                                .frame(height: 9)
                            }
                        }
                    }
                }
                .reportCard()

                // MARK: Results Statistics

                VStack(alignment: .leading, spacing: 16) {
                    sectionHeading(
                        "إحصائيات النتائج",
                        icon: "doc.text.fill"
                    )

                    HStack(spacing: 12) {
                        resultSummary(
                            title: "نتائج مرفوعة",
                            value: filteredResults.count,
                            icon: "doc.badge.checkmark"
                        )

                        resultSummary(
                            title: "مواعيد مكتملة دون نتيجة",
                            value: pendingResultsCount,
                            icon: "doc.badge.clock"
                        )
                    }

                    Text("النتائج المعلقة محسوبة تقديريًا من المواعيد المكتملة التي لا توجد لها نتيجة مطابقة للمريض والخدمة وتاريخ الموعد.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .reportCard()

                Text("البيانات المعروضة تجريبية، وتتغير وفق السجلات المحفوظة في العيادة.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
            }
            .padding(20)
        }
        .background(VitalaTheme.Colors.background)
        .navigationTitle("التقارير")
        .navigationBarTitleDisplayMode(.inline)
        .environment(\.layoutDirection, .rightToLeft)
    }

    // MARK: - Filtered Data

    private func isInSelectedPeriod(_ date: Date) -> Bool {
        Calendar.current.isDate(
            date,
            equalTo: Date(),
            toGranularity: selectedPeriod.calendarComponent
        )
    }

    private var filteredBookings: [ClinicBooking] {
        store.state.bookings.filter {
            isInSelectedPeriod($0.date)
        }
    }

    private var filteredResults: [ClinicResult] {
        store.state.results.filter {
            isInSelectedPeriod($0.date)
        }
    }

    // Patients do not have a registration date in the current model.
    // This count therefore represents the current total.
    private var patientCount: Int {
        store.state.patients.count
    }

    private var completedCount: Int {
        filteredBookings.filter {
            $0.status == .completed
        }.count
    }

    private var cancelledCount: Int {
        filteredBookings.filter {
            $0.status == .cancelled
        }.count
    }

    private var scheduledCount: Int {
        filteredBookings.filter {
            $0.status == .scheduled
        }.count
    }

    private var noShowCount: Int {
        filteredBookings.filter {
            $0.status == .noShow
        }.count
    }

    private var pendingResultsCount: Int {
        filteredBookings.filter { booking in
            booking.status == .completed &&
            !store.state.results.contains { result in
                result.patientID == booking.patientID &&
                result.serviceID == booking.serviceID &&
                Calendar.current.isDate(
                    result.date,
                    inSameDayAs: booking.date
                )
            }
        }.count
    }

    private struct ServiceCount: Identifiable {
        let id: UUID
        let name: String
        let count: Int
    }

    private var mostRequestedServices: [ServiceCount] {
        store.state.services.compactMap { service in
            let count = filteredBookings.filter {
                $0.serviceID == service.id
            }.count

            guard count > 0 else { return nil }

            return ServiceCount(
                id: service.id,
                name: service.name,
                count: count
            )
        }
        .sorted { $0.count > $1.count }
    }

    private var maxServiceCount: Int {
        max(mostRequestedServices.map(\.count).max() ?? 0, 1)
    }

    // MARK: - Metric Card

    private func reportMetric(
        title: String,
        value: Int,
        icon: String,
        tint: Color
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 19))
                .foregroundStyle(navy)
                .frame(width: 43, height: 43)
                .background(
                    tint,
                    in: RoundedRectangle(cornerRadius: 13)
                )

            Text("\(value)")
                .font(.system(size: 31, weight: .bold))
                .foregroundStyle(green)

            Text(title)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(navy)
                .lineLimit(2)
        }
        .frame(
            maxWidth: .infinity,
            minHeight: 140,
            alignment: .topLeading
        )
        .reportCard()
    }

    // MARK: - Section Heading

    private func sectionHeading(
        _ title: String,
        icon: String
    ) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .foregroundStyle(green)

            Text(title)
                .font(.headline)
                .foregroundStyle(navy)
        }
    }

    // MARK: - Status Row

    private func statusRow(
        title: String,
        count: Int,
        color: Color
    ) -> some View {
        VStack(spacing: 7) {
            HStack {
                HStack(spacing: 8) {
                    Circle()
                        .fill(color)
                        .frame(width: 9, height: 9)

                    Text(title)
                        .font(.subheadline)
                        .foregroundStyle(navy)
                }

                Spacer()

                Text("\(count)")
                    .font(.subheadline.bold())
                    .foregroundStyle(navy)
            }

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(Color.gray.opacity(0.10))

                    Capsule()
                        .fill(color)
                        .frame(
                            width: geometry.size.width
                                * CGFloat(count)
                                / CGFloat(max(filteredBookings.count, 1))
                        )
                }
            }
            .frame(height: 7)
        }
    }

    // MARK: - Results Summary

    private func resultSummary(
        title: String,
        value: Int,
        icon: String
    ) -> some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(green)

            Text("\(value)")
                .font(.title2.bold())
                .foregroundStyle(navy)

            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(
            VitalaTheme.Colors.background,
            in: RoundedRectangle(cornerRadius: 14)
        )
    }

    private func emptyMessage(_ message: String) -> some View {
        Text(message)
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 18)
    }
}

// MARK: - Card Styling

private struct ClinicReportCardModifier: ViewModifier {

    func body(content: Content) -> some View {
        content
            .padding(17)
            .background(
                Color.white,
                in: RoundedRectangle(cornerRadius: 20)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 20)
                    .stroke(
                        VitalaTheme.Colors.border,
                        lineWidth: 1
                    )
            }
    }
}

private extension View {
    func reportCard() -> some View {
        modifier(ClinicReportCardModifier())
    }
}

// MARK: - Preview

#Preview("تقارير العيادة") {
    NavigationStack {
        ClinicReportsView()
    }
    .environment(\.layoutDirection, .rightToLeft)
}
