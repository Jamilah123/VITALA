//
//  Untitled.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI

struct AuthView: View {

    @StateObject private var viewModel: AuthViewModel
    @State private var showPassword = false

    init(viewModel: AuthViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {

        VStack(spacing: 0) {

            VitalaHeader(
                title: viewModel.mode.title,
                showsBack: true
            ) {
                viewModel.backTapped()
            }

            ScrollView {

                VStack(spacing: 14) {

                    

                    // الاسم الكامل
                    FieldRow(title: "الاسم الكامل") {
                        TextField("الاسم الكامل", text: $viewModel.fullName)
                            .textContentType(.name)
                            .textInputAutocapitalization(.words)
                            .multilineTextAlignment(.leading)
                            .font(.system(size: 17, weight: .bold))
                            .foregroundStyle(VitalaTheme.Colors.navy)
                    }

                    // رقم الجوال: إنشاء حساب فقط
                    if viewModel.mode == .signUp {

                        FieldRow(title: "رقم الجوال") {
                            TextField("05XXXXXXXX", text: $viewModel.phone)
                                .keyboardType(.phonePad)
                                .textContentType(.telephoneNumber)
                                .multilineTextAlignment(.leading)
                                .font(.system(size: 17, weight: .bold))
                                .foregroundStyle(VitalaTheme.Colors.navy)
                        }

                        
                    }

                    // كلمة المرور
                    FieldRow(title: "كلمة المرور") {
                        HStack {
                            Group {
                                if showPassword {
                                    TextField("أدخل كلمة المرور", text: $viewModel.password)
                                } else {
                                    SecureField("أدخل كلمة المرور", text: $viewModel.password)
                                }
                            }
                            .textContentType(
                                viewModel.mode == .signUp ? .newPassword : .password
                            )
                            .textInputAutocapitalization(.never)
                            .multilineTextAlignment(.leading)
                            .font(.system(size: 17, weight: .bold))
                            .foregroundStyle(VitalaTheme.Colors.navy)

                            Button {
                                showPassword.toggle()
                            } label: {
                                Image(systemName: showPassword ? "eye" : "eye.slash")                                    .foregroundStyle(VitalaTheme.Colors.muted)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    if !viewModel.password.isEmpty &&
                        !viewModel.isPasswordValid {

                        Text("كلمة المرور يجب أن تكون 6 أحرف أو أكثر.")
                            .font(.system(size: 13))
                            .foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
            }
            .scrollDismissesKeyboard(.interactively)

            PrimaryButton(
                title: viewModel.mode == .signUp
                ? "إنشاء الحساب"
                : "تسجيل الدخول",
                isEnabled: viewModel.canSubmit
            ) {
                viewModel.submit()
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 16)
        }
        .background(VitalaTheme.Colors.background)
        .toolbar(.hidden, for: .navigationBar)
        .animation(.easeInOut(duration: 0.2), value: viewModel.mode)
        .alert(
            viewModel.alertTitle,
            isPresented: $viewModel.showAlert
        ) {
            Button("حسناً", role: .cancel) {}
        } message: {
            Text(viewModel.alertMessage)
        }
    }
}

// MARK: - Preview

#Preview("حساب جديد") {
    AuthView(
        viewModel: AppContainer().makeAuthViewModel(mode: .signUp)
    )
    .environment(\.layoutDirection, .rightToLeft)
    .environment(\.locale, Locale(identifier: "ar"))
}

#Preview("تسجيل الدخول") {
    AuthView(
        viewModel: AppContainer().makeAuthViewModel(mode: .login)
    )
    .environment(\.layoutDirection, .rightToLeft)
    .environment(\.locale, Locale(identifier: "ar"))
}
