//
//  PatientFollowUpView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import SwiftUI

struct PatientFollowUpView: View {

    @StateObject private var viewModel = PatientTabsViewModel()

    private var completed: Int { viewModel.checkups.filter { viewModel.count(for: $0) > 0 }.count }

    private var remaining: Int { max(0, viewModel.checkups.count - completed) }

    var body: some View {

        ScrollView(showsIndicators: false) {

            VStack(alignment: .leading, spacing: 20) {

                PatientTabHeading(title: "المتابعة", subtitle: "تابع فحوصاتك ونتائجك الصحية", symbol: "heart.text.square")

                HStack(spacing: 12) {

                    summaryCard("فحوصات لها نتائج", value: completed, symbol: "checkmark.circle.fill")

                    summaryCard("دون نتائج", value: remaining, symbol: "clock")

                }

                Text("متابعة الفحوصات").font(.headline).foregroundStyle(PatientTabPalette.navy)

                if viewModel.checkups.isEmpty {

                    PatientTabCard { Text("لا توجد فحوصات متاحة حاليًا").foregroundStyle(.secondary) }

                } else {

                    ForEach(viewModel.checkups, id: \.id) { checkup in

                        NavigationLink {

                            CheckupDetailsView(checkup: checkup)

                        } label: {

                            PatientTabCard {

                                HStack(spacing: 12) {

                                    Image(systemName: "cross.vial.fill")

                                        .foregroundStyle(PatientTabPalette.navy)

                                        .frame(width: 42, height: 42)

                                        .background(PatientTabPalette.ice, in: RoundedRectangle(cornerRadius: 12))

                                    VStack(alignment: .leading, spacing: 5) {

                                        Text(checkup.name).font(.subheadline.bold()).foregroundStyle(PatientTabPalette.navy)

                                        Text(checkup.category).font(.caption).foregroundStyle(.secondary)

                                        Text(viewModel.count(for: checkup) > 0 ? "توجد نتائج مسجلة" : "لم تُسجل نتائج بعد")

                                            .font(.caption).foregroundStyle(PatientTabPalette.green)

                                    }

                                    Spacer(minLength: 4)

                                    Image(systemName: "chevron.left").font(.caption).foregroundStyle(.secondary)

                                }

                            }

                        }.buttonStyle(.plain)

                    }

                }

            }

            .padding(20)

        }

        .background(Color.white.ignoresSafeArea())

        .navigationBarTitleDisplayMode(.inline)

        .environment(\.layoutDirection, .rightToLeft)

        .onAppear { viewModel.refresh() }

    }

    private func summaryCard(_ title: String, value: Int, symbol: String) -> some View {

        PatientTabCard {

            VStack(alignment: .leading, spacing: 12) {

                Image(systemName: symbol).foregroundStyle(PatientTabPalette.navy)

                Text("\(value)").font(.system(size: 29, weight: .bold)).foregroundStyle(PatientTabPalette.green)

                Text(title).font(.caption).foregroundStyle(PatientTabPalette.navy)

            }

        }

    }

}

#Preview("المتابعة") {

    PatientFollowUpView()

        .environment(\.locale, Locale(identifier: "ar"))

}
