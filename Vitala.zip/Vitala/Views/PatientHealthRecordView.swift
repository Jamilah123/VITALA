//
//  PatientHealthRecordView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//



import SwiftUI

struct PatientHealthRecordView: View {
    let repository: ProfileRepository

    init(repository: ProfileRepository = InMemoryProfileRepository()) {
        self.repository = repository
    }

    @StateObject private var viewModel = PatientTabsViewModel()
    @State private var searchText = ""

    private var filteredCheckups: [Checkup] {
        viewModel.checkups.filter {
            searchText.isEmpty ||
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.category.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                // MARK: - Header
                PatientTabHeading(
                    title: "السجل الصحي",
                    subtitle: "معلوماتك الصحية ونتائج فحوصاتك",
                    symbol: "folder.fill"
                )
                // MARK: - Personal Health Information
                Text("ملفي الصحي")
                    .font(.headline)
                    .foregroundStyle(PatientTabPalette.navy)

                NavigationLink {
                    let container = AppContainer(repository: repository)
                    BasicInfoView(
                        viewModel: container.makeBasicInfoViewModel(),
                        openedFromHealthRecord: true,
                        healthHistoryViewModel: container.makeHealthHistoryViewModel()
                    )
                } label: {
                    PatientTabCard {
                        HStack(spacing: 14) {
                            Image(systemName: "person.text.rectangle")
                                .font(.system(size: 22))
                                .foregroundStyle(PatientTabPalette.navy)
                                .frame(width: 48, height: 48)
                                .background(
                                    PatientTabPalette.ice,
                                    in: RoundedRectangle(cornerRadius: 14)
                                )
                            VStack(alignment: .leading, spacing: 6) {
                                Text("المعلومات الأساسية")
                                    .font(.subheadline.bold())
                                    .foregroundStyle(PatientTabPalette.navy)
                                Text("تاريخ الميلاد، الجنس، الطول، الوزن وBMI")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 4)
                            Image(systemName: "chevron.left")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .buttonStyle(.plain)

                // MARK: - Results Summary
                Text("نتائج الفحوصات")
                    .font(.headline)
                    .foregroundStyle(PatientTabPalette.navy)
                PatientTabCard {
                    HStack(spacing: 12) {
                        Image(systemName: "doc.text.magnifyingglass")
                            .foregroundStyle(PatientTabPalette.green)
                        Text("إجمالي النتائج المسجلة")
                            .foregroundStyle(PatientTabPalette.navy)
                        Spacer()
                        Text("\(viewModel.totalResults)")
                            .font(.title2.bold())
                            .foregroundStyle(PatientTabPalette.green)
                    }
                }

                // MARK: - Search
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("ابحثي عن فحص", text: $searchText)
                }
                .padding(14)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 15))
                .overlay {
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(VitalaTheme.Colors.border, lineWidth: 1)
                }
                Text("الفحوصات والنتائج")
                    .font(.headline)
                    .foregroundStyle(PatientTabPalette.navy)

                // MARK: - Checkups
                if filteredCheckups.isEmpty {
                    PatientTabCard {
                        Text("لا توجد فحوصات مطابقة")
                            .foregroundStyle(.secondary)
                    }
                } else {
                    ForEach(filteredCheckups, id: \.id) { checkup in
                        NavigationLink {
                            CheckupDetailsView(checkup: checkup)
                        } label: {
                            PatientTabCard {
                                HStack(spacing: 12) {
                                    Image(systemName: "doc.text")
                                        .foregroundStyle(PatientTabPalette.navy)
                                        .frame(width: 42, height: 42)
                                        .background(
                                            PatientTabPalette.ice,
                                            in: RoundedRectangle(cornerRadius: 12)
                                        )
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(checkup.name)
                                            .font(.subheadline.bold())
                                            .foregroundStyle(PatientTabPalette.navy)
                                        Text(checkup.category)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer(minLength: 5)
                                    Text("\(viewModel.count(for: checkup)) نتائج")
                                        .font(.caption)
                                        .foregroundStyle(PatientTabPalette.green)
                                    Image(systemName: "chevron.left")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(20)
        }
        .background(Color.white.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .environment(\.layoutDirection, .rightToLeft)
        .onAppear { viewModel.refresh() }
    }
}

// MARK: - Preview
#Preview("السجل الصحي") {
    PatientHealthRecordView()
        .environment(\.layoutDirection, .rightToLeft)
        .environment(\.locale, Locale(identifier: "ar"))
}
