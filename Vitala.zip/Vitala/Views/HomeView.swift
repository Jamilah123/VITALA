//
//  HomeView.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//






import SwiftUI

struct HomeView: View {

    @StateObject private var viewModel: HomeViewModel

    let openTab: (Int) -> Void

    @State private var showAI = false

    @State private var showClinics = false

    @State private var showMyAppointments = false

    @ObservedObject private var appointmentRepository = AppointmentRepository.shared

    init(

        repository: ProfileRepository,

        openTab: @escaping (Int) -> Void = { _ in }

    ) {

        _viewModel = StateObject(

            wrappedValue: HomeViewModel(repository: repository)

        )

        self.openTab = openTab

    }

    var body: some View {

        VStack(spacing: 0) {

            // MARK: - Header

            VitalaHeader(title: "الرئيسية")

            ScrollView {

                VStack(alignment: .leading, spacing: 22) {

                    greetingSection

                    healthSummarySection

                    nextScreeningSection

                    upcomingAppointmentsSection

                    screeningStatusSection

                    aiSection

                    clinicsSection

                }

                .frame(maxWidth: .infinity, alignment: .leading)

                .padding(20)

            }

        }

        .background(VitalaTheme.Colors.background)

        .environment(\.layoutDirection, .rightToLeft)

        .onAppear {

            viewModel.refreshProfile()

        }

        .sheet(isPresented: $showClinics) {

            NearbyClinicsView()

        }

        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("VitalaReturnHome"))) { _ in
            showMyAppointments = false
            showClinics = false
        }

        .sheet(isPresented: $showMyAppointments) {

            MyAppointmentsView()

        }

        .alert(

            "Vitala AI",

            isPresented: $showAI

        ) {

            Button("حسنًا", role: .cancel) {}

        } message: {

            Text("واجهة المساعد الذكي سيتم ربطها لاحقًا")

        }

    }

    // MARK: - Greeting

    private var greetingSection: some View {

        VStack(alignment: .leading, spacing: 5) {

            Text("مرحبًا، \(viewModel.patientName) ")

                .font(.system(size: 22, weight: .bold))

                .foregroundStyle(VitalaTheme.Colors.navy)

                .multilineTextAlignment(.leading)

            Text("هذه نظرة عامة على رحلتك الصحية")

                .font(.system(size: 13))

                .foregroundStyle(VitalaTheme.Colors.muted)

                .multilineTextAlignment(.leading)

        }

        .frame(maxWidth: .infinity, alignment: .leading)

    }

    // MARK: - Health Summary

    private var healthSummarySection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("ملخص ملفك الصحي")

            HStack(spacing: 12) {

                summaryCard(

                    title: "مؤشر كتلة الجسم",

                    value: viewModel.bmiText,

                    subtitle: viewModel.bmiCategory,

                    icon: "heart.text.square"

                )

                summaryCard(

                    title: "العمر",

                    value: viewModel.ageText,

                    subtitle: "بيانات الملف الصحي",

                    icon: "person.crop.circle"

                )

            }

        }

        .frame(maxWidth: .infinity, alignment: .leading)

    }

    // MARK: - Next Screening

    private var nextScreeningSection: some View {

        VStack(alignment: .leading, spacing: 13) {

            Text("خطوتك التالية")

                .font(.system(size: 14))

                .foregroundStyle(.white.opacity(0.75))

            Text(

                viewModel.nextScreening?.title ??

                "لا توجد فحوصات قادمة"

            )

            .font(.system(size: 21, weight: .bold))

            .foregroundStyle(.white)

            .multilineTextAlignment(.leading)

            if let screening = viewModel.nextScreening {

                Text(screening.date)

                    .font(.system(size: 14))

                    .foregroundStyle(.white.opacity(0.8))

            }

            Button {

                openTab(1)

            } label: {

                HStack(spacing: 8) {

                    Text("عرض تفاصيل الفحص")

                    Image(systemName: "arrow.left")

                }

                .font(.system(size: 13, weight: .semibold))

                .foregroundStyle(VitalaTheme.Colors.navy)

                .padding(.horizontal, 15)

                .padding(.vertical, 10)

                .background(.white)

                .clipShape(Capsule())

            }

            .buttonStyle(.plain)

        }

        .frame(maxWidth: .infinity, alignment: .leading)

        .padding(20)

        .background(VitalaTheme.Colors.navy)

        .clipShape(

            RoundedRectangle(cornerRadius: 24)

        )

    }

    // MARK: - Upcoming Appointments

    private var upcomingAppointments: [Appointment] {

        appointmentRepository.appointments

            .filter { $0.displayStatus == .upcoming }

            .sorted { $0.date < $1.date }

    }

    private var upcomingAppointmentsSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            HStack {

                sectionTitle("مواعيدي القادمة")

                Spacer()

                Button("عرض الكل") {

                    showMyAppointments = true

                }

                .font(.system(size: 13, weight: .semibold))

                .foregroundStyle(VitalaTheme.Colors.green)

            }

            if let appointment = upcomingAppointments.first {

                Button {

                    showMyAppointments = true

                } label: {

                    VStack(alignment: .leading, spacing: 12) {

                        HStack(spacing: 8) {

                            Text(appointment.clinicName)

                                .font(.system(size: 16, weight: .bold))

                                .foregroundStyle(VitalaTheme.Colors.navy)

                                .multilineTextAlignment(.leading)

                            Spacer(minLength: 4)

                            Text("مؤكد")

                                .font(.system(size: 11, weight: .semibold))

                                .foregroundStyle(VitalaTheme.Colors.green)

                                .padding(.horizontal, 10)

                                .padding(.vertical, 6)

                                .background(VitalaTheme.Colors.green.opacity(0.1))

                                .clipShape(Capsule())

                        }

                        appointmentDetailRow("heart.text.square", appointment.service)

                        appointmentDetailRow("calendar", appointment.formattedDate)

                        appointmentDetailRow("clock", appointment.formattedTime)

                        appointmentDetailRow("mappin", appointment.clinicAddress)

                    }

                    .frame(maxWidth: .infinity, alignment: .leading)

                    .padding(18)

                    .background(.white)

                    .clipShape(RoundedRectangle(cornerRadius: 20))

                    .overlay {

                        RoundedRectangle(cornerRadius: 20)

                            .stroke(VitalaTheme.Colors.border, lineWidth: 1)

                    }

                }

                .buttonStyle(.plain)

            } else {

                VStack(alignment: .leading, spacing: 12) {

                    Label("ليس لديك مواعيد قادمة", systemImage: "calendar")

                        .font(.system(size: 14, weight: .medium))

                        .foregroundStyle(VitalaTheme.Colors.muted)

                    Button {

                        showClinics = true

                    } label: {

                        Label("احجز موعدًا", systemImage: "plus.circle.fill")

                            .font(.system(size: 14, weight: .semibold))

                            .foregroundStyle(VitalaTheme.Colors.green)

                    }

                    .buttonStyle(.plain)

                }

                .frame(maxWidth: .infinity, alignment: .leading)

                .padding(18)

                .background(.white)

                .clipShape(RoundedRectangle(cornerRadius: 20))

                .overlay {

                    RoundedRectangle(cornerRadius: 20)

                        .stroke(VitalaTheme.Colors.border, lineWidth: 1)

                }

            }

        }

        .frame(maxWidth: .infinity, alignment: .leading)

    }

    private func appointmentDetailRow(_ icon: String, _ value: String) -> some View {

        HStack(alignment: .top, spacing: 9) {

            Image(systemName: icon)

                .foregroundStyle(VitalaTheme.Colors.green)

                .frame(width: 20)

            Text(value)

                .font(.system(size: 13))

                .foregroundStyle(VitalaTheme.Colors.muted)

                .multilineTextAlignment(.leading)

            Spacer(minLength: 0)

        }

    }

    // MARK: - Screening Status

    private var screeningStatusSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            sectionTitle("خطة الفحوصات")

            HStack(spacing: 12) {

                statusCard(

                    title: "الفحوصات القادمة",

                    count: viewModel.upcomingScreenings.count,

                    icon: "calendar",

                    color: VitalaTheme.Colors.green

                )

                statusCard(

                    title: "الفحوصات المتأخرة",

                    count: viewModel.overdueScreenings.count,

                    icon: "exclamationmark.circle",

                    color: VitalaTheme.Colors.pink

                )

            }

            if let overdue = viewModel.overdueScreenings.first {

                Button {

                    openTab(1)

                } label: {

                    HStack(spacing: 10) {

                        Image(systemName: "exclamationmark.circle.fill")

                            .foregroundStyle(VitalaTheme.Colors.pink)

                        VStack(alignment: .leading, spacing: 4) {

                            Text("يحتاج انتباهك")

                                .font(.system(size: 12))

                                .foregroundStyle(VitalaTheme.Colors.muted)

                            Text(overdue.title)

                                .font(.system(size: 15, weight: .semibold))

                                .foregroundStyle(VitalaTheme.Colors.navy)

                        }

                        Spacer()

                        Image(systemName: "chevron.left")

                            .foregroundStyle(VitalaTheme.Colors.muted)

                    }

                    .padding(16)

                    .background(.white)

                    .clipShape(

                        RoundedRectangle(cornerRadius: 18)

                    )

                    .overlay {

                        RoundedRectangle(cornerRadius: 18)

                            .stroke(

                                VitalaTheme.Colors.border,

                                lineWidth: 1

                            )

                    }

                }

                .buttonStyle(.plain)

            }

        }

        .frame(maxWidth: .infinity, alignment: .leading)

    }

    // MARK: - Weekly Goal

    // MARK: - Notifications

    // MARK: - Ask Vitala AI

    // Same design, RTL alignment corrected.

    private var aiSection: some View {

        Button {

            showAI = true

        } label: {

            HStack(spacing: 12) {

                VStack(alignment: .leading, spacing: 6) {

                    Text("اسأل Vitala")

                        .font(.system(size: 18, weight: .bold))

                        .foregroundStyle(VitalaTheme.Colors.navy)

                    Text("هل لديك سؤال عن فحوصاتك الصحية؟")

                        .font(.system(size: 13))

                        .foregroundStyle(VitalaTheme.Colors.muted)

                }

                Spacer()

                Image(systemName: "sparkles")

                    .font(.system(size: 26))

                    .foregroundStyle(VitalaTheme.Colors.navy)

            }

            .frame(maxWidth: .infinity)

            .padding(18)

            .background(VitalaTheme.Colors.background)

            .clipShape(

                RoundedRectangle(cornerRadius: 22)

            )

            .overlay {

                RoundedRectangle(cornerRadius: 22)

                    .stroke(

                        VitalaTheme.Colors.border,

                        lineWidth: 1

                    )

            }

        }

        .buttonStyle(.plain)

    }

    // MARK: - Clinics

    private var clinicsSection: some View {

        Button {

            showClinics = true

        } label: {

            HStack(spacing: 12) {

                Image(systemName: "cross.case")

                    .font(.system(size: 24))

                    .foregroundStyle(VitalaTheme.Colors.green)

                VStack(alignment: .leading, spacing: 5) {

                    Text("العيادات والمواعيد")

                        .font(.system(size: 16, weight: .bold))

                        .foregroundStyle(VitalaTheme.Colors.navy)

                    Text("البحث عن العيادات وحجز الفحوصات")

                        .font(.system(size: 12))

                        .foregroundStyle(VitalaTheme.Colors.muted)

                }

                Spacer()

                Image(systemName: "chevron.left")

                    .foregroundStyle(VitalaTheme.Colors.muted)

            }

            .padding(18)

            .background(.white)

            .clipShape(

                RoundedRectangle(cornerRadius: 20)

            )

            .overlay {

                RoundedRectangle(cornerRadius: 20)

                    .stroke(

                        VitalaTheme.Colors.border,

                        lineWidth: 1

                    )

            }

        }

        .buttonStyle(.plain)

    }

    // MARK: - Reusable Components

    private func sectionTitle(_ title: String) -> some View {

        Text(title)

            .font(.system(size: 19, weight: .bold))

            .foregroundStyle(VitalaTheme.Colors.navy)

            .frame(maxWidth: .infinity, alignment: .leading)

    }

    private func summaryCard(

        title: String,

        value: String,

        subtitle: String,

        icon: String

    ) -> some View {

        VStack(alignment: .leading, spacing: 9) {

            HStack {

                Spacer()

                Image(systemName: icon)

                    .font(.system(size: 20))

                    .foregroundStyle(VitalaTheme.Colors.green)

            }

            Text(title)

                .font(.system(size: 12))

                .foregroundStyle(VitalaTheme.Colors.muted)

                .offset(y: -30)

            Text(value)

                .font(.system(size: 21, weight: .bold))

                .foregroundStyle(VitalaTheme.Colors.navy)

                .offset(y: -30)

            Text(subtitle)

                .font(.system(size: 11))

                .foregroundStyle(VitalaTheme.Colors.muted)

                .offset(y: -30)

        }

        .frame(maxWidth: .infinity, alignment: .leading)

        .padding(15)

        .background(.white)

        .clipShape(

            RoundedRectangle(cornerRadius: 20)

        )

        .overlay {

            RoundedRectangle(cornerRadius: 20)

                .stroke(

                    VitalaTheme.Colors.border,

                    lineWidth: 1

                )

        }

    }

    private func statusCard(

        title: String,

        count: Int,

        icon: String,

        color: Color

    ) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            HStack {

                Spacer()

                Image(systemName: icon)

                    .font(.system(size: 21))

                    .foregroundStyle(color)

            }

            Text("\(count)")

                .font(.system(size: 27, weight: .bold))

                .foregroundStyle(VitalaTheme.Colors.navy)

                .offset(y: -30)

            Text(title)

                .font(.system(size: 12))

                .foregroundStyle(VitalaTheme.Colors.muted)

                .offset(y: -10)

        }

        .frame(maxWidth: .infinity, alignment: .leading)

        .padding(16)

        .background(.white)

        .clipShape(

            RoundedRectangle(cornerRadius: 20)

        )

        .overlay {

            RoundedRectangle(cornerRadius: 20)

                .stroke(

                    VitalaTheme.Colors.border,

                    lineWidth: 1

                )

        }

    }

}

#Preview {

    HomeView(

        repository: InMemoryProfileRepository()

    )

}
