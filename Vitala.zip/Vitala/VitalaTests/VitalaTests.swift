//
//  VitalaTests.swift
//  VitalaTests
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Testing

struct VitalaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
