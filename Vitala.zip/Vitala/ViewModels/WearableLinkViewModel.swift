//
//  WearableLinkViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation
import Combine

@MainActor
final class WearableLinkViewModel: ObservableObject {

    @Published var isConnecting = false
    @Published var isConnected = false
    @Published var errorMessage: String?

    @Published var activityData = HealthActivityData()

    private let healthKitService: HealthKitService
    private let router: OnboardingRouter

    init(
        healthKitService: HealthKitService,
        router: OnboardingRouter
    ) {
        self.healthKitService = healthKitService
        self.router = router
    }

    func connectHealth() {
        Task {
            await connect()
        }
    }

    private func connect() async {

        guard !isConnecting else { return }

        isConnecting = true
        errorMessage = nil

        defer {
            isConnecting = false
        }

        do {
            try await healthKitService.requestAuthorization()

            let data = try await healthKitService.fetchTodayData()

            activityData = data
            isConnected = true

        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func nextTapped() {
        router.push(.setupComplete)
    }

    func skipTapped() {
        router.push(.setupComplete)
    }

    func backTapped() {
        router.pop()
    }

    var stepsText: String {
        guard let steps = activityData.steps else {
            return "لا توجد بيانات"
        }
        return "\(steps.formatted()) خطوة"
    }

    var heartRateText: String {
        guard let rate = activityData.heartRate else {
            return "لا توجد بيانات"
        }
        return "\(Int(rate)) نبضة/دقيقة"
    }

    var sleepText: String {
        guard let hours = activityData.sleepHours else {
            return "لا توجد بيانات"
        }
        return String(format: "%.1f ساعة", hours)
    }
}
