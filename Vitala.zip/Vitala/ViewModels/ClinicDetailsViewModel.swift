//
//  ClinicDetailsViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import Foundation
import MapKit
import Combine

@MainActor
final class ClinicDetailsViewModel: ObservableObject {

    let clinic: NearbyClinic

    @Published var selectedService: String?

    init(clinic: NearbyClinic) {
        self.clinic = clinic
    }

    var mapRegion: MKCoordinateRegion {
        MKCoordinateRegion(
            center: clinic.coordinate,
            span: MKCoordinateSpan(
                latitudeDelta: 0.012,
                longitudeDelta: 0.012
            )
        )
    }

    var hasPhoneNumber: Bool {
        !clinic.phone.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).isEmpty
    }

    var phoneURL: URL? {
        let cleaned = clinic.phone.filter {
            $0.isNumber || $0 == "+"
        }

        guard !cleaned.isEmpty else {
            return nil
        }

        return URL(string: "tel:\(cleaned)")
    }

    var mapsURL: URL? {
        var components = URLComponents(
            string: "https://maps.apple.com/"
        )

        components?.queryItems = [
            URLQueryItem(
                name: "ll",
                value: "\(clinic.latitude),\(clinic.longitude)"
            ),
            URLQueryItem(
                name: "q",
                value: clinic.name
            )
        ]

        return components?.url
    }

    func selectService(_ service: String) {
        selectedService = service
    }
}
