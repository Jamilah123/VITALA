//
//  CheckupsViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation
import Combine

@MainActor
final class CheckupsViewModel: ObservableObject {

    @Published var selectedFilter = "الكل"

    @Published var checkups: [Checkup] = [

        Checkup(
            name: "فحص السكر التراكمي",
            category: "السكري",
            date: "20 نوفمبر 2026",
            status: .upcoming,
            description: "يقيس متوسط مستوى السكر في الدم خلال آخر شهرين إلى ثلاثة أشهر.",
            importance: "يساعد على متابعة التحكم بمستوى السكر وتقييم الخطة العلاجية.",
            lastResult: "غير مسجل"
        ),

        Checkup(
            name: "قياس ضغط الدم",
            category: "القلب والأوعية",
            date: "متأخر",
            status: .overdue,
            description: "يقيس ضغط الدم داخل الشرايين.",
            importance: "يساعد على متابعة صحة القلب والأوعية الدموية.",
            lastResult: "120/80"
        ),

        Checkup(
            name: "فحص الكوليسترول",
            category: "القلب والأوعية",
            date: "15 ديسمبر 2026",
            status: .upcoming,
            description: "يقيس مستويات الدهون المختلفة في الدم.",
            importance: "يساعد على تقييم عوامل خطر أمراض القلب.",
            lastResult: "غير مسجل"
        ),

        Checkup(
            name: "فحص وظائف الكلى",
            category: "الكلى",
            date: "مكتمل",
            status: .completed,
            description: "يساعد على تقييم كفاءة وظائف الكلى.",
            importance: "مهم لمتابعة صحة الكلى.",
            lastResult: "طبيعي"
        )
    ]

    let filters = ["الكل", "القادمة", "المتأخرة", "المكتملة"]

    var filteredCheckups: [Checkup] {

        switch selectedFilter {
        case "القادمة":
            return checkups.filter { $0.status == .upcoming }

        case "المتأخرة":
            return checkups.filter { $0.status == .overdue }

        case "المكتملة":
            return checkups.filter { $0.status == .completed }

        default:
            return checkups
        }
    }
}
