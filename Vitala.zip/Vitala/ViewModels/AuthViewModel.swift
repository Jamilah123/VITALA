//
//  AuthViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation
import Combine

enum AuthMode: String, CaseIterable, Hashable, Identifiable {
    case signUp, login

    var id: String { rawValue }

    var title: String {
        self == .signUp ? "حساب جديد" : "تسجيل الدخول"
    }

    var subtitle: String {
        self == .signUp
        ? "أدخل بياناتك لإنشاء حسابك"
        : "أدخل اسمك وكلمة المرور للمتابعة"
    }
}

@MainActor
final class AuthViewModel: ObservableObject {

    @Published var mode: AuthMode

    @Published var fullName: String
    @Published var phone: String
    @Published var password: String = ""

    @Published var showAlert = false
    @Published var alertTitle = ""
    @Published var alertMessage = ""

    private let repository: ProfileRepository
    private let authRepository: DemoAuthRepository
    private let router: OnboardingRouter

    init(
        mode: AuthMode,
        repository: ProfileRepository,
        authRepository: DemoAuthRepository,
        router: OnboardingRouter
    ) {
        self.mode = mode
        self.repository = repository
        self.authRepository = authRepository
        self.router = router

        self.fullName = repository.draft.fullName ?? ""
        self.phone = repository.draft.phoneNumber ?? ""
    }

    // MARK: - Validation

    private var normalizedPhone: String {
        phone.normalizedDigits.filter {
            $0.isNumber || $0 == "+"
        }
    }

    var isNameValid: Bool {
        fullName.trimmingCharacters(
            in: .whitespacesAndNewlines
        ).count >= 2
    }

    var isPhoneValid: Bool {
        normalizedPhone.range(
            of: #"^(05\d{8}|\+9665\d{8}|9665\d{8})$"#,
            options: .regularExpression
        ) != nil
    }

    var showsPhoneError: Bool {
        mode == .signUp && !phone.isEmpty && !isPhoneValid
    }

    var isPasswordValid: Bool {
        password.count >= 6
    }

    var canSubmit: Bool {
        guard isNameValid && isPasswordValid else {
            return false
        }

        if mode == .signUp {
            return isPhoneValid
        }

        return true
    }

    // MARK: - Actions

    func submit() {
        guard canSubmit else { return }

        let name = fullName.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        switch mode {

        case .signUp:

            let success = authRepository.register(
                fullName: name,
                phone: normalizedPhone,
                password: password
            )

            guard success else {
                showMessage(
                    title: "الحساب موجود",
                    message: "رقم الجوال مسجل مسبقاً. يمكنك تسجيل الدخول"
                )
                return
            }

            repository.update { draft in
                draft.fullName = name
                draft.phoneNumber = normalizedPhone
            }

            router.push(.basicInfo)

        case .login:

            guard let account = authRepository.login(
                fullName: name,
                password: password
            ) else {
                showMessage(
                    title: "تعذر تسجيل الدخول",
                    message: "الاسم أو كلمة المرور غير صحيحة"
                )
                return
            }

            repository.update { draft in
                draft.fullName = account.fullName
                draft.phoneNumber = account.phone
            }

            router.push(.basicInfo)
        }
    }

    private func showMessage(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showAlert = true
    }

    func backTapped() {
        router.pop()
    }
}
