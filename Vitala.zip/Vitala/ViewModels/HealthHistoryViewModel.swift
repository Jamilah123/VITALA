//
//  HealthHistoryViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation
import Combine

@MainActor
final class HealthHistoryViewModel: ObservableObject {

    @Published private(set) var conditions: Set<DiagnosedCondition>
    @Published private(set) var familyHistory: Set<FamilyHistoryItem>
    @Published private(set) var medications: [Medication]

    @Published var diabetesType: DiabetesType?
    @Published var familyDiabetesType: DiabetesType?
    @Published var smokingStatus: SmokingStatus?

    @Published var isAddingMedication = false

    private let repository: ProfileRepository
    private let router: OnboardingRouter

    init(repository: ProfileRepository, router: OnboardingRouter) {

        self.repository = repository
        self.router = router

        let draft = repository.draft

        self.conditions = draft.conditions
        self.familyHistory = draft.familyHistory
        self.medications = draft.medications

        self.diabetesType = draft.diabetesType
        self.familyDiabetesType = draft.familyDiabetesType
        self.smokingStatus = draft.smokingStatus
    }

    // MARK: - Conditions

    func toggle(_ condition: DiagnosedCondition) {

        if condition == .none {

            conditions = conditions.contains(.none) ? [] : [.none]

        } else {

            conditions.remove(.none)

            if conditions.contains(condition) {
                conditions.remove(condition)
            } else {
                conditions.insert(condition)
            }
        }

        if !conditions.contains(.diabetes) {
            diabetesType = nil
        }
    }

    // MARK: - Family History

    func toggle(_ item: FamilyHistoryItem) {

        if familyHistory.contains(item) {
            familyHistory.remove(item)
        } else {
            familyHistory.insert(item)
        }

        if !familyHistory.contains(.diabetes) {
            familyDiabetesType = nil
        }
    }

    // MARK: - Medications

    func addMedication(name: String, frequency: String) {

        let name = name.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !name.isEmpty else { return }

        medications.append(
            Medication(
                name: name,
                frequency: frequency.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
            )
        )
    }

    func removeMedication(_ medication: Medication) {
        medications.removeAll { $0.id == medication.id }
    }

    // MARK: - Save

    func saveHistory() {

        repository.update { draft in

            draft.conditions = conditions
            draft.familyHistory = familyHistory
            draft.medications = medications

            draft.diabetesType = conditions.contains(.diabetes)
                ? diabetesType
                : nil

            draft.familyDiabetesType = familyHistory.contains(.diabetes)
                ? familyDiabetesType
                : nil

            draft.smokingStatus = smokingStatus
        }
    }

    // MARK: - Navigation

    func nextTapped() {
        saveHistory()
        router.push(.wearableLink)
    }

    func backTapped() {
        router.pop()
    }
}

