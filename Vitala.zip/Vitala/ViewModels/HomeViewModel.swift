//
//  HomeViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import Foundation
import Combine

@MainActor
final class HomeViewModel: ObservableObject {

    // MARK: - Patient Data

    @Published private(set) var patientName = "المستخدم"
    @Published private(set) var ageText = "غير محدد"
    @Published private(set) var bmi: Double?
    @Published private(set) var healthConditions: [String] = []

    // MARK: - Mock Screening Data

    struct Screening: Identifiable {
        let id = UUID()
        let title: String
        let date: String
        let isOverdue: Bool
    }

    @Published private(set) var screenings: [Screening] = [
        Screening(
            title: "فحص السكر التراكمي",
            date: "20 نوفمبر 2026",
            isOverdue: false
        ),
        Screening(
            title: "فحص الكوليسترول",
            date: "15 ديسمبر 2026",
            isOverdue: false
        ),
        Screening(
            title: "قياس ضغط الدم",
            date: "متأخر",
            isOverdue: true
        )
    ]

    // MARK: - Mock Goals

    @Published private(set) var weeklyActivityMinutes = 98
    @Published private(set) var weeklyActivityGoal = 150

    private let repository: ProfileRepository

    init(repository: ProfileRepository) {
        self.repository = repository
        refreshProfile()
    }

    var upcomingScreenings: [Screening] {
        screenings.filter { !$0.isOverdue }
    }

    var overdueScreenings: [Screening] {
        screenings.filter { $0.isOverdue }
    }

    var nextScreening: Screening? {
        upcomingScreenings.first
    }

    var activityProgress: Double {
        guard weeklyActivityGoal > 0 else { return 0 }
        return min(
            Double(weeklyActivityMinutes) /
            Double(weeklyActivityGoal),
            1
        )
    }

    var bmiText: String {
        guard let bmi else { return "—" }
        return String(format: "%.1f", bmi)
    }

    var bmiCategory: String {
        guard let bmi else { return "غير محدد" }

        switch bmi {
        case ..<18.5:
            return "نقص الوزن"
        case ..<25:
            return "وزن طبيعي"
        case ..<30:
            return "زيادة الوزن"
        default:
            return "سمنة"
        }
    }

    // MARK: - Profile Reading

    func refreshProfile() {

        let draft = repository.draft

        if let name = stringValue(
            in: draft,
            keys: ["fullName", "name", "patientName"]
        ), !name.isEmpty {
            patientName = name
        }

        if let birthDate = dateValue(
            in: draft,
            keys: ["birthDate", "dateOfBirth", "dob"]
        ) {
            let age = Calendar.current.dateComponents(
                [.year],
                from: birthDate,
                to: Date()
            ).year ?? 0

            ageText = "\(max(0, age)) سنة"
        }

        let height = numberValue(
            in: draft,
            keys: ["heightCm", "height", "heightInCm"]
        )

        let weight = numberValue(
            in: draft,
            keys: ["weightKg", "weight", "weightInKg"]
        )

        if let height, let weight,
           height > 0, weight > 0 {

            let heightInMeters = height / 100
            bmi = weight / (heightInMeters * heightInMeters)
        } else {
            bmi = nil
        }

        healthConditions = arrayValue(
            in: draft,
            keys: [
                "conditions",
                "diagnosedConditions",
                "selectedConditions"
            ]
        )
    }

    // MARK: - Flexible Model Reading
    // Temporary until ProfileDraft fields are confirmed.

    private func property(
        in object: Any,
        keys: [String]
    ) -> Any? {

        let mirror = Mirror(reflecting: object)

        for child in mirror.children {
            guard let label = child.label else { continue }

            if keys.contains(label) {
                return unwrap(child.value)
            }
        }

        return nil
    }

    private func unwrap(_ value: Any) -> Any? {

        let mirror = Mirror(reflecting: value)

        if mirror.displayStyle == .optional {
            return mirror.children.first.map {
                $0.value
            }
        }

        return value
    }

    private func stringValue(
        in object: Any,
        keys: [String]
    ) -> String? {
        guard let value = property(in: object, keys: keys)
        else { return nil }

        return value as? String
    }

    private func dateValue(
        in object: Any,
        keys: [String]
    ) -> Date? {
        property(in: object, keys: keys) as? Date
    }

    private func numberValue(
        in object: Any,
        keys: [String]
    ) -> Double? {

        guard let value = property(in: object, keys: keys)
        else { return nil }

        if let value = value as? Double {
            return value
        }

        if let value = value as? Int {
            return Double(value)
        }

        if let value = value as? Float {
            return Double(value)
        }

        return nil
    }

    private func arrayValue(
        in object: Any,
        keys: [String]
    ) -> [String] {

        guard let value = property(in: object, keys: keys)
        else { return [] }

        let mirror = Mirror(reflecting: value)

        guard mirror.displayStyle == .collection
        else { return [] }

        return mirror.children.map {
            String(describing: $0.value)
        }
    }
}
