//
//  BookingViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//



import Foundation
import Combine

struct BookingTimeSlot: Identifiable, Hashable {
    let id: String
    let time: String
    let durationMinutes: Int
}

@MainActor
final class BookingViewModel: ObservableObject {

    let clinic: NearbyClinic

    @Published var selectedService: String?
    @Published var selectedDate: Date
    @Published var selectedTime: BookingTimeSlot?

    @Published var bookedAppointment: Appointment?
    @Published var errorMessage: String?

    let repository = AppointmentRepository.shared

    private let calendar = Calendar.current

    init(clinic: NearbyClinic) {
        self.clinic = clinic
        self.selectedService = clinic.services.first
        self.selectedDate = Calendar.current.startOfDay(for: Date())
    }

    var availableDates: [Date] {
        (0..<14).compactMap {
            calendar.date(
                byAdding: .day,
                value: $0,
                to: calendar.startOfDay(for: Date())
            )
        }
    }

    var availableTimes: [BookingTimeSlot] {

        let mockTimes = [
            "09:00", "10:30", "12:00",
            "14:00", "15:30", "17:00"
        ]

        return mockTimes.compactMap { time in

            guard let date = dateTime(
                date: selectedDate,
                time: time
            ) else {
                return nil
            }

            guard date > Date() else {
                return nil
            }

            guard repository.isAvailable(
                clinicID: clinic.id,
                date: date,
                durationMinutes: 30
            ) else {
                return nil
            }

            return BookingTimeSlot(
                id: time,
                time: time,
                durationMinutes: 30
            )
        }
    }

    var selectedDateTime: Date? {
        guard let selectedTime else {
            return nil
        }

        return dateTime(
            date: selectedDate,
            time: selectedTime.time
        )
    }

    var canContinue: Bool {
        selectedService != nil &&
        selectedTime != nil &&
        selectedDateTime != nil
    }

    func selectDate(_ date: Date) {
        selectedDate = date
        selectedTime = nil
    }

    func selectService(_ service: String) {
        selectedService = service
        selectedTime = nil
    }

    func selectTime(_ slot: BookingTimeSlot) {
        selectedTime = slot
    }

    func confirmBooking() {

        guard let service = selectedService,
              let date = selectedDateTime else {
            errorMessage = "اختاري الخدمة والتاريخ والوقت أولًا."
            return
        }

        do {
            bookedAppointment = try repository.book(
                clinic: clinic,
                service: service,
                date: date,
                durationMinutes: selectedTime?.durationMinutes ?? 30
            )
        } catch {
            errorMessage = error.localizedDescription
            selectedTime = nil
        }
    }

    func formattedDate(_ date: Date) -> String {
        date.formatted(
            .dateTime
                .weekday(.wide)
                .day()
                .month(.abbreviated)
                .locale(Locale(identifier: "ar_SA"))
        )
    }

    private func dateTime(
        date: Date,
        time: String
    ) -> Date? {

        let parts = time.split(separator: ":")

        guard parts.count == 2,
              let hour = Int(parts[0]),
              let minute = Int(parts[1]) else {
            return nil
        }

        return calendar.date(
            bySettingHour: hour,
            minute: minute,
            second: 0,
            of: date
        )
    }
}
