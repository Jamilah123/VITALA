//
//  NearbyClinicsViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import Foundation
import CoreLocation
import Combine

@MainActor
final class NearbyClinicsViewModel: NSObject,
    ObservableObject, CLLocationManagerDelegate {

    enum DisplayMode: String, CaseIterable {
        case list = "القائمة"
        case map = "الخريطة"
    }

    @Published var searchText = ""
    @Published var selectedMode: DisplayMode = .list

    @Published private(set) var clinics: [NearbyClinic] = []
    @Published private(set) var userLocation: CLLocationCoordinate2D?

    @Published var locationMessage: String?

    @Published private(set) var authorizationStatus:
        CLAuthorizationStatus = .notDetermined

    private let locationManager = CLLocationManager()

    init(
        repository: NearbyClinicsRepository =
            MockNearbyClinicsRepository()
    ) {
        super.init()

        clinics = repository.fetchClinics()

        locationManager.delegate = self
        locationManager.desiredAccuracy =
            kCLLocationAccuracyHundredMeters

        authorizationStatus =
            locationManager.authorizationStatus
    }

    // MARK: - Search

    var filteredClinics: [NearbyClinic] {

        let query = searchText.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        let matches = query.isEmpty
            ? clinics
            : clinics.filter {
                $0.searchText.localizedStandardContains(query)
            }

        guard let userLocation else {
            return matches
        }

        return matches.sorted {
            distanceInMeters(
                to: $0,
                from: userLocation
            ) < distanceInMeters(
                to: $1,
                from: userLocation
            )
        }
    }

    // MARK: - Location Permission

    var isLocationAuthorized: Bool {
        authorizationStatus == .authorizedWhenInUse ||
        authorizationStatus == .authorizedAlways
    }

    func requestLocation() {

        guard CLLocationManager.locationServicesEnabled() else {
            locationMessage =
                "خدمات الموقع مقفلة على الجهاز. يمكنك البحث باسم المدينة أو الحي."
            return
        }

        switch locationManager.authorizationStatus {

        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()

        case .authorizedAlways, .authorizedWhenInUse:
            locationManager.requestLocation()

        case .denied, .restricted:
            locationMessage =
                "لم يُسمح بالوصول للموقع. يمكنك البحث يدويًا، أو تفعيل الإذن من إعدادات الجهاز."

        @unknown default:
            locationMessage =
                "تعذّر تحديد حالة إذن الموقع. استخدمي البحث اليدوي."
        }
    }

    // MARK: - Distance

    func distanceText(
        for clinic: NearbyClinic
    ) -> String? {

        guard let userLocation else {
            return nil
        }

        let km = distanceInMeters(
            to: clinic,
            from: userLocation
        ) / 1000

        return String(format: "%.1f كم", km)
    }

    private func distanceInMeters(
        to clinic: NearbyClinic,
        from coordinate: CLLocationCoordinate2D
    ) -> CLLocationDistance {

        let origin = CLLocation(
            latitude: coordinate.latitude,
            longitude: coordinate.longitude
        )

        let destination = CLLocation(
            latitude: clinic.latitude,
            longitude: clinic.longitude
        )

        return origin.distance(from: destination)
    }

    // MARK: - CLLocationManagerDelegate

    func locationManagerDidChangeAuthorization(
        _ manager: CLLocationManager
    ) {

        authorizationStatus =
            manager.authorizationStatus

        if isLocationAuthorized {
            locationMessage = nil
            manager.requestLocation()
        }
    }

    func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {

        guard let location = locations.last else {
            return
        }

        userLocation = location.coordinate
        locationMessage = nil
    }

    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {

        if (error as? CLError)?.code == .locationUnknown {
            return
        }

        locationMessage =
            "تعذّر الحصول على الموقع حاليًا. يمكنك البحث يدويًا."
    }
}
