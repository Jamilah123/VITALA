//
//  WelcomeViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Foundation
import Combine

@MainActor
final class WelcomeViewModel: ObservableObject {
    private let router: OnboardingRouter

    init(router: OnboardingRouter) {
        self.router = router
    }

    func startTapped() { router.push(.auth(.signUp)) }
    func loginTapped() { router.push(.auth(.login)) }
}
