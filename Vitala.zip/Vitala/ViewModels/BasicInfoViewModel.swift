//
//  BasicInfoViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Foundation
import Combine

@MainActor
final class BasicInfoViewModel: ObservableObject {
    
    // MARK: Input
    @Published var birthDate: Date
    @Published var gender: Gender?
    @Published var heightText: String
    @Published var weightText: String

    // MARK: Dependencies
    private let repository: ProfileRepository
    private let router: OnboardingRouter

    init(repository: ProfileRepository, router: OnboardingRouter) {
        self.repository = repository
        self.router = router

        let draft = repository.draft
        self.birthDate = draft.birthDate
            ?? Calendar.current.date(byAdding: .year, value: -30, to: Date()) ?? Date()
        self.gender = draft.gender
        self.heightText = draft.heightCm.map { String(Int($0)) } ?? ""
        self.weightText = draft.weightKg.map { String(Int($0)) } ?? ""
    }

    // MARK: Derived
    var heightCm: Double? { Double(heightText.normalizedDigits) }
    var weightKg: Double? { Double(weightText.normalizedDigits) }

    var bmi: Double? { BMICalculator.bmi(heightCm: heightCm, weightKg: weightKg) }
    var bmiCategory: BMICategory? { bmi.map(BMICategory.init(bmi:)) }

    var bmiDisplay: String {
        bmi.map { String(format: "%.1f", $0) } ?? "—"
    }

    /// موضع المؤشر على الشريط (0...1) بحيث BMI من 15 إلى 40.
    var bmiMarkerPosition: Double {
        guard let bmi else { return 0 }
        return min(max((bmi - 15) / 25, 0), 1)
    }

    var age: Int {
        Calendar.current.dateComponents([.year], from: birthDate, to: Date()).year ?? 0
    }

    var isHeightValid: Bool { (heightCm ?? 0) >= 50 && (heightCm ?? 0) <= 250 }
    var isWeightValid: Bool { (weightKg ?? 0) >= 20 && (weightKg ?? 0) <= 300 }
    var canProceed: Bool { isHeightValid && isWeightValid && age >= 0 && age <= 120 }

    // MARK: Actions
    func nextTapped() {
        guard canProceed else { return }
        repository.update { draft in
            draft.birthDate = birthDate
            draft.gender = gender
            draft.heightCm = heightCm
            draft.weightKg = weightKg
        }
        router.push(.healthHistory)
    }

    func backTapped() { router.pop() }
}

