//
//  PatientTabsViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import SwiftUI
import Combine

// Shared read-only projection of the existing checkup catalog and results store.
@MainActor
final class PatientTabsViewModel: ObservableObject {
    @Published private(set) var checkups: [Checkup] = []
    @Published private(set) var resultCountByCheckup: [String: Int] = [:]
    @Published private(set) var totalResults = 0

    func refresh() {
        checkups = CheckupsViewModel().checkups
        var counts: [String: Int] = [:]
        for checkup in checkups {
            counts[String(describing: checkup.id)] = CheckupResultsStore.shared.results(for: checkup.id).count
        }
        resultCountByCheckup = counts
        totalResults = counts.values.reduce(0, +)
    }

    func count(for checkup: Checkup) -> Int {
        resultCountByCheckup[String(describing: checkup.id)] ?? 0
    }
}

// Demo-only account details. Replace with your existing profile repository
// when its API is available. Does not change the patient medical profile.
@MainActor
final class PatientAccountViewModel: ObservableObject {
    @Published var fullName: String { didSet { save() } }
    @Published var phone: String { didSet { save() } }
    @Published var email: String { didSet { save() } }
    @Published var notificationsEnabled: Bool { didSet { save() } }

    private enum Keys {
        static let name = "vitala.patient.account.name"
        static let phone = "vitala.patient.account.phone"
        static let email = "vitala.patient.account.email"
        static let notifications = "vitala.patient.account.notifications"
    }

    init() {
        let defaults = UserDefaults.standard
        fullName = defaults.string(forKey: Keys.name) ?? ""
        phone = defaults.string(forKey: Keys.phone) ?? ""
        email = defaults.string(forKey: Keys.email) ?? ""
        notificationsEnabled = defaults.object(forKey: Keys.notifications) as? Bool ?? true
    }

    private func save() {
        let defaults = UserDefaults.standard
        defaults.set(fullName, forKey: Keys.name)
        defaults.set(phone, forKey: Keys.phone)
        defaults.set(email, forKey: Keys.email)
        defaults.set(notificationsEnabled, forKey: Keys.notifications)
    }
}
