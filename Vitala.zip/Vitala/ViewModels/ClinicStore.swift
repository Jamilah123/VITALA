//
//  ClinicStore.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import SwiftUI
import Combine

@MainActor final class ClinicStore: ObservableObject {
    static let shared = ClinicStore()
    @Published var state: ClinicState { didSet { save() } }
    @Published var isLoggedIn = false
    private let key = "vitala.clinic.demo.v1"
    private init() {
        if let data = UserDefaults.standard.data(forKey: key), let value = try? JSONDecoder().decode(ClinicState.self, from: data) { state = value }
        else { state = .demo() }
    }
    private func save() { if let data = try? JSONEncoder().encode(state) { UserDefaults.standard.set(data, forKey: key) } }
    func login(name: String, contact: String, password: String) -> Bool {
        let profile = state.profile
        let valid = name.trimmingCharacters(in: .whitespacesAndNewlines).localizedCaseInsensitiveCompare(profile.name) == .orderedSame &&
            (contact == profile.email || contact == profile.phone) && password == profile.password
        isLoggedIn = valid
        return valid
    }
    func logout() { isLoggedIn = false }
    func patient(_ id: UUID) -> ClinicPatient? { state.patients.first { $0.id == id } }
    func service(_ id: UUID) -> ClinicManagedService? {
        state.services.first { $0.id == id }
    }

    func updateBooking(_ booking: ClinicBooking, status: ClinicBookingStatus) {
        guard let index = state.bookings.firstIndex(where: { $0.id == booking.id }) else { return }
        state.bookings[index].status = status
    }
    func addService(_ service: ClinicManagedService) {
        state.services.append(service)
    }
    func removeService(_ id: UUID) { state.services.removeAll { $0.id == id } }
    func addResult(_ result: ClinicResult) { state.results.append(result) }
    func addSlot(_ slot: ClinicAvailability) { state.availability.append(slot) }
    var completedCount: Int { state.bookings.filter { $0.status == .completed }.count }
    var cancelledCount: Int { state.bookings.filter { $0.status == .cancelled }.count }
    var mostRequested: [(String, Int)] {
        state.services.map { service in (service.name, state.bookings.filter { $0.serviceID == service.id }.count) }.sorted { $0.1 > $1.1 }
    }
}

