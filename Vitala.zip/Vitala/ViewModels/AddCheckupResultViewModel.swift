//
//  AddCheckupResultViewModel.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation
import Combine

@MainActor
final class AddCheckupResultViewModel: ObservableObject {
    @Published var value = ""
    @Published var unit = ""
    @Published var date = Date()
    @Published var notes = ""
    @Published var errorMessage: String?

    private let checkupID: UUID
    private let store: CheckupResultsStore

    init(
        checkupID: UUID,
        store: CheckupResultsStore = .shared
    ) {
        self.checkupID = checkupID
        self.store = store
    }

    func save() -> Bool {
        let cleanedValue = value.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !cleanedValue.isEmpty else {
            errorMessage = "فضلاً أدخلي نتيجة الفحص"
            return false
        }

        let result = CheckupResult(
            checkupID: checkupID,
            value: cleanedValue,
            unit: unit.trimmingCharacters(in: .whitespacesAndNewlines),
            date: date,
            notes: notes.trimmingCharacters(in: .whitespacesAndNewlines)
        )

        store.add(result)
        errorMessage = nil
        return true
    }
}
