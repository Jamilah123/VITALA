//
//  NearbyClinic.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import Foundation
import CoreLocation

struct NearbyClinic: Identifiable, Hashable {
    let id: String
    let name: String
    let description: String
    let city: String
    let district: String
    let address: String
    let latitude: Double
    let longitude: Double
    let rating: Double?
    let workingHours: String
    let phone: String
    let services: [String]

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(
            latitude: latitude,
            longitude: longitude
        )
    }

    var searchText: String {
        "\(name) \(city) \(district) \(address) \(services.joined(separator: " "))"
    }

    static func == (
        lhs: NearbyClinic,
        rhs: NearbyClinic
    ) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

// MARK: - Repository

protocol NearbyClinicsRepository {
    func fetchClinics() -> [NearbyClinic]
}

// MARK: - Mock Data

struct MockNearbyClinicsRepository: NearbyClinicsRepository {

    func fetchClinics() -> [NearbyClinic] {
        [
            NearbyClinic(
                id: "clinic-01",
                name: "عيادة فيتالا التجريبية - الروضة",
                description: "عيادة تجريبية للفحوصات الوقائية والتحاليل الأساسية.",
                city: "جدة",
                district: "الروضة",
                address: "حي الروضة، جدة",
                latitude: 21.5652,
                longitude: 39.1661,
                rating: 4.7,
                workingHours: "حسب المواعيد المتاحة",
                phone: "",
                services: [
                    "فحص السكري",
                    "فحص الكوليسترول",
                    "تحليل الدم"
                ]
            ),

            NearbyClinic(
                id: "clinic-02",
                name: "مركز الصحة الوقائية التجريبي",
                description: "مركز تجريبي للمتابعة الصحية والفحوصات الدورية.",
                city: "جدة",
                district: "الزهراء",
                address: "حي الزهراء، جدة",
                latitude: 21.6010,
                longitude: 39.1465,
                rating: 4.4,
                workingHours: "حسب المواعيد المتاحة",
                phone: "",
                services: [
                    "قياس ضغط الدم",
                    "مؤشر كتلة الجسم",
                    "فحص السكري"
                ]
            ),

            NearbyClinic(
                id: "clinic-03",
                name: "عيادة العناية التجريبية",
                description: "خدمات تجريبية للفحوصات المخبرية والوقائية.",
                city: "جدة",
                district: "السلامة",
                address: "حي السلامة، جدة",
                latitude: 21.5843,
                longitude: 39.1587,
                rating: nil,
                workingHours: "حسب المواعيد المتاحة",
                phone: "",
                services: [
                    "تحليل الدم",
                    "فحص وظائف الكلى",
                    "فحص الكوليسترول"
                ]
            ),

            NearbyClinic(
                id: "clinic-04",
                name: "مركز فيتالا التجريبي - الرياض",
                description: "مركز تجريبي للفحوصات الوقائية.",
                city: "الرياض",
                district: "العليا",
                address: "حي العليا، الرياض",
                latitude: 24.6921,
                longitude: 46.6850,
                rating: 4.6,
                workingHours: "حسب المواعيد المتاحة",
                phone: "",
                services: [
                    "فحص السكري",
                    "تحليل الدم",
                    "قياس ضغط الدم"
                ]
            )
        ]
    }
}
