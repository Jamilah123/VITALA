//
//  PatientTabComponents.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import SwiftUI

// Unique names avoid conflicts with existing Vitala UI components.
enum PatientTabPalette {
    static let navy = VitalaTheme.Colors.navy
    static let green = VitalaTheme.Colors.green
    static let ice = Color(red: 0.94, green: 0.97, blue: 0.99)
    static let border = VitalaTheme.Colors.border
}

struct PatientTabCard<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        content
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(17)
            .background(.white, in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(PatientTabPalette.border, lineWidth: 1))
    }
}

struct PatientTabHeading: View {
    let title: String
    let subtitle: String
    let symbol: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.system(size: 27, weight: .bold)).foregroundStyle(PatientTabPalette.navy)
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
                .font(.title3)
                .foregroundStyle(PatientTabPalette.navy)
                .frame(width: 48, height: 48)
                .background(.white, in: RoundedRectangle(cornerRadius: 15))
        }
    }
}
