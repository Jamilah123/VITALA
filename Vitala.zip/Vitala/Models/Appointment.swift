//
//  Appointment.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import Foundation

enum AppointmentStatus: String, Codable {
    case upcoming = "قادم"
    case completed = "سابق"
    case cancelled = "ملغي"
}

struct Appointment: Identifiable, Codable, Hashable {
    let id: UUID
    let clinicID: String
    let clinicName: String
    let clinicAddress: String
    let service: String
    let date: Date
    let durationMinutes: Int
    var status: AppointmentStatus

    init(
        id: UUID = UUID(),
        clinicID: String,
        clinicName: String,
        clinicAddress: String,
        service: String,
        date: Date,
        durationMinutes: Int = 30,
        status: AppointmentStatus = .upcoming
    ) {
        self.id = id
        self.clinicID = clinicID
        self.clinicName = clinicName
        self.clinicAddress = clinicAddress
        self.service = service
        self.date = date
        self.durationMinutes = durationMinutes
        self.status = status
    }

    var displayStatus: AppointmentStatus {
        if status == .cancelled {
            return .cancelled
        }

        return date < Date() ? .completed : .upcoming
    }

    var formattedDate: String {
        date.formatted(
            .dateTime
                .weekday(.wide)
                .day()
                .month(.wide)
                .year()
                .locale(Locale(identifier: "ar_SA"))
        )
    }

    var formattedTime: String {
        date.formatted(
            .dateTime
                .hour()
                .minute()
                .locale(Locale(identifier: "ar_SA"))
        )
    }
}
