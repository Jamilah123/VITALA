//
//  AppointmentRepository.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//


import Foundation
import Combine

enum AppointmentError: LocalizedError {
    case slotUnavailable
    case invalidDate
    case appointmentNotFound

    var errorDescription: String? {
        switch self {
        case .slotUnavailable:
            return "هذا الموعد لم يعد متاحًا. اختاري وقتًا آخر."
        case .invalidDate:
            return "لا يمكن حجز موعد في وقت سابق."
        case .appointmentNotFound:
            return "لم يتم العثور على الموعد."
        }
    }
}

@MainActor
final class AppointmentRepository: ObservableObject {

    static let shared = AppointmentRepository()

    @Published private(set) var appointments: [Appointment] = []

    private let storageKey = "vitala.mock.appointments.v1"

    private init() {
        load()
    }

    func isAvailable(
        clinicID: String,
        date: Date,
        durationMinutes: Int = 30,
        excluding appointmentID: UUID? = nil
    ) -> Bool {

        let proposedEnd = date.addingTimeInterval(
            TimeInterval(durationMinutes * 60)
        )

        return !appointments.contains { appointment in

            guard appointment.clinicID == clinicID,
                  appointment.status != .cancelled,
                  appointment.id != appointmentID else {
                return false
            }

            let existingEnd = appointment.date.addingTimeInterval(
                TimeInterval(appointment.durationMinutes * 60)
            )

            return date < existingEnd &&
                   appointment.date < proposedEnd
        }
    }

    @discardableResult
    func book(
        clinic: NearbyClinic,
        service: String,
        date: Date,
        durationMinutes: Int = 30
    ) throws -> Appointment {

        guard date > Date() else {
            throw AppointmentError.invalidDate
        }

        guard isAvailable(
            clinicID: clinic.id,
            date: date,
            durationMinutes: durationMinutes
        ) else {
            throw AppointmentError.slotUnavailable
        }

        let appointment = Appointment(
            clinicID: clinic.id,
            clinicName: clinic.name,
            clinicAddress: clinic.address,
            service: service,
            date: date,
            durationMinutes: durationMinutes
        )

        appointments.append(appointment)
        save()

        return appointment
    }

    func cancel(_ appointment: Appointment) throws {

        guard let index = appointments.firstIndex(
            where: { $0.id == appointment.id }
        ) else {
            throw AppointmentError.appointmentNotFound
        }

        appointments[index].status = .cancelled
        save()
    }

    func reschedule(
        _ appointment: Appointment,
        to newDate: Date
    ) throws {

        guard newDate > Date() else {
            throw AppointmentError.invalidDate
        }

        guard let index = appointments.firstIndex(
            where: { $0.id == appointment.id }
        ) else {
            throw AppointmentError.appointmentNotFound
        }

        guard appointments[index].status == .upcoming,
              appointments[index].date > Date() else {
            throw AppointmentError.invalidDate
        }

        guard isAvailable(
            clinicID: appointment.clinicID,
            date: newDate,
            durationMinutes: appointment.durationMinutes,
            excluding: appointment.id
        ) else {
            throw AppointmentError.slotUnavailable
        }

        appointments[index] = Appointment(
            id: appointment.id,
            clinicID: appointment.clinicID,
            clinicName: appointment.clinicName,
            clinicAddress: appointment.clinicAddress,
            service: appointment.service,
            date: newDate,
            durationMinutes: appointment.durationMinutes
        )

        save()
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(appointments) else {
            return
        }

        UserDefaults.standard.set(data, forKey: storageKey)
    }

    private func load() {
        guard let data = UserDefaults.standard.data(
            forKey: storageKey
        ),
        let saved = try? JSONDecoder().decode(
            [Appointment].self,
            from: data
        ) else {
            return
        }

        appointments = saved
    }
}
