//
//  Clinic.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Foundation

struct ClinicService: Identifiable, Hashable {
    let id: UUID
    let name: String
    init(id: UUID = UUID(), name: String) { self.id = id; self.name = name }
}

struct Clinic: Identifiable, Hashable {
    let id: UUID
    let name: String
    let description: String
    let district: String
    let distanceKm: Double
    let rating: Double
    let ratingCount: Int
    let workingHours: String
    let phone: String
    let latitude: Double
    let longitude: Double
    let services: [ClinicService]
}
