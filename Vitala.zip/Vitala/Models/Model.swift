//
//  Model.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation

// MARK: - Enums

enum Gender: String, CaseIterable, Identifiable, Codable {
    case male, female

    var id: String { rawValue }

    var title: String {
        self == .male ? "ذكر" : "أنثى"
    }
}

enum DiabetesType: String, CaseIterable, Identifiable, Codable {
    case type1
    case type2
    case gestational
    case unknown

    var id: String { rawValue }

    var title: String {
        switch self {
        case .type1: return "النوع الأول"
        case .type2: return "النوع الثاني"
        case .gestational: return "سكري الحمل"
        case .unknown: return "غير معروف"
        }
    }
}

enum SmokingStatus: String, CaseIterable, Identifiable, Codable {
    case never
    case current
    case former

    var id: String { rawValue }

    var title: String {
        switch self {
        case .never: return "لم أدخن سابقًا"
        case .current: return "مدخن حاليًا"
        case .former: return "مدخن سابقًا"
        }
    }
}

enum DiagnosedCondition: String, CaseIterable, Identifiable, Codable {
    case diabetes, hypertension, highCholesterol, none

    var id: String { rawValue }

    var title: String {
        switch self {
        case .diabetes: return "السكري"
        case .hypertension: return "ضغط الدم"
        case .highCholesterol: return "ارتفاع في الدهون"
        case .none: return "لا شيء"
        }
    }
}

enum FamilyHistoryItem: String, CaseIterable, Identifiable, Codable {
    case diabetes
    case breastCancer
    case colon
    case heartDisease
    case hypertension

    var id: String { rawValue }

    var title: String {
        switch self {
        case .diabetes: return "السكري"
        case .breastCancer: return "سرطان الثدي"
        case .colon: return "سرطان القولون"
        case .heartDisease: return "أمراض القلب"
        case .hypertension: return "ارتفاع ضغط الدم"
        }
    }
}

enum BMICategory {
    case underweight, normal, overweight, obese

    init(bmi: Double) {
        switch bmi {
        case ..<18.5: self = .underweight
        case ..<25: self = .normal
        case ..<30: self = .overweight
        default: self = .obese
        }
    }

    var title: String {
        switch self {
        case .underweight: return "أقل من الطبيعي"
        case .normal: return "ضمن النطاق الطبيعي"
        case .overweight: return "زيادة في الوزن"
        case .obese: return "سمنة"
        }
    }
}

// MARK: - Entities

struct Medication: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String
    var frequency: String

    init(
        id: UUID = UUID(),
        name: String,
        frequency: String
    ) {
        self.id = id
        self.name = name
        self.frequency = frequency
    }
}

// MARK: - Profile Draft

struct ProfileDraft: Codable {
    var fullName: String?
    var phoneNumber: String?
    var birthDate: Date?
    var gender: Gender?
    var heightCm: Double?
    var weightKg: Double?

    var conditions: Set<DiagnosedCondition> = []
    var familyHistory: Set<FamilyHistoryItem> = []
    var medications: [Medication] = []

    var diabetesType: DiabetesType?
    var familyDiabetesType: DiabetesType?
    var smokingStatus: SmokingStatus?
}

// MARK: - BMI

enum BMICalculator {
    static func bmi(
        heightCm: Double?,
        weightKg: Double?
    ) -> Double? {
        guard
            let h = heightCm,
            let w = weightKg,
            h > 0,
            w > 0
        else {
            return nil
        }

        let m = h / 100
        return w / (m * m)
    }
}
