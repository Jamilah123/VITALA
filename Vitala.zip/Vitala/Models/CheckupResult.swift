//
//  CheckupResult.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation

struct CheckupResult: Identifiable, Codable {
    let id: UUID
    let checkupID: UUID
    var value: String
    var unit: String
    var date: Date
    var notes: String

    init(
        id: UUID = UUID(),
        checkupID: UUID,
        value: String,
        unit: String,
        date: Date = Date(),
        notes: String = ""
    ) {
        self.id = id
        self.checkupID = checkupID
        self.value = value
        self.unit = unit
        self.date = date
        self.notes = notes
    }
}
