//
//  Checkup.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation

struct Checkup: Identifiable, Hashable {
    let id: UUID
    let name: String
    let category: String
    let date: String
    let status: CheckupStatus
    let description: String
    let importance: String
    let lastResult: String

    init(
        id: UUID = UUID(),
        name: String,
        category: String,
        date: String,
        status: CheckupStatus,
        description: String,
        importance: String,
        lastResult: String
    ) {
        self.id = id
        self.name = name
        self.category = category
        self.date = date
        self.status = status
        self.description = description
        self.importance = importance
        self.lastResult = lastResult
    }
}

enum CheckupStatus: String, Hashable {
    case overdue = "متأخر"
    case upcoming = "قادم"
    case completed = "مكتمل"
}
