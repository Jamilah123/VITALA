//
//  ClinicModels.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 04/06/1448 AH.
//

import Foundation

struct ClinicPatient: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var age: Int
    var gender: String
    var height: Double
    var weight: Double
    var medicalHistory: String
    var familyHistory: String
    var medications: String
    var riskFactors: String
    var previousResults: String
    var recommendedScreenings: String
    var bmi: Double { weight / pow(height / 100, 2) }
}
struct ClinicDoctor: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var specialty: String
}
struct ClinicManagedService: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var duration: Int
    var isActive: Bool = true
}
enum ClinicBookingStatus: String, Codable, CaseIterable, Identifiable {
    case scheduled = "مجدول", completed = "مكتمل", cancelled = "ملغي", noShow = "لم يحضر"
    var id: String { rawValue }
}
struct ClinicBooking: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var patientID: UUID
    var serviceID: UUID
    var date: Date
    var status: ClinicBookingStatus = .scheduled
}
struct ClinicResult: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var patientID: UUID
    var serviceID: UUID
    var date: Date = Date()
    var notes: String
    var fileName: String?
    var fileData: Data?
}
struct ClinicAvailability: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var date: Date
    var time: Date
    var duration: Int = 30
    var isClosed: Bool = false
}
struct ClinicProfileData: Codable {
    var name: String = "عيادة الأمل"
    var email: String = "clinic@example.com"
    var phone: String = "0123456789"
    var password: String = "123456"
    var description: String = "فحوصات وقائية وخدمات صحية"
    var address: String = "جدة، حي الروضة"
    var workingHours: String = "8 ص – 9 م"
    var logoData: Data? = nil
}
struct ClinicSubscription: Codable {
    var planName: String = "تجريبي"
    var renewalDate: Date = Calendar.current.date(byAdding: .month, value: 1, to: Date()) ?? Date()
    var isActive: Bool = true
}
struct ClinicState: Codable {
    var profile = ClinicProfileData()
    var patients: [ClinicPatient] = []
    var doctors: [ClinicDoctor] = []
    var services: [ClinicManagedService] = []
    var bookings: [ClinicBooking] = []
    var results: [ClinicResult] = []
    var availability: [ClinicAvailability] = []
    var subscription = ClinicSubscription()
    static func demo() -> ClinicState {
        var state = ClinicState()
        state.patients = [
            ClinicPatient(name: "نورة العتيبي", age: 31, gender: "أنثى", height: 165, weight: 68, medicalHistory: "لا يوجد", familyHistory: "السكري", medications: "لا يوجد", riskFactors: "قلة النشاط", previousResults: "HbA1c: 5.7%", recommendedScreenings: "فحص السكر والكوليسترول"),
            ClinicPatient(name: "محمد الغامدي", age: 45, gender: "ذكر", height: 175, weight: 83, medicalHistory: "ارتفاع ضغط الدم", familyHistory: "أمراض القلب", medications: "دواء ضغط", riskFactors: "زيادة الوزن", previousResults: "ضغط الدم: 135/85", recommendedScreenings: "فحص الكوليسترول"),
            ClinicPatient(name: "ريم الحربي", age: 28, gender: "أنثى", height: 160, weight: 59, medicalHistory: "لا يوجد", familyHistory: "لا يوجد", medications: "لا يوجد", riskFactors: "لا يوجد", previousResults: "CBC: طبيعي", recommendedScreenings: "تحليل الدم")
        ]
        state.doctors = [ClinicDoctor(name: "د. سارة أحمد", specialty: "طب الأسرة"), ClinicDoctor(name: "د. خالد محمد", specialty: "الطب الباطني")]
        state.services = [
            ClinicManagedService(name: "تحليل الدم", duration: 30),
            ClinicManagedService(name: "قياس مؤشر كتلة الجسم", duration: 15),
            ClinicManagedService(name: "فحص الكوليسترول", duration: 30),
            ClinicManagedService(name: "فحص السكري", duration: 30)
        ]
        state.bookings = [ClinicBooking(patientID: state.patients[0].id, serviceID: state.services[0].id, date: Calendar.current.date(byAdding: .day, value: 1, to: Date()) ?? Date()), ClinicBooking(patientID: state.patients[1].id, serviceID: state.services[3].id, date: Calendar.current.date(byAdding: .day, value: 2, to: Date()) ?? Date())]
        return state
    }
}
