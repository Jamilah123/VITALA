//
//  HealthKitService.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import Foundation
import HealthKit

enum HealthKitError: LocalizedError {
    case unavailable
    case invalidType
    case readFailed

    var errorDescription: String? {
        switch self {
        case .unavailable:
            return "Apple Health غير متاح على هذا الجهاز."
        case .invalidType:
            return "نوع البيانات المطلوبة غير متاح."
        case .readFailed:
            return "تعذرت قراءة البيانات الصحية."
        }
    }
}

struct HealthActivityData {
    var steps: Int?
    var heartRate: Double?
    var sleepHours: Double?
}

@MainActor
final class HealthKitService {

    private let healthStore = HKHealthStore()

    var isAvailable: Bool {
        HKHealthStore.isHealthDataAvailable()
    }

    func requestAuthorization() async throws {
        guard isAvailable else {
            throw HealthKitError.unavailable
        }

        let identifiers: [HKQuantityTypeIdentifier] = [
            .stepCount,
            .heartRate
        ]

        var readTypes = Set<HKObjectType>()

        for identifier in identifiers {
            if let type = HKObjectType.quantityType(
                forIdentifier: identifier
            ) {
                readTypes.insert(type)
            }
        }

        if let sleepType = HKObjectType.categoryType(
            forIdentifier: .sleepAnalysis
        ) {
            readTypes.insert(sleepType)
        }

        try await healthStore.requestAuthorization(
            toShare: [],
            read: readTypes
        )
    }

    func fetchTodayData() async throws -> HealthActivityData {

        async let steps = fetchSteps()
        async let heartRate = fetchHeartRate()
        async let sleep = fetchSleep()

        return try await HealthActivityData(
            steps: steps,
            heartRate: heartRate,
            sleepHours: sleep
        )
    }

    private func fetchSteps() async throws -> Int? {

        guard let type = HKQuantityType.quantityType(
            forIdentifier: .stepCount
        ) else {
            throw HealthKitError.invalidType
        }

        let calendar = Calendar.current
        let start = calendar.startOfDay(for: Date())

        return try await withCheckedThrowingContinuation {
            continuation in

            let predicate = HKQuery.predicateForSamples(
                withStart: start,
                end: Date(),
                options: .strictStartDate
            )

            let query = HKStatisticsQuery(
                quantityType: type,
                quantitySamplePredicate: predicate,
                options: .cumulativeSum
            ) { _, statistics, error in

                if let error {
                    continuation.resume(throwing: error)
                    return
                }

                let value = statistics?
                    .sumQuantity()?
                    .doubleValue(for: .count())

                continuation.resume(
                    returning: value.map { Int($0) }
                )
            }

            healthStore.execute(query)
        }
    }

    private func fetchHeartRate() async throws -> Double? {

        guard let type = HKQuantityType.quantityType(
            forIdentifier: .heartRate
        ) else {
            throw HealthKitError.invalidType
        }

        return try await withCheckedThrowingContinuation {
            continuation in

            let sort = NSSortDescriptor(
                key: HKSampleSortIdentifierEndDate,
                ascending: false
            )

            let query = HKSampleQuery(
                sampleType: type,
                predicate: nil,
                limit: 1,
                sortDescriptors: [sort]
            ) { _, samples, error in

                if let error {
                    continuation.resume(throwing: error)
                    return
                }

                let sample = samples?.first as? HKQuantitySample

                let value = sample?.quantity.doubleValue(
                    for: HKUnit.count().unitDivided(
                        by: .minute()
                    )
                )

                continuation.resume(returning: value)
            }

            healthStore.execute(query)
        }
    }

    private func fetchSleep() async throws -> Double? {

        guard let type = HKObjectType.categoryType(
            forIdentifier: .sleepAnalysis
        ) else {
            throw HealthKitError.invalidType
        }

        let calendar = Calendar.current
        let end = Date()
        let start = calendar.date(
            byAdding: .day,
            value: -1,
            to: end
        )!

        return try await withCheckedThrowingContinuation {
            continuation in

            let predicate = HKQuery.predicateForSamples(
                withStart: start,
                end: end,
                options: .strictStartDate
            )

            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, samples, error in

                if let error {
                    continuation.resume(throwing: error)
                    return
                }

                let totalSeconds = (samples ?? [])
                    .compactMap { $0 as? HKCategorySample }
                    .filter {
                        $0.value == HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue ||
                        $0.value == HKCategoryValueSleepAnalysis.asleepCore.rawValue ||
                        $0.value == HKCategoryValueSleepAnalysis.asleepDeep.rawValue ||
                        $0.value == HKCategoryValueSleepAnalysis.asleepREM.rawValue
                    }
                    .reduce(0.0) {
                        $0 + $1.endDate.timeIntervalSince(
                            $1.startDate
                        )
                    }

                let hours = totalSeconds / 3600

                continuation.resume(
                    returning: hours > 0 ? hours : nil
                )
            }

            healthStore.execute(query)
        }
    }
}
