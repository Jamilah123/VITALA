//
//  ProfileRepository.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Foundation

/// طبقة البيانات. الحين في الذاكرة، ولاحقاً تبدّلينها بـ Backend أو SwiftData بدون ما تتغير الـ ViewModels.
protocol ProfileRepository: AnyObject {
    var draft: ProfileDraft { get }
    func update(_ transform: (inout ProfileDraft) -> Void)
}

final class InMemoryProfileRepository: ProfileRepository {
    private(set) var draft: ProfileDraft

    init(draft: ProfileDraft = ProfileDraft()) {
        self.draft = draft
    }

    func update(_ transform: (inout ProfileDraft) -> Void) {
        transform(&draft)
    }
}
