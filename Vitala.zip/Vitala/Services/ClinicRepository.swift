//
//  ClinicRepository.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Foundation

protocol ClinicRepository {
    func fetchNearby(city: String?) async throws -> [Clinic]
}

/// نسخة وهمية: تتأخر شوي عشان نجرب حالة التحميل في الشاشة.
struct MockClinicRepository: ClinicRepository {
    func fetchNearby(city: String?) async throws -> [Clinic] {
        try await Task.sleep(nanoseconds: 400_000_000)
        return MockData.clinics
    }
}
