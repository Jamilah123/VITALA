//
//  MockData.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import Foundation

enum MockData {
    // المريضة التجريبية (نفس بيانات تصميم الـ PDF)
    static var patientDraft: ProfileDraft {
        var draft = ProfileDraft()
        draft.birthDate = Calendar.current.date(from: DateComponents(year: 1995, month: 5, day: 15))
        draft.gender = .female
        draft.heightCm = 175
        draft.weightKg = 72
        draft.conditions = [.diabetes, .hypertension]
        draft.familyHistory = [.diabetes]
        draft.medications = [Medication(name: "ميتفورمين 500 ملغ", frequency: "مرتين يومياً")]
        return draft
    }

    private static let bloodTest = ClinicService(name: "تحليل الدم")
    private static let bmi = ClinicService(name: "قياس مؤشر كتلة الجسم")
    private static let cholesterol = ClinicService(name: "فحص الكوليسترول")
    private static let diabetes = ClinicService(name: "فحص السكري")

    static let clinics: [Clinic] = [
        Clinic(id: UUID(), name: "عيادة الأمل",
               description: "عيادة متخصصة في الفحوصات الوقائية.",
               district: "جدة، حي الروضة", distanceKm: 1.2, rating: 4.7, ratingCount: 126,
               workingHours: "8ص – 9م", phone: "012 345 6789",
               latitude: 21.5433, longitude: 39.1728,
               services: [bloodTest, bmi, cholesterol, diabetes]),
        Clinic(id: UUID(), name: "مركز الرعاية الوقائية",
               description: "فحوصات دورية ومتابعة الأمراض المزمنة.",
               district: "جدة، حي الشاطئ", distanceKm: 2.8, rating: 4.5, ratingCount: 84,
               workingHours: "9ص – 8م", phone: "012 987 6543",
               latitude: 21.5810, longitude: 39.1530,
               services: [cholesterol, bmi])
    ]
}
