//
//  DemoAuthRepository.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import Foundation

struct DemoAccount: Codable {
    let fullName: String
    let phone: String
    let password: String
}

protocol DemoAuthRepository: AnyObject {
    func register(
        fullName: String,
        phone: String,
        password: String
    ) -> Bool

    func login(
        fullName: String,
        password: String
    ) -> DemoAccount?
}

final class InMemoryDemoAuthRepository: DemoAuthRepository {

    private let storageKey = "vitala_saved_accounts"

    private var accounts: [DemoAccount] = []

    init() {
        loadAccounts()

        // إضافة حساب تجريبي إذا لم توجد حسابات محفوظة
        if accounts.isEmpty {
            accounts.append(
                DemoAccount(
                    fullName: "Vitala Test",
                    phone: "0512345678",
                    password: "Vitala123"
                )
            )

            saveAccounts()
        }
    }

    // MARK: - Register

    func register(
        fullName: String,
        phone: String,
        password: String
    ) -> Bool {

        let alreadyExists = accounts.contains {
            $0.phone == phone
        }

        guard !alreadyExists else {
            return false
        }

        let account = DemoAccount(
            fullName: fullName.trimmingCharacters(
                in: .whitespacesAndNewlines
            ),
            phone: phone,
            password: password
        )

        accounts.append(account)

        saveAccounts()

        return true
    }

    // MARK: - Login

    func login(
        fullName: String,
        password: String
    ) -> DemoAccount? {

        accounts.first {
            $0.fullName.localizedCaseInsensitiveCompare(
                fullName.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
            ) == .orderedSame
            && $0.password == password
        }
    }

    // MARK: - Save

    private func saveAccounts() {

        guard let data = try? JSONEncoder().encode(accounts) else {
            return
        }

        UserDefaults.standard.set(data, forKey: storageKey)
    }

    // MARK: - Load

    private func loadAccounts() {

        guard
            let data = UserDefaults.standard.data(forKey: storageKey),
            let savedAccounts = try? JSONDecoder().decode(
                [DemoAccount].self,
                from: data
            )
        else {
            return
        }

        accounts = savedAccounts
    }
}
