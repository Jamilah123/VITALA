//
//  CheckupResultsStore.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import Foundation

final class CheckupResultsStore {
    static let shared = CheckupResultsStore()

    private let storageKey = "vitala_checkup_results"

    private init() {}

    func allResults() -> [CheckupResult] {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let results = try? JSONDecoder().decode(
                [CheckupResult].self,
                from: data
              ) else {
            return []
        }

        return results
    }

    func results(for checkupID: UUID) -> [CheckupResult] {
        allResults()
            .filter { $0.checkupID == checkupID }
            .sorted { $0.date > $1.date }
    }

    func add(_ result: CheckupResult) {
        var results = allResults()
        results.append(result)

        if let data = try? JSONEncoder().encode(results) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
}
