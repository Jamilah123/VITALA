//
//  AppContainer.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//


import SwiftUI
import Combine

@MainActor
final class AppContainer: ObservableObject {

    let repository: ProfileRepository
    let authRepository: DemoAuthRepository
    let clinicRepository: ClinicRepository
    let router: OnboardingRouter
    let healthKitService = HealthKitService()

    init(
        repository: ProfileRepository? = nil,
        authRepository: DemoAuthRepository? = nil,
        clinicRepository: ClinicRepository? = nil,
        router: OnboardingRouter? = nil
    ) {
        self.repository = repository ?? InMemoryProfileRepository()
        self.authRepository = authRepository ?? InMemoryDemoAuthRepository()
        self.clinicRepository = clinicRepository ?? MockClinicRepository()
        self.router = router ?? OnboardingRouter()
    }

    func makeWelcomeViewModel() -> WelcomeViewModel {
        WelcomeViewModel(router: router)
    }

    func makeAuthViewModel(mode: AuthMode) -> AuthViewModel {
        AuthViewModel(
            mode: mode,
            repository: repository,
            authRepository: authRepository,
            router: router
        )
    }

    func makeBasicInfoViewModel() -> BasicInfoViewModel {
        BasicInfoViewModel(
            repository: repository,
            router: router
        )
    }

    func makeHealthHistoryViewModel() -> HealthHistoryViewModel {
        HealthHistoryViewModel(
            repository: repository,
            router: router
        )
    }
    
    func makeWearableLinkViewModel() -> WearableLinkViewModel {
        WearableLinkViewModel(
            healthKitService: healthKitService,
            router: router
        )
    }
}
