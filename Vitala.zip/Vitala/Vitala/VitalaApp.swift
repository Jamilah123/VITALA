//
//  VitalaApp.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import SwiftUI

@main
@MainActor
struct VitalaApp: App {
    @StateObject private var container = AppContainer()

    var body: some Scene {
        WindowGroup {
            OnboardingFlowView(container: container)
                // التطبيق عربي (RTL)
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "ar"))
        }
    }
}
