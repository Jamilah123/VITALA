//
//  OnboardingRouter.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//



import SwiftUI
import Combine

@MainActor
final class OnboardingRouter: ObservableObject {

    @Published var path = NavigationPath()

    func push(_ route: OnboardingRoute) {
        path.append(route)
    }

    func pop() {
        guard !path.isEmpty else { return }
        path.removeLast()
    }

    func popToRoot() {
        path = NavigationPath()
    }
}
