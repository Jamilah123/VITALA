//
//  Theme..swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import SwiftUI

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }
}

enum VitalaTheme {
    enum Colors {
        static let navy      = Color(hex: 0x1B2A62)
        static let green     = Color(hex: 0x6B7F52)
        static let pink      = Color(hex: 0xC98A93)
        static let muted     = Color(hex: 0x7A8099)
        static let border    = Color(hex: 0xE3E5EE)
        static let surface   = Color(hex: 0xF4F5F9)
        static let background = Color.white
    }

    enum Radius {
        static let card: CGFloat = 22
        static let button: CGFloat = 24
    }
}


extension String {

    var normalizedDigits: String {

        let map: [Character: Character] = [
            // Arabic digits
            "٠": "0", "١": "1", "٢": "2",
            "٣": "3", "٤": "4", "٥": "5",
            "٦": "6", "٧": "7", "٨": "8",
            "٩": "9",

            // Persian digits
            "۰": "0", "۱": "1", "۲": "2",
            "۳": "3", "۴": "4", "۵": "5",
            "۶": "6", "۷": "7", "۸": "8",
            "۹": "9",

            "٫": ".",
            ",": "."
        ]

        return String(self.map { map[$0] ?? $0 })
    }
}
