//
//  Components.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//

import SwiftUI

// MARK: - Logo

private struct LogoSwoosh: Shape {
    func path(in rect: CGRect) -> Path {
        let s = min(rect.width, rect.height) / 40
        func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x * s, y: y * s) }
        var path = Path()
        path.move(to: p(3, 8))
        path.addCurve(to: p(23, 36), control1: p(13, 8), control2: p(21, 20))
        path.addCurve(to: p(3, 8), control1: p(14, 28), control2: p(8, 18))
        return path
    }
}

private struct LogoLeaf: Shape {
    func path(in rect: CGRect) -> Path {
        let s = min(rect.width, rect.height) / 40
        func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x * s, y: y * s) }
        var path = Path()
        path.move(to: p(36, 4))
        path.addCurve(to: p(24, 30), control1: p(38, 18), control2: p(32, 26))
        path.addCurve(to: p(36, 4), control1: p(24, 18), control2: p(28, 10))
        return path
    }
}

struct VitalaLogo: View {
    var size: CGFloat = 28

    var body: some View {
        ZStack {
            LogoSwoosh().fill(VitalaTheme.Colors.navy)
            LogoLeaf().fill(VitalaTheme.Colors.green)
            Circle()
                .fill(VitalaTheme.Colors.pink)
                .frame(width: size * 0.175, height: size * 0.175)
                .position(x: size * 21 / 40, y: size * 9 / 40)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

// MARK: - Header

struct VitalaHeader: View {
    let title: String
    var showsBack: Bool = false
    var onBack: (() -> Void)? = nil
    var showsLogo: Bool = true

    var body: some View {
        ZStack {
            Text(title)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)

            HStack {
                if showsBack {
                    Button {
                        onBack?()
                    } label: {
                        Image(systemName: "chevron.backward")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(VitalaTheme.Colors.navy)
                            .frame(width: 40, height: 40)
                            .background(
                                VitalaTheme.Colors.surface,
                                in: RoundedRectangle(cornerRadius: 12)
                            )
                    }
                    .accessibilityLabel("رجوع")
                }

                Spacer()

                if showsLogo {
                    VitalaLogo(size: 28)
                }
            }
        }
        .padding(.horizontal, 20)
        .frame(height: 56)
    }
}

// MARK: - Buttons

struct PrimaryButton: View {
    let title: String
    var isEnabled: Bool = true
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(VitalaTheme.Colors.navy.opacity(isEnabled ? 1 : 0.4),
                            in: RoundedRectangle(cornerRadius: VitalaTheme.Radius.button))
        }
        .disabled(!isEnabled)
    }
}

struct SecondaryButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(VitalaTheme.Colors.navy)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .overlay(
                    RoundedRectangle(cornerRadius: VitalaTheme.Radius.button)
                        .stroke(VitalaTheme.Colors.navy, lineWidth: 1.5)
                )
        }
    }
}

// MARK: - Field row (القيمة يمين، العنوان يسار)

struct FieldRow<Content: View>: View {
    let title: String
    @ViewBuilder var content: () -> Content

    var body: some View {
        HStack {
            content()
            Spacer(minLength: 12)
            Text(title)
                .font(.system(size: 14))
                .foregroundStyle(VitalaTheme.Colors.muted)
        }
        .padding(.horizontal, 18)
        .frame(minHeight: 56)
        .background(
            RoundedRectangle(cornerRadius: VitalaTheme.Radius.card)
                .stroke(VitalaTheme.Colors.border, lineWidth: 1)
        )
    }
}

// MARK: - Chips

struct ChipView: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(isSelected ? .white : VitalaTheme.Colors.navy)
                .padding(.horizontal, 18)
                .padding(.vertical, 11)
                .background(isSelected ? VitalaTheme.Colors.navy : .white, in: Capsule())
                .overlay(Capsule().stroke(isSelected ? VitalaTheme.Colors.navy : VitalaTheme.Colors.border, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }
}

/// صف شرائح يلتف على أكثر من سطر ويدعم RTL.
struct ChipsFlow<Item: Identifiable & Hashable>: View {
    let items: [Item]
    let title: (Item) -> String
    let isSelected: (Item) -> Bool
    let onTap: (Item) -> Void
    @Environment(\.layoutDirection) private var direction

    var body: some View {
        FlowLayout(spacing: 10, isRTL: direction == .rightToLeft) {
            ForEach(items) { item in
                ChipView(title: title(item), isSelected: isSelected(item)) { onTap(item) }
            }
        }
    }
}

struct FlowLayout: Layout {
    var spacing: CGFloat = 10
    var isRTL: Bool = false

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        arrange(width: proposal.width ?? .infinity, subviews: subviews).size
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = arrange(width: bounds.width, subviews: subviews)
        for (index, frame) in result.frames.enumerated() {
            let x = isRTL ? bounds.minX + bounds.width - frame.maxX : bounds.minX + frame.minX
            subviews[index].place(at: CGPoint(x: x, y: bounds.minY + frame.minY),
                                  proposal: ProposedViewSize(frame.size))
        }
    }

    private func arrange(width: CGFloat, subviews: Subviews) -> (frames: [CGRect], size: CGSize) {
        var frames: [CGRect] = []
        var x: CGFloat = 0, y: CGFloat = 0, rowHeight: CGFloat = 0, maxX: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if x > 0, x + size.width > width {
                x = 0; y += rowHeight + spacing; rowHeight = 0
            }
            frames.append(CGRect(origin: CGPoint(x: x, y: y), size: size))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
            maxX = max(maxX, x - spacing)
        }
        return (frames, CGSize(width: maxX, height: y + rowHeight))
    }
}

// MARK: - Progress

struct StepProgressBar: View {

    let currentStep: Int
    var totalSteps: Int = 4

    var body: some View {
        HStack(spacing: 8) {
            ForEach(1...totalSteps, id: \.self) { step in
                Capsule()
                    .fill(
                        step <= currentStep
                        ? VitalaTheme.Colors.navy
                        : VitalaTheme.Colors.border
                    )
                    .frame(maxWidth: .infinity)
                    .frame(height: 5)
            }
        }
        .frame(maxWidth: .infinity)
        
    }
}


struct ScreenTitle: View {
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 26, weight: .bold))
                .foregroundStyle(VitalaTheme.Colors.navy)
            Text(subtitle)
                .font(.system(size: 14))
                .foregroundStyle(VitalaTheme.Colors.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
