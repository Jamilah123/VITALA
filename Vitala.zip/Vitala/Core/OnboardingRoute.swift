//
//  OnboardingRoute.swift
//  Vitala
//
//  Created by Jamilah Jaber Hazazi on 03/06/1448 AH.
//




import Foundation

enum OnboardingRoute: Hashable {
    case auth(AuthMode)
    case basicInfo
    case healthHistory
    case wearableLink
    case setupComplete
    case patientApp
}
